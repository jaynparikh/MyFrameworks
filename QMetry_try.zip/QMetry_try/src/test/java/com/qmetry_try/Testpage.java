package com.qmetry_try;

import org.testng.annotations.Test;
//import com.qmetry.qaf.automation.ui.WebDriverTestCase;
import static com.qmetry.qaf.automation.step.CommonStep.*;

import com.qmetry.qaf.automation.core.TestBaseProvider;
import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.WebDriverTestCase;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;

public class Testpage extends WebDriverTestCase {

	/*@Override
	protected void openPage(PageLocator pageLocator, Object... args) {
		
	}*/

	@Test(description="Sample Test Scenario", groups={"SMOKE"})
	   public void testGoogleSearch() throws InterruptedException {
		 get("http://www.google.co.in");
	      sendKeys("Git reporsitory QAF", "txt.searchbox");
	      Thread.sleep(2000);
	      click("btn.search");
	      verifyLinkWithPartialTextPresent("qaf");
	      assertLinkWithPartialTextPresent("qaf");
	      TestBaseProvider.instance().get().getLastCapturedScreenShot();
	      
	   }
}

package utility;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;



public class Xlsdataprovider {
	
	@DataProvider(name="Smoke")
	public static Object[][] regressionData(Method m)
	{
		FetchExcelDataSet excelDatSet = new FetchExcelDataSet();
		Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\ABSLI_Tests.xls", "Smoke_Test",m.getName());
		return dataset;
	}
	
	
	
	

}

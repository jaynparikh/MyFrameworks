package utility;


public class SuiteUtility {	
		
	public static boolean WriteResultUtility(Read_XLS xls, String sheetName, String ColName, int rowNum, String Result){			
		return xls.writeResult(sheetName, ColName, rowNum, Result);		 	
	}
	public static boolean WriteResultUtility1(Read_XLS xls, String sheetName,String ColName, int rowNum, String Result){			
		return xls.writeResult1(sheetName, ColName, rowNum, Result);		 	
	}
	public static boolean WriteResultUtility2(Read_XLS xls, String sheetName,String ColName, int rowNum, int Result){			
		return xls.writeResult2(sheetName, ColName, rowNum, Result);		 	
	}

	
}


package utility;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {

	static ExtentReports extent;
	static ExtentTest test;
	static ExtentHtmlReporter htmlReporter;
	static InetAddress ip;
	public static ExtentHtmlReporter startReport() throws MalformedURLException, UnknownHostException {
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")
				+ "/AutoReport.html");
		extent = new ExtentReports();

		extent.attachReporter(htmlReporter);

		extent.setSystemInfo("OS", System.getProperty("os.name"));
		ip = InetAddress.getLocalHost();
		extent.setSystemInfo("Host ip", ip.getHostName());
		extent.setSystemInfo("Environment", "QA");
		extent.setSystemInfo("User Name", System.getProperty("user.name"));

		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("AutomationTesting Report");
		htmlReporter.config().setReportName("My Own Report");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);
		return htmlReporter;
	}

	public static ExtentReports GetExtent() throws MalformedURLException, UnknownHostException {
		if (extent != null) {
			return extent;
		}
		// avoid creating new instance of html file extent = new
		// ExtentReports();

		htmlReporter = ExtentManager.startReport();

		extent.attachReporter(htmlReporter);
		return extent;
	}

	public static ExtentTest createTest(String name, String description) {
		test = extent.createTest(name, description);
		return test;
	}
	
}

package utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class AutoScreen {

	public String getscreenshot(WebDriver driver, String name)
			throws IOException, InterruptedException {

		String imagePath = String
				.format(System.getProperty("user.dir")+"\\ScreenShot\\%s_%s.png",
						name, timestamp());
		
		File scr = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File dest = new File(imagePath);
		FileUtils.copyFile(scr, dest);
		imagePath = imagePath.replace(
				System.getProperty("user.dir")+"\\", "");
		return imagePath;
	}

	public String timestamp() {
		return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());
	}

}

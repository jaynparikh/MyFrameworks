package utility;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import testsuitebase.TestResultStatus;


public class SeleniumUtils 
{
	public String element_Exit;
	public Logger Add_Log = Logger.getLogger("rootLogger");		
	public HashMap<String, String> metaData = new HashMap<String, String>();
    
	public void seterror(String errormsg){
    	TestResultStatus.Errormsg=errormsg;
    }
	public void copyExcel(String filename){

        File srcFile = new File(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\"+filename+".xls");
        String destDir = System.getProperty("user.dir")+"\\ReportLog";
        DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy__hh_mm_ssaa");
        String destFile = "Report - "+dateFormat.format(new Date()) + ".xls";
        try {
                FileUtils.copyFile(srcFile, new File(destDir + "/" + destFile));
        } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
        }       
}


	
	public void click(WebDriver driver,WebPageElements ele ) {
		WebElement element=null;
		try {
			/*waitForElement(driver, ele);*/
			element = getWebElement(driver,ele);
			element.click();
			
		} catch (Exception e) {
			try {
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", element);
			} catch (Exception e2) {
				Add_Log.info("Not able click "+ele.getName()+" element.");
				Reporter.log("Not able to click "+ele.getName()+" element.");
				seterror(ele.getName()+" not present on page");
				TestResultStatus.Testfail= true;
				Assert.fail();
			}			
						
		}						
		
						
	}
        

	public void setText(WebDriver driver,WebPageElements ele,String text){	
		if(text!=null){
		try {
			WebElement element=null;
			/*waitForElement(driver, ele);*/
			element = getWebElement(driver,ele);
			element.sendKeys(text);
		} catch (Exception e) {
			Add_Log.info(text+" not entered in "+ele.getName()+" textbox.");
			Reporter.log(text+" not entered in "+ele.getName()+" textbox.");
			seterror(ele.getName()+" not present on page");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}
		}else{
			Add_Log.info(ele.getName()+" value is null in excel");
			
			
			/*TestResultStatus.Testfail= true;
			Assert.fail();*/
		}
					
	}
	
	public void autoCompleteText(WebDriver driver,WebPageElements ele,String text){	
		if(text.length()>0){
		try {
			WebElement element=null;
			/*waitForElement(driver, ele);*/
			element = getWebElement(driver,ele);						
			element.sendKeys(text);
			Thread.sleep(5000);
			element.sendKeys(Keys.ARROW_DOWN,Keys.ENTER);
		} catch (Exception e) {
			Add_Log.info(text+" not entered in "+ele.getName()+" textbox.");
			Reporter.log(text+" not entered in "+ele.getName()+" textbox.");
			seterror(ele.getName()+" not present on page");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}
		}else{
			Add_Log.info(ele.getName()+" value is null in excel");
			/*TestResultStatus.Testfail= true;
			Assert.fail();*/
		}
					
	}
	
	public void selectDate(WebDriver driver,WebPageElements element,String dateToSelect){
		String day = dateToSelect.substring(3,5);		
		if(day.startsWith("0")){
			day = dateToSelect.substring(4,	5);
		}
		System.out.println(day);
		List<WebElement> allDates = driver.findElements(getLocatorName(element));
		/*List<WebElement> allDates=driver.findElements(By.xpath("//*[@class='calendar']//td"));*/		
		for(WebElement ele:allDates)
		{			
			String date=ele.getText();				
			if(date.equalsIgnoreCase(day))
			{
				ele.click();
				break;
			}
			
		}
	}
	
	public void clickNextCal(WebDriver driver){
		
		//List<WebElement> allDates = driver.findElements(getLocatorName(element));
		List<WebElement> allDates=driver.findElements(By.xpath("//*[@class='calendar']//td//div"));		
		for(WebElement ele:allDates)
		{			
			String date=ele.getText();	
			System.out.println(date);
			if(date.contains("�"))
			{
				ele.click();
				System.out.println("clicked on cal");
				break;
			}
			
		}
	}
	
	public String getText(WebDriver driver,WebPageElements ele){
		String text = null;
		try {
			WebElement element=null;
			element = getWebElement(driver, ele);
			text = element.getText();
			/*System.out.println(text);*/
		} catch (Exception e) {
			Add_Log.info("Not able to get text for "+ele.getName());
			Reporter.log("Not able to get text for "+ele.getName());
			seterror(ele.getName()+" not present on page");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}
		return text;
	}
	
	public String getValue(WebDriver driver,WebPageElements ele){
		String text = null;
		try {
			WebElement element=null;
			element = getWebElement(driver, ele);
			text = element.getAttribute("value");
			/*System.out.println(text);*/
		} catch (Exception e) {
			Add_Log.info("Not able to get text for "+ele.getName());
			Reporter.log("Not able to get text for "+ele.getName());
			seterror(ele.getName()+" not present on page");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}
		return text;
	}
	
	
	
	public void clearText(WebDriver driver,WebPageElements ele,String text){		
		try {
			WebElement element=null;
			/*waitForElement(driver, ele);*/
			element = getWebElement(driver,ele);
			element.clear();
		} catch (Exception e) {
			Add_Log.info(text+" not entered in "+ele.getName()+" textbox.");
			Reporter.log(text+" not entered in "+ele.getName()+" textbox.");
			seterror(ele.getName()+" not present on page");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}
	}
	
	public void selectDropdown(WebDriver driver,WebPageElements ele,String text){
		if(text.length()>0)
		{
			try {
				/*waitForElement(driver, ele);*/
				new Select(getWebElement(driver,ele)).selectByVisibleText(text);
			} catch (Exception e) {
				e.printStackTrace();
				Add_Log.info("Not able to Select "+text+" in "+ele.getName()+" drop down list.");
				Reporter.log("Not able to Select "+text+" in "+ele.getName()+" drop down list.");
				seterror(ele.getName()+" not present on page");
				TestResultStatus.Testfail= true;
				Assert.fail();
			}
		}else{
			Add_Log.info(ele.getName()+" value is null in excel");
			/*TestResultStatus.Testfail= true;
			Assert.fail();*/
		}
	}
	
	public void selectDropdownByValue(WebDriver driver,WebPageElements ele,String text){
		if(text.length()>0)
		{
			try {
				/*waitForElement(driver, ele);*/
				new Select(getWebElement(driver,ele)).selectByValue(text);
			} catch (Exception e) {
				e.printStackTrace();
				Add_Log.info("Not able to Select "+text+" in "+ele.getName()+" drop down list.");
				Reporter.log("Not able to Select "+text+" in "+ele.getName()+" drop down list.");	
				seterror(ele.getName()+" not present on page");
				TestResultStatus.Testfail= true;
				Assert.fail();
			}
		}else{
			Add_Log.info(ele.getName()+" value is null in excel");
			/*TestResultStatus.Testfail= true;
			Assert.fail();*/
		}
	}
			
	public void multiSelect(WebDriver driver,String elename,String text,WebPageElements element){
		WebPageElements ele =null;
		if(text.length()>0)
		{
			try {
				String[] values = text.split(";");
				for (int i = 0; i < values.length; i++) {
					
					/*ele = new WebPageElements(values[i],"xpath", "//*[text()='"+values[i]+"']");*/
					String xpath = "//*[contains(text(),'"+values[i]+"')]";
					System.out.println(xpath);
					ele = new WebPageElements(values[i],"xpath", xpath);
					getWebElement(driver,ele).click();
					click(driver, element);
				}
			} catch (Exception e) {
				Add_Log.info("Not able to multiselect element "+elename);
				Reporter.log("Not able to multiselect element "+elename);
				seterror(ele.getName()+" not present on page");
				TestResultStatus.Testfail= true;
				Assert.fail();
			}
		}else{
			Add_Log.info(elename+ " value is null in excel");
			/*TestResultStatus.Testfail= true;
			Assert.fail();*/
		}
	}
	
	
	public void switchToPopup(WebDriver driver, WebPageElements ele){	
		try {
			click(driver, ele);
			Thread.sleep(3000);
			String childWindowHandler = driver.getWindowHandle();
			driver.switchTo().window(childWindowHandler);
		} catch (Exception e) {
			// TODO: handle exception
			Add_Log.info("Not able to switch to popup "+ele);
			Reporter.log("Not able to switch to popup "+ele);
			seterror(ele.getName()+" not present on page");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}
		
	}
	
	public WebElement getWebElement(WebDriver driver,WebPageElements element){
    	WebElement ele =null;
    	try {
	    		if(element.getLocator().equalsIgnoreCase("xpath"))
	        	{
	    			ele = driver.findElement(By.xpath(element.getValue())); 		    			  		
	        	}else if(element.getLocator().equalsIgnoreCase("id"))
	        	{
	        		ele= driver.findElement(By.id(element.getValue()));  
	        	}else if(element.getLocator().equalsIgnoreCase("name"))
	        	{
	        		ele= driver.findElement(By.name(element.getValue()));  
	        	}else if(element.getLocator().equalsIgnoreCase("linktext"))
	        	{
	        		ele = driver.findElement(By.linkText(element.getValue()));  
	        	}else if(element.getLocator().equalsIgnoreCase("partiallinktext"))
	        	{
	        		ele = driver.findElement(By.partialLinkText(element.getValue()));  
	        	}else if(element.getLocator().equalsIgnoreCase("classname"))
	        	{
	        		ele = driver.findElement(By.className(element.getValue()));  
	        	}else if(element.getLocator().equalsIgnoreCase("tagname"))
	        	{
	        		ele = driver.findElement(By.tagName(element.getValue()));  
	        	}else if(element.getLocator().equalsIgnoreCase("css"))
	        	{
	        		ele = driver.findElement(By.cssSelector(element.getValue()));  
	        	}
	    		
		} catch (NoSuchElementException e) {	
			Add_Log.info("Not able to find element "+element.getName());
			Reporter.log("Not able to find element "+element.getName());
			seterror("Not able to find element \"+element.getName()");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}
    	if(ele==null){
    		TestResultStatus.Testfail= true;
    		Assert.fail();
    	}
    	return ele;
    }
    

   /* public void waitForElement(int miliSeconds, String eleData){
    	
    	try {
    		if(eleData.length()>0){
    			Thread.sleep(miliSeconds);
    		}		  		
		} catch (Exception e) {
			TestResultStatus.Testfail= true;
			Assert.fail();	
		}
    	
    	
	}*/
    
    public void waitForLoad(WebDriver driver, int seconds){
    	try {
    		WebDriverWait wait = new WebDriverWait(driver, seconds);

            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[contains(@class,'x-mask-msg-text')]")));

            /*while(driver.findElements(By.xpath("//div[@class='blockUI blockOverlay']")).size()>0 && seconds!=0){

                    Thread.sleep(1000);

                    seconds--;

            }*/
    		
		} catch (Exception e) {
			
			Boolean flag =isAlertPresent(driver);
	    	//System.out.println(flag);
	    	if(flag){
	    		String Msg = getAlerttext(driver).trim();
	    		System.out.println(Msg);
	    		Reporter.log(Msg);
	    		seterror(Msg);
	    		TestResultStatus.Testfail=true;				
				Assert.fail();
	    	}else{
					Add_Log.info("Loading pop up not closed");
					Reporter.log("Loading pop up not closed");
					seterror("Loading pop up not closed");
					TestResultStatus.Testfail= true;
		    		Assert.fail();
				}
					
				
			
		}
    	
    }
    
   public void waitForElementPresent(WebDriver driver, int seconds, final WebPageElements ele){
	   try {
		   WebDriverWait wait = new WebDriverWait(driver, seconds);
		   if(ele.getLocator().equalsIgnoreCase("xpath")){
			   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("id")){
			   wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("linktext")){
			   wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("name")){
			   wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("classname")){
			   wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("css")){
			   wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(ele.getValue())));
		   }
		   
		   
		   /*FluentWait<WebDriver> fWait = new FluentWait<WebDriver>(driver).withTimeout(seconds, TimeUnit.SECONDS)
			        .pollingEvery(3, TimeUnit.SECONDS)
			        .ignoring(NoSuchElementException.class);
		   fWait.until(ExpectedConditions.visibilityOf(getWebElement(driver, ele)));*/

		   
	} catch (Exception e) {
		Add_Log.info(ele.getName()+" not present on page");
		seterror(ele.getName()+" not present on page");
		TestResultStatus.Testfail= true;
		Assert.fail();
	}
	   
   }
   
   
   
   public By getLocatorName(WebPageElements ele){
	  By locator =null;
	   if(ele.getLocator().equalsIgnoreCase("xpath")){
		   locator= By.xpath(ele.getValue());
	   }else{
		   Add_Log.info("Incorrect Element");
		   seterror(ele.getName()+" not present on page");
		   Assert.fail();
	   }
	   return locator;
   }
    
    public String getAlerttext(WebDriver driver){
    	String alertText;
    	try {
    		
    		Alert alert = driver.switchTo().alert();
    		alertText = alert.getText();
    		alert.accept();    		
    		return alertText;
		} catch (Exception e) {
			Add_Log.info("Alert not present on page.");
			return null;
		}
    	    	
    }
    
    public void verifyMessage(WebDriver driver, WebPageElements ele,String expectedMsg){	
    	
    	/*Thread.sleep(3000);*/
    	waitForElementPresent(driver, 10, ele);
    	String actualMsg = null;
    		Boolean flag =isAlertPresent(driver);
	    	//System.out.println(flag);
	    	if(flag){
	    		actualMsg = getAlerttext(driver).trim();
	    		System.out.println(actualMsg);
	    		if(!actualMsg.equalsIgnoreCase(expectedMsg)){
					Add_Log.info(actualMsg+" does not message match with "+expectedMsg);
					Reporter.log(actualMsg+" does not message match with "+expectedMsg);
					seterror(actualMsg+" does not message match with "+expectedMsg);
					TestResultStatus.Testfail=true;				
					Assert.fail();
				}
	    	}else{
	    		System.out.println(expectedMsg.length());
	    		if(expectedMsg.length()>0){
		    		actualMsg =getWebElement(driver, ele).getText();
					if(!actualMsg.equalsIgnoreCase(expectedMsg)){
						Add_Log.info("Actual message "+actualMsg+" does not match with expected message: "+expectedMsg);
						Reporter.log("Actual message "+actualMsg+" does not match with expected message:"+expectedMsg);	
						Add_Log.info("Actual message is "+actualMsg);
						seterror("Actual message "+actualMsg+" does not match with expected message:"+expectedMsg);
						TestResultStatus.Testfail= true;
						Assert.fail();
					}
		    	}else{
		    		Add_Log.info(ele.getName()+" value is null in excel");	
		    		Reporter.log(ele.getName()+" value is null in excel");	
		    		seterror(ele.getName()+" value is null in excel");
		    		TestResultStatus.Testfail= true;
		    		Assert.fail();
		    	}
	    	}
	    } 
	
    public void verifyIdentifier(WebDriver driver, String expectedMsg) throws InterruptedException{
    	Thread.sleep(3000);
    	String actualMsg = null;
    		Boolean flag =isAlertPresent(driver);
	    	//System.out.println(flag);
	    	if(flag){
	    		actualMsg = getAlerttext(driver).trim();
	    		System.out.println(actualMsg);
	    		if(!actualMsg.equalsIgnoreCase(expectedMsg)){
					Add_Log.info(actualMsg+" does not message match with "+expectedMsg);
					Reporter.log(actualMsg+" does not message match with "+expectedMsg);
					seterror(actualMsg+" does not message match with "+expectedMsg);
					TestResultStatus.Testfail=true;				
					Assert.fail();
				}
	    	}else{
	    		Add_Log.info("Valid ID entered");
	    	}
	    	
    }
    
    
		
    
    
    
    public boolean isAlertPresent(WebDriver driver) 
    { 
        try 
        { 
            driver.switchTo().alert().accept();
            
        	driver.getTitle();
            return true; 
        }   // try 
        catch (UnhandledAlertException Ex) 
        { 
            return false; 
        }   // catch 
    }   // isAlertPresent()
    
    public void verifyTextPresent(WebDriver driver, WebPageElements ele, String expText)
    {
    	String actualText = getText(driver, ele);
    	if(!actualText.equalsIgnoreCase(expText)){
    		Add_Log.info(actualText+" does not match with "+expText);
			Reporter.log(actualText+" does not match with "+expText);
			seterror(actualText+" does not match with "+expText);
			TestResultStatus.Testfail=true;				
			Assert.fail();
    	}else{
    		Add_Log.info(actualText+" match with "+expText);
    		Reporter.log(actualText+" match with "+expText);
    	}
    }
    public void verifyValuePresent(WebDriver driver, WebPageElements ele, String expText)
    {
    	String actualText = getValue(driver, ele);
    	if(!actualText.equalsIgnoreCase(expText)){
    		Add_Log.info(actualText+" does not match with "+expText);
			Reporter.log(actualText+" does not match with "+expText);
			seterror(actualText+" does not match with "+expText);
			TestResultStatus.Testfail=true;				
			Assert.fail();
    	}else{
    		Add_Log.info(actualText+" match with "+expText);
    		Reporter.log(actualText+" match with "+expText);
    	}
    }
    
                 
    /*public HashMap<String, String> fetchDBdata(String query) throws SQLException 
    {
    	Statement stmt = null;
    	Connection conn = null;
    	try {
    		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());       	
    	    String url = "jdbc:oracle:thin:@vm-17fe-e158.nam.nsroot.net:1522:cloudapp";
    	    conn = DriverManager.getConnection(url,"rdip","rdipwd1");
    	    conn.setAutoCommit(false);
    	    stmt = conn.createStatement();
    	    ResultSet rset = stmt.executeQuery(query);
    	    while (rset.next()) {
    	    	int colcount = rset.getMetaData().getColumnCount();
    	    	System.out.println(colcount);
    	    	for(int i=1;i<=colcount;i++){
    	    		String colname = rset.getMetaData().getColumnName(i);
    	    		String rowdata =rset.getString(i);
        	    	System.out.println(colname+": "+data);
        	    	metaData.put(colname, rowdata);     	    	
    	    	}   	    	 	    	
    	    }  	        	
    	    stmt.close();
    	    conn.close();
    	   	return metaData;
		} catch (Exception e) {
			Add_Log.info("Fail to fetch DB data");
			Reporter.log("Fail to fetch DB data");
			stmt.close();
			conn.close();
			TestResultStatus.Testfail=true;				
			Assert.fail();
			return null;
		}
    	
    }*/
    
    /*public ArrayList<String> getRowData(String query) throws SQLException{
    	ArrayList<String> arrayList = new ArrayList<String>(); 
    	Statement stmt = null;
    	Connection conn = null;
    	try {  
    		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());       	
    	    String url = "jdbc:oracle:thin:@vm-17fe-e158.nam.nsroot.net:1522:cloudapp";
    	    conn = DriverManager.getConnection(url,"rdip","rdipwd1");
    	    conn.setAutoCommit(false);
    	    stmt = conn.createStatement();
    	    ResultSet rset = stmt.executeQuery(query);
    	    int colcount = rset.getMetaData().getColumnCount();
	    	System.out.println(colcount);
	    	for(int i=1;i<=colcount;i++){    
	        	while(rset.next()){
	        		arrayList.add(rset.getString(i));
	        	}
	    	}
	        	stmt.close();
	        	conn.close();
		} catch (Exception e) {
			stmt.close();
        	conn.close();
        	TestResultStatus.Testfail=true;				
			Assert.fail();
			return null;
		}
    	
    	
    	return arrayList;
    }*/
    
    
    public void validateDBData(String excelHeader, String DBheader, HashMap<String, String> hash){
    	try {
    		System.out.println(excelHeader);
    		System.out.println(hash.get(DBheader).toString());
			if(excelHeader.equalsIgnoreCase(hash.get(DBheader).toString())){
				System.out.println("Correct data in DB");
				Reporter.log("Correct data in DB");
				Add_Log.info("Correct data in DB");
			}else{
				System.out.println("Incorrect data in DB");
				Reporter.log("Incorrect data in DB");
				Add_Log.info("Incorrect data in DB");
				seterror("Incorrect data in DB");
				TestResultStatus.Testfail=true;				
				Assert.fail();
			}
		} catch (Exception e) {
			Reporter.log("Not able to validate data in DB");
			Add_Log.info("Not able to validate data in DB");
			seterror("Not able to validate data in DB");
			TestResultStatus.Testfail=true;				
			Assert.fail();
		}
    }
    
    public boolean verifyTextpresent(WebDriver driver,String text){
    	
    	return driver.getPageSource().contains(text);
    	
    }
    
    public void validateSearchData(ArrayList<HashMap<String,Object>> abc, String data){
    	try {
    		String test = abc.get(0).toString();
			if(test.contains(data)){
				
				System.out.println("Correct data in DB");
				Reporter.log("Correct data in DB");
				Add_Log.info("Correct data in DB");
			}else{
				System.out.println("Incorrect data in DB");
				Reporter.log("Incorrect data in DB");
				Add_Log.info("Incorrect data in DB");
				seterror("Incorrect data in DB");
				TestResultStatus.Testfail=true;				
				Assert.fail();
			}
		} catch (Exception e) {
			Reporter.log("Not able to validate data in DB");
			Add_Log.info("Not able to validate data in DB");
			seterror("Not able to validate data in DB");
			TestResultStatus.Testfail=true;				
			Assert.fail();
		}
    }
    
    
   /* public ArrayList<HashMap<String,Object>> getRowData(String query) throws SQLException{
    	try {
    		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());       	
    	    String url = "jdbc:oracle:thin:@vm-17fe-e158.nam.nsroot.net:1522:cloudapp";
    	    Connection con = DriverManager.getConnection(url,"rdip","rdipwd1");
    	    //create statement
    	    Statement stm = null;
    	    stm = con.createStatement();

    	    //query
    	    ResultSet result = null;
    	    boolean returningRows = stm.execute(query);
    	    if (returningRows)
    	      result = stm.getResultSet();
    	    else
    	      return new ArrayList<HashMap<String,Object>>();

    	    //get metadata
    	    ResultSetMetaData meta = null;
    	    meta = result.getMetaData();

    	    //get column names
    	    int colCount = meta.getColumnCount();
    	    ArrayList<String> cols = new ArrayList<String>();
    	    for (int index=1; index<=colCount; index++)
    	      cols.add(meta.getColumnName(index));

    	    //fetch out rows
    	    ArrayList<HashMap<String,Object>> rows = new ArrayList<HashMap<String,Object>>();

    	    while (result.next()) {
    	      HashMap<String,Object> row = new HashMap<String,Object>();
    	      for (String colName:cols) {
    	        Object val = result.getObject(colName);
    	        row.put(colName,val);
    	      }
    	      rows.add(row);
    	    }

    	    //close statement
    	    stm.close();

    	    //pass back rows
    	    return rows;
    	  }
    	  catch (Exception ex) {
    	    System.out.print(ex.getMessage());
    	    return new ArrayList<HashMap<String,Object>>();
    	  }
    }*/
    
    
    
    public boolean getOptions_chk(WebDriver driver,WebPageElements ele, String exp_options ) {
    	
    	boolean result = false;
    	
    	try {			
    		List<WebElement> options;
			
			if(ele.getLocator().equalsIgnoreCase("xpath")){
				int count =0;
				int i=0;
				options = driver.findElements(By.xpath(ele.getValue()));
				String [] exp_viewname_option = exp_options.split(",");
				for(WebElement list1: options)
				{
	
					String act_option= list1.getText();
					if(exp_viewname_option[i].equals(act_option))
					{
						count++;
						i++;
						if(count==options.size())
						{
							result = true;
						}
					}
				}
				
			}
			}
	
			 catch (Exception e) {
			
				Add_Log.info("Not able get options "+ele.getName()+" element.");
				seterror("Not able get options "+ele.getName()+" element.");
				TestResultStatus.Testfail= true;
				Assert.fail();
			}			
						
		
		
    	return result;						
		
						
	}
    
    public void getUtilizationdata(WebDriver driver,WebPageElements ele) {
    
    	WebElement element1=null;
    	try {
    		if(ele.getLocator().equalsIgnoreCase("xpath"))
    		{
    			element1 = getWebElement(driver, ele);
    			element1.click();
    			
    			
    			
    		}
    		
    		
    		
			} catch (Exception e) {
			try {
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", ele);
			} catch (Exception e2) {
				Add_Log.info("Not able click "+ele.getName()+" element.");
				Reporter.log("Not able to click "+ele.getName()+" element.");
				seterror("Not able to click "+ele.getName()+" element.");
				TestResultStatus.Testfail= true;
				Assert.fail();
			}			
						
		}					
		
						
	}
    
public void sendKey_element(WebDriver driver,WebPageElements ele, String exp_input) {
	WebElement element1=null;
    	
    	try {
    		if(ele.getLocator().equalsIgnoreCase("xpath"))
    		{
    			element1=getWebElement(driver, ele);
    			element1.sendKeys(exp_input);
    			
  
    		}
    		
    		
    		
			} catch (Exception e) {
			try {
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].click();", ele);
			} catch (Exception e2) {
				Add_Log.info("Not able click "+ele.getName()+" element.");
				Reporter.log("Not able to click "+ele.getName()+" element.");	
				seterror("Not able to click "+ele.getName()+" element.");
				TestResultStatus.Testfail= true;
				Assert.fail();
			}			
						
		}					
		
						
	}



public int getWebElementSize(WebDriver driver,WebPageElements ele) {
	List<WebElement> element_list=null;
	int element_size = 0;
	
	try {
		if(ele.getLocator().equalsIgnoreCase("xpath"))
		{
			element_list= driver.findElements(By.xpath(ele.getValue()));
			element_size=element_list.size();	
			
		}else if(ele.getLocator().equalsIgnoreCase("id"))
    	{
			element_list= driver.findElements(By.id(ele.getValue())); 
			element_size=element_list.size();
			
    	}else if(ele.getLocator().equalsIgnoreCase("name"))
    	{
    		element_list= driver.findElements(By.name(ele.getValue())); 
    		element_size=element_list.size();
    		
    	}else if(ele.getLocator().equalsIgnoreCase("linktext"))
    	{
    		element_list = driver.findElements(By.linkText(ele.getValue()));
    		element_size=element_list.size();
    		
    	}else if(ele.getLocator().equalsIgnoreCase("partiallinktext"))
    	{
    		element_list = driver.findElements(By.partialLinkText(ele.getValue()));
    		element_size=element_list.size();
    		
    	}else if(ele.getLocator().equalsIgnoreCase("classname"))
    	{
    		element_list = driver.findElements(By.className(ele.getValue()));
    		element_size=element_list.size();
    		
    	}else if(ele.getLocator().equalsIgnoreCase("tagname"))
    	{
    		element_list = driver.findElements(By.tagName(ele.getValue()));
    		element_size=element_list.size();
    		
    	}else if(ele.getLocator().equalsIgnoreCase("css"))
    	{
    		element_list = driver.findElements(By.cssSelector(ele.getValue()));
    		element_size=element_list.size();
    	}
		
		
		
		} catch (Exception e) {
		try {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].click();", ele);
		} catch (Exception e2) {
			Add_Log.info("Not able click "+ele.getName()+" element.");
			Reporter.log("Not able to click "+ele.getName()+" element.");	
			seterror("Not able to click "+ele.getName()+" element.");
			TestResultStatus.Testfail= true;
			Assert.fail();
		}			
					
	}
	return element_size;					
	
					
}

  public void element_chk(WebDriver driver, WebPageElements ele)
  {
	
	  WebElement element=null;
	  try {
		  waitForElementPresent(driver, 60, ele);
		  
		  element=getWebElement(driver, ele);
		 
		  if(element.isDisplayed())
		  {
			  if(element.isEnabled())
			  {
				  element_Exit="Pass";
			  }
		  }
		  else{
			  TestResultStatus.Testfail=true;
			  Assert.fail();
		  }
  		
		} catch (Exception e) {
			Reporter.log("Not able to find "+ele.getName()+" element");
			Add_Log.info("Not able to find "+ele.getName()+" element");
			seterror("Not able to find "+ele.getName()+" element");
			TestResultStatus.Testfail=true;				
			Assert.fail();
		}
	  
  }
  
  

  
  
  public String[] str_split(String str)
  {
	  String arrStr[]=str.split(",");
	return arrStr;
	  
  }
  
  public void switchToTab(WebDriver driver, WebPageElements element) throws InterruptedException{
		String parent = driver.getWindowHandle();
		click(driver, element);
		Thread.sleep(3000);
		for (String handle : driver.getWindowHandles()) {
			if(!handle.equals(parent)){
				driver.switchTo().window(handle);													
			}
		}
  }

  public void waitForElementInvisibilty(WebDriver driver, int seconds, final WebPageElements ele){
	   try {
		   WebDriverWait wait = new WebDriverWait(driver, seconds);
		   if(ele.getLocator().equalsIgnoreCase("xpath")){
			   wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("id")){
			   wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("linktext")){
			   wait.until(ExpectedConditions.invisibilityOfElementLocated(By.linkText(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("name")){
			   wait.until(ExpectedConditions.invisibilityOfElementLocated(By.name(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("classname")){
			   wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className(ele.getValue())));
		   }else if(ele.getLocator().equalsIgnoreCase("css")){
			   wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector(ele.getValue())));
		   }
		   
		   
		   /*FluentWait<WebDriver> fWait = new FluentWait<WebDriver>(driver).withTimeout(seconds, TimeUnit.SECONDS)
			        .pollingEvery(3, TimeUnit.SECONDS)
			        .ignoring(NoSuchElementException.class);
		   fWait.until(ExpectedConditions.visibilityOf(getWebElement(driver, ele)));*/

		   
	} catch (Exception e) {
		Add_Log.info(ele.getName()+" not present on page");
		Reporter.log(ele.getName()+" not present on page");
		seterror(ele.getName()+" not present on page");
		TestResultStatus.Testfail= true;
		Assert.fail();
		}
	}
    
    
    
    
    
}
    
    
    
    
    
    
    
    




package testcases;

import java.awt.AWTException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.LinkedHashMap;


import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import testsuitebase.SuiteBase;
import testsuitebase.TestResultStatus;
import utility.AutoScreen;
import utility.ExtentManager;
import utility.Read_XLS;
import utility.SuiteUtility;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.model.ScreenCapture;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ABSLI_Flow extends SuiteBase {
	// private static final String WebDriver = null;

	static ExtentHtmlReporter htmlReporter;
	static ExtentReports extent;
	public static ExtentTest Elogger;
	public static ScreenCapture screenCapture;
	public static AutoScreen screenshotTaker = new AutoScreen();
	public static String ErrorMsg=null;
	
	Read_XLS FilePath = null;
	String TestCaseName = null;
	// String SheetName = "search";
	String SheetName = "Smoke_Test";
	String ResultSheetName = "Result";
	public boolean TestCasePass = true;
	public int DataSet = -1;
	public DecimalFormat df = new DecimalFormat("#.##");

	public boolean Testskip = false;
	public boolean Testfail = false;
	SoftAssert s_assert = null;
	public double finish, start;
	public double end;
	public double totalTime;

	@BeforeClass
	public void setUp() throws IOException {
		init();
		FilePath = TestCaseListExcelsearchContains;
		URLs = TestCaseListExcelsearchContains.getEnvUrl("Environment");
		System.out.println(URLs.size());
		//loadWebBrowser();
		extent = ExtentManager.GetExtent();
		screenCapture = new ScreenCapture();
		// Extent Report Initialize;
	}

	@Test(priority = 1, dataProvider = "Smoke", dataProviderClass = utility.Xlsdataprovider.class)
	public void Smoke_TC1(LinkedHashMap<String, String> data) throws InterruptedException, SQLException, AWTException {

		DataSet++;

		TestCaseName = getData(data, "TestCaseName");
		CaseToRun = getData(data, "CaseToRun");

		String sumassured = getData(data, "SumAssured");
		String aadharNumber = getData(data, "AadharNumber");
		String fatherSpouseName = getData(data, "FatherSpouseName");
		String birthState = getData(data, "BirthState");
		String birthCity = getData(data, "BirthCity");
		String address = getData(data, "Address");
		String pin = getData(data, "Pin");
		String emailid = getData(data, "EmailId");
		String city = getData(data, "City");
		String mobileno = getData(data, "MobileNumber");
		String employername = getData(data, "EmployerName");
		String designation = getData(data, "Designation");
		String natureofduties = getData(data, "NatureOfDuties");
		String expyears = getData(data, "ExpYears");
		String annualincome = getData(data, "AnnualIncome");
		String nomineefirstname = getData(data, "NomineeFirstName");
		String nomineelastname = getData(data, "NomineeLastName");
		String nomineedob = getData(data, "NomineeDOB");
		String nominationshare = getData(data, "NominationShare");
		String accountholdername = getData(data, "AccountHolderName");
		String accountnumber = getData(data, "AccountNumber");
		String height = getData(data, "Height");
		String heightinch = getData(data, "HeightInch");
		String weight = getData(data, "Weight");
		String fatherage = getData(data, "FatherAge");
		String motherage = getData(data, "MotherAge");
		String applicationplace = getData(data, "ApplicationPlace");
		String pandetails = getData(data, "PanDetails");
		
		
		//String exp_option = getData(data, "ExpectedOptions");
		//String dd_selector = getData(data, "DropDownSelector");
		Elogger = extent.createTest(TestCaseName);
		screenCapture.setName(TestCaseName);
		// Set testCase Name In Extent Report
		String Role = getData(data, "Role");

		if (CaseToRun.equalsIgnoreCase("N")) {
			System.out.println(TestCaseName + " : CaseToRun = N for So Skipping Execution.");
			Testskip = true;
			//Elogger.log(Status.SKIP, TestCaseName+" is skipped");
			throw new SkipException(
					TestCaseName + "'s CaseToRun Flag Is 'N' Or Blank. So Skipping Execution Of " + TestCaseName);
		} else {
			// loadWebBrowser();
			for (String Key : URLs.keySet()) {
				System.out.println(URLs.get(Key));
				credentials = TestCaseListExcelsearchContains.getLoginCredentials("Users", Role);
				for (int j = 0; j < credentials.size(); j++) {
					users = credentials.get(j);
					System.out.println(users.get("username"));
					System.out.println(users.get("password"));
					username = users.get("username");
					password = users.get("password");
				}
				loadWebBrowser();
				driver.get(URLs.get(Key));
				start = System.currentTimeMillis();
				absliPage.insurerProposerSameFlow(driver,sumassured,aadharNumber,fatherSpouseName,birthState,birthCity,pandetails,address,pin,emailid,city,mobileno,
						employername,designation,natureofduties,expyears,annualincome,nomineefirstname,nomineelastname,nomineedob,nominationshare,accountholdername
						,accountnumber,height,heightinch,weight,fatherage,motherage,applicationplace);
				
				
				end = System.currentTimeMillis();
				System.out.println("Took: " + ((end - start) / 1000000) + "ms");
				totalTime = (end - start) / 1000;
				String totaltime = df.format(totalTime);
				if (Key.equalsIgnoreCase("UAT")) {
					SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_UAT", DataSet + 1, totaltime);
				} else if (Key.equalsIgnoreCase("PROD")) {
					SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_PROD", DataSet + 1, totaltime);
				} else if (Key.equalsIgnoreCase("SIT")) {
					SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_SIT", DataSet + 1, totaltime);
				}
				if (URLs.size() > 0) {
					driver.manage().deleteAllCookies();
					driver.navigate().refresh();
				}

			}
		}
	}
	


	@AfterMethod
	public void reporterDataResults(ITestResult Result) throws IOException, InterruptedException {
		Testfail = TestResultStatus.Testfail;
		
		ErrorMsg = TestResultStatus.Errormsg;
		// Reporter.log(ele.getName() + " not present on page");
		/*screenCapture.setPath(screenshotTaker.getscreenshot(driver,
						TestCaseName));
		// take a ScreenShot And Store It.
		Elogger.log(Status.FAIL,ErrorMsg, new MediaEntityModelProvider(
						screenCapture));*/
		// Fail The Test Show Message With ScreenShot.
		System.out.println("test fail flag in AfterMethod: " + Testfail);
		if (Testskip) {
			ErrorMsg = TestCaseName+" is Skipped";
			Elogger.log(Status.SKIP,ErrorMsg);
			String str = "0";
			totalTime = 0;
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_UAT", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_PROD", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_SIT", DataSet + 1, str);
			Add_Log.info(TestCaseName + " : Reporting test data set line " + (DataSet + 1) + " as SKIP In excel.");
			// If found Testskip = true, Result will be reported as SKIP against
			// data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", DataSet + 1, "SKIP");

		} else if (Testfail) {
			Add_Log.info(TestCaseName + " : Reporting test data set line " + (DataSet + 1) + " as FAIL In excel.");
			// To make object reference null after reporting In report.
			screenCapture.setPath(screenshotTaker.getscreenshot(driver,
					TestCaseName));
			// take a ScreenShot And Store It.
			Elogger.log(Status.FAIL,ErrorMsg, new MediaEntityModelProvider(
					screenCapture));
			if (!(driver == null)) {
				closeWebBrowser();
			}

			String str = "0";
			totalTime = 0;
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_UAT", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_PROD", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_SIT", DataSet + 1, str);
			TestCasePass = false;
			// If found Testfail = true, Result will be reported as FAIL against
			// data set line In excel sheet.

			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", DataSet + 1, "FAIL");

			// driver.manage().deleteAllCookies();
			// driver.close();
			// Reporter.log(Result.getMethod().getMethodName()+" failed.");

		} else {
			screenCapture.setPath(screenshotTaker.getscreenshot(driver,
					TestCaseName));
			// take a ScreenShot And Store It.
			ErrorMsg = TestCaseName+"is Successfully Pass";
			Elogger.log(Status.PASS,ErrorMsg);
			if (!(driver == null)) {
				closeWebBrowser();
			}

			System.out.println(df.format(totalTime));
			System.out.println("Total Time for page load - " + totalTime);

			Add_Log.info(TestCaseName + " : Reporting test data set line " + (DataSet + 1) + " as PASS In excel.");
			// If found Testskip = false and Testfail = false, Result will be
			// reported as PASS against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", DataSet + 1, "PASS");
			// driver.manage().deleteAllCookies();
			// driver.close();

		}
		// At last make both flags as false for next data set.

		Testskip = false;
		TestResultStatus.Testfail = false;
		// driver.close();

	}
	@AfterSuite
	public void endreport() {
		extent.flush();

		// Extent report End
	}
	/*
	 * @AfterTest public void testUp() { driver.close(); driver.quit(); }
	 */
	/*@AfterSuite
	public void aftersuite() {
		cpyExcel.copyXlsFiles();
	}*/
}

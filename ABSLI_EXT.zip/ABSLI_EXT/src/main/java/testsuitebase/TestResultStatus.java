package testsuitebase;

public class TestResultStatus {
	public static boolean Testfail=false;
	public static String Errormsg = null;
}

package property;

public interface IABSLI {

	//Home Page
	String TXTBOX_FIRSTNAME_PROPOSERDETAILS = "//input[@id='proFirstName']";
	String TXTBOX_LASTNAME_PROPOSERDETAILS = "//input[@id='proLastName']";
	String DOB_PROPOSERDETAILS = "//input[@id='proDOB']";
	//String AGE_PROSPERDETAILS = "//input[@id='proAge']";
	String IMAGE_MALEGENDER_PROPOSERDETAILS = "//img[@id='genderMaleImg']";
	String CHB_LIFE_TO_BE_INSURED_PROPOSER = "//input[@id='iChampHomeLifeInsuredToggle']";
	String BTN_SUGGESTPLAN = "//a[text()='Suggest Plan']";
	String DDL_SELECT_MENU_SAVING_WITH_PROTECTION_PLAN = "//h3[text()='Saving with Protection']/following-sibling::div[2]/select[@class='planSelectorDDCommon']";
	String DDL_VALUE_BSLI_VISION_ENDOWMENT_PLUS = "//option[text()='BSLI Vision Endowment Plus']";
	String BTN_NEXT_PROPOSERDETAILS = "//a[text()='Next']";
	String TXT_PROPOSER_STATE = "//input[@id='propState']";
	String TAB_RIDERS = "//span[text()='Riders']";
	String CHB_SELECTALL_RIDERS_TAB = "//input[@id='selectAll']";
	String CHB_ACCIDENTAL_DEATH_AND_DISABILITY_RIDERS_TAB = "//input[@data-id='txtADD']";
	String INPUT_SUM_ASSURED_ACCIDENTAL_DEATH_AND_DISABILITY = "//input[@id='txtADD']";
	String BTN_CALCULATE_PREMIUM = "//a[text()='Calculate Premium']";
	String BTN_GENERATE_ILLUSTRATION = "//a[text()='Generate Illustration']";
	String BTN_BUY_NOW = "//a[text()='Buy Now']";
	String BTN_PROCEED = "//a[text()='Proceed']";
	
	//Basic Details
	String INPUT_BASICDETAILS_AADHARNUMBER = "//input[@id='insUID']";
	String BTN_CONFIRM  = "//a[text()='Confirm']";
	String INPUT_FATHER_SPOUSE_NAME_BASIC_DETAILS = "//input[@id='insFatherName']";
	String INPUT_BIRTH_STATE_BASIC_DETAILS = "//input[@id='insBirthState']";
	String INPUT_BIRTH_CITY_BASIC_DETAILS = "//input[@id='insBirthCity']";
	String DDL_MARITAL_STATUS_BASIC_DETAILS = "//select[@id='insMaritalStatus']";
	String DDL_VALUE_MARITAL_STATUS_SINGLE_BASIC_DETAILS = "//option[text()='Single']";
	String TOGGLE_BTN_CITIZENSHIP_BASIC_DETAILS = "//p[text()='Are you holding citizenship of any other country?']/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_BTN_TAX_RESIDENT_BASIC_DETAILS = "//p[text()='Are you tax resident of any other country?']/following-sibling::div/descendant::span[text()='N']";
	String TXT_PERSONAL_DETAILS_BASIC_DETAILS = "//div[text()='Personal Details ']";
	String TXT_PROFESSIONAL_DETAILS_BASIC_DETAILS = "//div[text()='Professional Details ']";
	String INPUT_PAN_PROFESSIONAL_DETAILS = "//input[@id='propPAN']";
	String BTN_VALIDATE_FOR_PAN = "//a[text()='Validate']";
	String TXT_FISRT_LAST_NOT_MATCHING = "//p[text()='First name/Last name mismatched. You will have to upload PAN card proof.']";
	String BTN_CLOSE = "//button[text()='Close']";
	String TXT_COMMUNICATION_ADDRESS_BASIC_DETAILS = "//div[text()='Communication Address ']";
	String TXT_EIA_DETAILS_BASIC_DETAILS = "//div[text()='EIA Details ']";
	String TXT_OTHER_DETAILS_BASIC_DETAILS = "//div[text()='Other Details']";
	String DDL_QUALIFICATION_BASIC_DETAILS = "//select[@id='propQualification']";
	String DDL_QUALIFICATION_VALUE_PROFESSIONAL_BASIC_DETAILS = "(//option[text()='Professional'])[1]";
	String DDL_OCCUPATION_BASIC_DETAILS = "//select[@id='propOccupation']";
	String DDL_OCCUPATION_VALUE_SERVICE_BASIC_DETAILS = "//option[text()='Service']";
	String INPUT_NAME_OF_EMPLOYER_PROFESSIONAL_BASIC_DETAILS = "(//input[@id='propNameOfEmployer'])[2]";
	String INPUT_DESIGNATION_PROFESSIONAL_BASIC_DETAILS = "(//input[@id='propDesignation'])[1]";
	String DDL_ORGANIZATION_TYPE_PROFESSIONAL_BASIC_DETAILS = "(//select[@id='propTypeOrg'])[2]";
	String DDL_ORGANIZATION_VALUE_PRIVATE_PROFESSIONAL_BASIC_DETAILS = "(//option[text()='Private Ltd.'])[2]";
	String INPUT_NATURE_OF_DUTIES_PROFESSIONAL_DETAILS = "(//input[@id='propNatureDuties'])[1]";
	String INPUT_YEARS_WITH_EXPERIENCE_PROFESSIONAL_DETAILS = "(//input[@id='propExperience'])[2]";
	String INPUT_ANNUAL_INCOME_PROFESSIONAL_DETAILS = "(//input[@id='propAnnualIncome'])[2]";
	String ADDRESS1_COMMUNICATION_ADDRESS_BASIC_DETAILS = "//input[@id='insComAddr1']";
	String INPUT_CITY_COMMUNICATION_ADDRESS_BASIC_DETAILS = "//input[@id='insCommCity']";
	String INPUT_PIN_COMMUNICATION_ADDRESS_BASIC_DETAILS = "//input[@id='insComPIN']";
	String INPUT_MOBILE_COMMUNICATION_ADDRESS_BASIC_DETAILS = "//input[@id='insComMobNo']";
	String INPUT_EMAIL_COMMUNICATION_ADDRESS_BASIC_DETAILS = "//input[@id='propComEmail']";
	String TOGGLE_POLICY_DOCUMENT_N_BASIC_DETAILS = "//P[text()='I request you to send my policy documents in electronic form at above email id']/following-sibling::div/descendant::span[text()='N']";
	String RB_EIA_DETAILS_NO_VALUE_BASIC_DETAILS = "//P[text()='Do you have an EIA Account?']/following-sibling::label[text()='No']";
	String TOGGLE_OTHER_DETAILS_PEP_N_VALUE_BASIC_DETAILS = "//p[text()='PEP - State whether the Proposer or the Life to be Insured or Nominee are Politically Exposed Person']/following-sibling::div/descendant::span[text()='N']";
	String RB_OTHER_DETAILS_SAVINGS_BASIC_DETAILS = "//div[text()='PURPOSE of INSURANCE']/following-sibling::div/label[text()='Savings']";
	String INPUT_NOMINEE_FIRST_NAME_BASIC_DETAILS = "//input[@id='nomineeFName']";
	String INPUT_NOMINEE_LAST_NAME_BASIC_DETAILS = "//input[@id='nomineeLName']";
	String NOMINEE_DOB_BASIC_DETAILS = "//input[@id='nomineeDOB']";
	String DDL_RELATIONSHIP_WITH_LI_NOMINEE_BASIC_DETAILS = "//select[@id='nomineeReltn']";
	String DDL_RELATIONSHIP_WITH_LI_VALUE_PARENT_NOMINEE_BASIC_DETAILS = "//option[text()='Parent']";
	String INPUT_NOMINATION_SHARE_BASIC_DETAILS = "//input[@id='nomineeShare']";
	String BTN_ADD_NOMINEE_BASIC_DETAILS = "//input[@id='nomineeContact']/../../following-sibling::div/span/img";
	
	//Payment
	String BTN_SUBMIT_PAYMENT = "(//a[text()='Submit'])[1]";
	
	//Gateway
	String TXT_DUMMY_PAYMENT_OPTION = "//span[text()='Dummy Payment Option']";
	String CHB_POLICY_AGREEMENT_CHECKBOX = "//input[@type='checkbox']";
	String BTN_SUBMIT_PAYMENT_GATEWAY = "//input[@type='checkbox']/../../following-sibling::tr/td/input";
	String BTN_PAYNOW_PAYMENT_GATEWAY = "//input[@value='PayNow']";
	String BTN_CONTINUE_FILLING_CUSTOMER_DETAILS_NOW = "//button[text()='Yes, I will continue filling Customer details now']";

	//Prev. policy details
	String TOGGLE_PREV_POLICY_DETAILS_N_OPTION = "//p[text()='Is there any concurrent application and/or any existing insurance on your life for Life / Health / Accident / Critical Illness or other riders in effect with ABSLI or any other insurer in India or abroad? If Yes, give details.']/following-sibling::div/descendant::span[text()='N']";
	String TXT_REFUSED_WITHDRAWN_PREV_POLICY_DETAILS = "//div[text()='Refused, Withdrawn, Declined, Postponed Policies']";
	String TOGGLE_REFUSED_WITHDRAWN_PREV_POLICY_DETAILS_N_OPTION = "//p[contains(text(),'Have you ever had an application for life, accident, medical, health-related insurance or riders refused, withdrawn,')]/following-sibling::div/descendant::span[text()='N']";
	
	//Policy Payout Details
	String INPUT_PAYOUT_ACCOUNT_HOLDERS_NAME = "//input[@id='payOutAccountHolder']";
	String INPUT_PAYOUT_ACCOUNT_NUMBER = "//input[@id='payOutAccountNo']";
	String RB_ACCOUNT_TYPE_SAVING = "//label[text()='Savings']";
	String TXT_RENEWAL_PREMIUM_PAYMENT_DETAILS = "//div[text()='Renewal Premium Payment Details']";
	String RB_DIRECT_BILL_RENEWAL_PREMIUM = "//label[text()='Direct Bill']";
	
	//customer health details
	String INPUT_HEIGHT_HEALTH_DETAILS = "//input[@placeholder='Feet']";
	String INPUT_HEIGHT_INCH_HEALTH_DETAILS = "//input[@id='heightIn']";
	String INPUT_WEIGHT_HEALTH_DETAILS = "//input[@id='weight']";
	String TOGGLE_WEIGHT_CHANGE_QUESTION = "//p[contains(text(),'Is there any weight change')]/following-sibling::div/descendant::span[text()='N']";
	String TXT_LIFE_STYLE_INFORMATION = "//div[text()='Life Style Information']";
	String TOGGLE_QUESTION_LIVE_TRAVEL_OUTSIDE_INDIA_N_OPTION = "//p[contains(text(),'Do You Intend to live or travel outside India')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_HAZARDOUS_OCCUPATION_N_OPTION = "//p[contains(text(),'hazardous occupation')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_NARCOTIC_SUBSTANCE_N_OPTION = "//p[contains(text(),'narcotic substance')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_CONSUME_ALCOHOL_N_OPTION = "//p[contains(text(),'consume alcohol')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_TOBACCO_NICOTINE_PRODUCTS_N_OPTION = "//p[contains(text(),'tobacco/nicotine products')]/following-sibling::div/descendant::span[text()='N']";
	String TXT_FAMILY_MEDICAL_HISTORY = "//div[text()='Family Medical History']";
	String CHB_NONE_FAMILY_MEDICAL_HISTORY = "//label[text()='None']";
	String INPUT_FATHERAGE_FAMILY_MEDICAL_HISTORY = "//input[@id='familyFatherAge']";
	String INPUT_MOTHERAGE_FAMILY_MEDICAL_HISTORY = "//input[@id='familyMotherAge']";
	String DDL_FATHER_STATE_OF_HEALTH = "//select[@id='familyFatherAgestat']";
	String DDL_FATHER_STATE_OF_HEALTH_OPTION_OK_GOOD = "//select[@id='familyFatherAgestat']/option[text()='Ok/Good']";
	String DDL_MOTHER_STATE_OF_HEALTH_OPTION_OK_GOOD = "//select[@id='familyMotherAgestat']/option[text()='Ok/Good']";
	String DDL_MOTHER_STATE_OF_HEALTH = "//select[@id='familyMotherAgestat']";
	String TOGGLE_NO_OF_BROTHERS = "//div[text()='Do you have brother(s)']/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_NO_OF_SISTERS = "//div[text()='Do you have sister(s)']/following-sibling::div/descendant::span[text()='N']";
	String TXT_MEDICAL_HISTORY = "//div[text()='Medical History']";
	String TOGGLE_REMAIN_ABSENT_MEDICAL_HISTORY_N_OPTION = "//p[contains(text(),'Have you remained absent from place of work on grounds of health')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_SURGICAL_OPERATION_N_OPTION = "//p[contains(text(),'have you ever undergone any surgical operation')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_DIET_N_OPTION = "//p[contains(text(),'diet or any other medicine')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_UNDERGO_ANY_TREATMENT_N_OPTION = "//p[contains(text(),'undergo any treatment?')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_SURGICAL_OPERATION_PROCEDURE_OPTION_N = "//p[contains(text(),'surgical operation, procedure or hospital admission?')]/following-sibling::div/descendant::span[text()='N']";
	String CHB_SOUGHT_ADVICE_MEDICAL_HISTORY = "//label[text()='No I Have never sought advice or suffered from any of the above?']";
	String TOGGLE_QUESTION_PHYSICAL_DEFECTS_OPTION_N = "//p[contains(text(),'Do you have any physical defects,')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_HIV_OPTION_N = "//p[contains(text(),'HIV Infection / AIDS?')]/following-sibling::div/descendant::span[text()='N']";
	String TOGGLE_QUESTION_HEALTH_SYMPTOMS = "//p[contains(text(),'health symptoms or complaints')]/following-sibling::div/descendant::span[text()='N']";
	
	//Review & Acceptance
	String TXT_REVIEW_AND_ACCEPTANCE = "//a[text()='Reviewed and Accepted']";
	String TXT_PLACE_OF_APPLICATION = "//input[@id='applicationPlace']";
}

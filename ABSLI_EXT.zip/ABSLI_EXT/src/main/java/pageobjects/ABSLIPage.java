package pageobjects;



import java.awt.*;


import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import org.testng.Assert;
import org.testng.Reporter;



import property.IABSLI;
import testsuitebase.TestResultStatus;

import utility.SeleniumUtils;

import utility.WebPageElements;

public class ABSLIPage extends SeleniumUtils implements IABSLI {

	WebPageElements txtbox_fisrtname_proposerdetails = new WebPageElements("First Name Proposer Details", "xpath", TXTBOX_FIRSTNAME_PROPOSERDETAILS);
	WebPageElements txtbox_lastname_proposerdetails = new WebPageElements("Last Name Proposer Details", "xpath", TXTBOX_LASTNAME_PROPOSERDETAILS);
	WebPageElements dob_proposerdetails = new WebPageElements("DOB Proposer Details", "xpath", DOB_PROPOSERDETAILS);
	WebPageElements image_malegender_proposerdetails = new WebPageElements("Image of Male Gender Proposer Details", "xpath", IMAGE_MALEGENDER_PROPOSERDETAILS);
	WebPageElements chb_life_to_be_insured_proposer = new WebPageElements("Life to be insured proposer checkbox", "xpath", CHB_LIFE_TO_BE_INSURED_PROPOSER);
	WebPageElements btn_suggestplan = new WebPageElements("Suggest Plan Button", "xpath", BTN_SUGGESTPLAN);
	WebPageElements ddl_select_menu_saving_with_protection_plan = new WebPageElements("Dropdown to select plan under saving with protection plan", "xpath", DDL_SELECT_MENU_SAVING_WITH_PROTECTION_PLAN);
	WebPageElements ddl_value_bsli_vision_endowment_plus = new WebPageElements("bsli_vision_endowment_plus plan under saving with protection plan", "xpath", DDL_VALUE_BSLI_VISION_ENDOWMENT_PLUS);
	WebPageElements btn_next_proposerdetails = new WebPageElements("Next button on home page", "xpath", BTN_NEXT_PROPOSERDETAILS);
	WebPageElements txt_proposer_state = new WebPageElements("Proposer State field", "xpath", TXT_PROPOSER_STATE);
	WebPageElements tab_riders = new WebPageElements("Riders Tab", "xpath", TAB_RIDERS);
	WebPageElements chb_selectall_riders_tab = new WebPageElements("Select all Riders Tab", "xpath", CHB_SELECTALL_RIDERS_TAB);
	WebPageElements chb_accidental_death_and_disability_riders_tab = new WebPageElements("Accidental Death and Disability checkbox under riders tab", "xpath", CHB_ACCIDENTAL_DEATH_AND_DISABILITY_RIDERS_TAB);
	WebPageElements input_sum_assured_accidental_death_and_disability = new WebPageElements("Accidental Death and Disability checkbox under riders tab", "xpath", INPUT_SUM_ASSURED_ACCIDENTAL_DEATH_AND_DISABILITY);
	WebPageElements btn_calculate_premium = new WebPageElements("Button calculate premium", "xpath", BTN_CALCULATE_PREMIUM);
	WebPageElements btn_generate_illustration = new WebPageElements("Button generate illustration", "xpath", BTN_GENERATE_ILLUSTRATION);
	WebPageElements btn_buy_now = new WebPageElements("Button generate illustration", "xpath", BTN_BUY_NOW);
	WebPageElements btn_proceed = new WebPageElements("Button generate illustration", "xpath", BTN_PROCEED);
	WebPageElements input_basicdetails_aadharnumber = new WebPageElements("Aadhar Number basic details", "xpath", INPUT_BASICDETAILS_AADHARNUMBER);
	WebPageElements input_father_spouse_name_basic_details = new WebPageElements("Father/Spouse Name Basic Details", "xpath", INPUT_FATHER_SPOUSE_NAME_BASIC_DETAILS);
	WebPageElements btn_confirm = new WebPageElements("Confirm Button", "xpath", BTN_CONFIRM);
	WebPageElements input_birth_state_basic_details = new WebPageElements("Birth State under basic details", "xpath", INPUT_BIRTH_STATE_BASIC_DETAILS);
	WebPageElements input_birth_city_basic_details = new WebPageElements("Birth City field under basic details", "xpath", INPUT_BIRTH_CITY_BASIC_DETAILS);
	WebPageElements ddl_value_marital_status_single_basic_details = new WebPageElements("Birth City field under basic details", "xpath", DDL_VALUE_MARITAL_STATUS_SINGLE_BASIC_DETAILS);
	WebPageElements ddl_marital_status_basic_details = new WebPageElements("Marital Stauts basic details", "xpath", DDL_MARITAL_STATUS_BASIC_DETAILS);
	WebPageElements toggle_btn_citizenship_basic_details = new WebPageElements("Toggle Button for Citizenship question under basic details", "xpath", TOGGLE_BTN_CITIZENSHIP_BASIC_DETAILS);
	WebPageElements toggle_btn_tax_resident_basic_details = new WebPageElements("Toggle button for tax resident question under basic details", "xpath", TOGGLE_BTN_TAX_RESIDENT_BASIC_DETAILS);
	WebPageElements txt_personal_details_basic_details = new WebPageElements("Personal details txt under basic details", "xpath", TXT_PERSONAL_DETAILS_BASIC_DETAILS);
	WebPageElements txt_professional_details_basic_details = new WebPageElements("Professional details txt under basic details", "xpath", TXT_PROFESSIONAL_DETAILS_BASIC_DETAILS);
	WebPageElements txt_communication_address_basic_details = new WebPageElements("Communication Address txt under basic details", "xpath", TXT_COMMUNICATION_ADDRESS_BASIC_DETAILS);
	WebPageElements txt_eia_details_basic_details = new WebPageElements("EIA details txt under basic details", "xpath", TXT_EIA_DETAILS_BASIC_DETAILS);
	WebPageElements txt_other_details_basic_details = new WebPageElements("Other details txt under basic details", "xpath", TXT_OTHER_DETAILS_BASIC_DETAILS);
	WebPageElements ddl_qualification_basic_details = new WebPageElements("Qualification drop down basic details", "xpath", DDL_QUALIFICATION_BASIC_DETAILS);
	WebPageElements ddl_qualification_value_professional_basic_details = new WebPageElements("Qualification value as professional in basic details", "xpath", DDL_QUALIFICATION_VALUE_PROFESSIONAL_BASIC_DETAILS);
	WebPageElements ddl_occupation_basic_details = new WebPageElements("Occupation dropdown basic details", "xpath", DDL_OCCUPATION_BASIC_DETAILS);
	WebPageElements ddl_occupation_value_service_basic_details = new WebPageElements("Occupation value as service from dropdown basic details", "xpath", DDL_OCCUPATION_VALUE_SERVICE_BASIC_DETAILS);
	WebPageElements input_pan_professional_details = new WebPageElements("PAN Field under professional details", "xpath", INPUT_PAN_PROFESSIONAL_DETAILS);
	WebPageElements btn_validate_for_pan = new WebPageElements("PAN Validation Button", "xpath", BTN_VALIDATE_FOR_PAN);
	WebPageElements txt_first_last_not_matching = new WebPageElements("First Last name not matching", "xpath", TXT_FISRT_LAST_NOT_MATCHING);
	WebPageElements btn_close = new WebPageElements("Close Button", "xpath", BTN_CLOSE);
	WebPageElements input_name_of_employer_professional_basic_details = new WebPageElements("Name of Employer_professional_basic details", "xpath", INPUT_NAME_OF_EMPLOYER_PROFESSIONAL_BASIC_DETAILS);
	WebPageElements input_designation_professional_basic_details = new WebPageElements("Designation_professional_basic details", "xpath", INPUT_DESIGNATION_PROFESSIONAL_BASIC_DETAILS);
	WebPageElements ddl_organization_type_professional_basic_details = new WebPageElements("organisational_type_ddl_professional_basic details", "xpath", DDL_ORGANIZATION_TYPE_PROFESSIONAL_BASIC_DETAILS);
	WebPageElements ddl_organization_value_private_professional_basic_details = new WebPageElements("organisation_type_private_professional_basic details", "xpath", DDL_ORGANIZATION_VALUE_PRIVATE_PROFESSIONAL_BASIC_DETAILS);
	WebPageElements input_nature_of_duties_professional_details = new WebPageElements("Nature_of_duties_professional_basic_details", "xpath", INPUT_NATURE_OF_DUTIES_PROFESSIONAL_DETAILS);
	WebPageElements input_years_with_experience_professional_details = new WebPageElements("years_with_experience_professional_basic_details", "xpath", INPUT_YEARS_WITH_EXPERIENCE_PROFESSIONAL_DETAILS);
	WebPageElements input_annual_income_professional_details = new WebPageElements("Annual_income_professional_basic_details", "xpath", INPUT_ANNUAL_INCOME_PROFESSIONAL_DETAILS);
	
	
	
	WebPageElements address1_communication_address_basic_details = new WebPageElements("address1 field in communication address basic details", "xpath", ADDRESS1_COMMUNICATION_ADDRESS_BASIC_DETAILS);
	WebPageElements input_city_communication_address_basic_details = new WebPageElements("City field under communication address basic details", "xpath", INPUT_CITY_COMMUNICATION_ADDRESS_BASIC_DETAILS);
	WebPageElements input_pin_communication_address_basic_details = new WebPageElements("input pin field under communication address basic details", "xpath", INPUT_PIN_COMMUNICATION_ADDRESS_BASIC_DETAILS);
	WebPageElements input_mobile_communication_address_basic_details = new WebPageElements("Mobile no under communication address basic details", "xpath", INPUT_MOBILE_COMMUNICATION_ADDRESS_BASIC_DETAILS);
	WebPageElements input_email_communication_address_basic_details = new WebPageElements("Email communication address under basic details", "xpath", INPUT_EMAIL_COMMUNICATION_ADDRESS_BASIC_DETAILS);
	WebPageElements toggle_policy_document_N_basic_details = new WebPageElements("N to policy Doucment question under basic details", "xpath", TOGGLE_POLICY_DOCUMENT_N_BASIC_DETAILS);
	WebPageElements rb_eia_details_no_value_basic_details = new WebPageElements("Radio button No under EIA details basic details", "xpath", RB_EIA_DETAILS_NO_VALUE_BASIC_DETAILS);
	WebPageElements toggle_other_details_pep_n_value_basic_details = new WebPageElements("Toggle No value under other details under basic details", "xpath", TOGGLE_OTHER_DETAILS_PEP_N_VALUE_BASIC_DETAILS);
	WebPageElements rb_other_details_savings_basic_details = new WebPageElements("Radio button savings under other details basic details", "xpath", RB_OTHER_DETAILS_SAVINGS_BASIC_DETAILS);
	WebPageElements input_nominee_first_name_basic_details = new WebPageElements("Nominee first name under basic details", "xpath", INPUT_NOMINEE_FIRST_NAME_BASIC_DETAILS);
	WebPageElements input_nominee_last_name_basic_details = new WebPageElements("Nominee last name under basic details", "xpath", INPUT_NOMINEE_LAST_NAME_BASIC_DETAILS);
	WebPageElements nominee_dob_basic_details = new WebPageElements("Nominee DOB under basic details", "xpath", NOMINEE_DOB_BASIC_DETAILS);
	WebPageElements ddl_relationship_with_li_nominee_basic_details = new WebPageElements("Relationship with LI under nominee under basic details", "xpath", DDL_RELATIONSHIP_WITH_LI_NOMINEE_BASIC_DETAILS);
	WebPageElements ddl_relationship_with_li_value_parent_nominee_basic_details = new WebPageElements("Relationship with LI with value=Parent under nominee under basic details", "xpath", DDL_RELATIONSHIP_WITH_LI_VALUE_PARENT_NOMINEE_BASIC_DETAILS);
	WebPageElements input_nomination_share_basic_details = new WebPageElements("Nomination share under nominee under basic details", "xpath", INPUT_NOMINATION_SHARE_BASIC_DETAILS);
	WebPageElements btn_add_nominee_basic_details = new WebPageElements("Add Button under nominee under basic details", "xpath", BTN_ADD_NOMINEE_BASIC_DETAILS);
	WebPageElements btn_submit_payment = new WebPageElements("Submit Button Payment Page", "xpath", BTN_SUBMIT_PAYMENT);
	WebPageElements txt_dummy_payment_option = new WebPageElements("Dummy Payment Option Page", "xpath", TXT_DUMMY_PAYMENT_OPTION);
	WebPageElements chb_policy_agreement_checkbox = new WebPageElements("Policy Agreement checkbox on payment page", "xpath", CHB_POLICY_AGREEMENT_CHECKBOX);
	WebPageElements btn_submit_payment_gateway = new WebPageElements("Submit Button on payment gateway page", "xpath", BTN_SUBMIT_PAYMENT_GATEWAY);
	WebPageElements btn_paynow_payment_gateway = new WebPageElements("Paynow Button on payment gateway page", "xpath", BTN_PAYNOW_PAYMENT_GATEWAY);
	WebPageElements btn_continue_filling_customer_details_now = new WebPageElements("Alert box for continue filling customer details", "xpath", BTN_CONTINUE_FILLING_CUSTOMER_DETAILS_NOW);
	WebPageElements toggle_prev_policy_details_N_option = new WebPageElements("Prev. Policy Details N option", "xpath", TOGGLE_PREV_POLICY_DETAILS_N_OPTION);
	WebPageElements txt_refused_withdrawn_prev_policy_details = new WebPageElements("Refused, Withdrawn, Declined, Postponed Policies txt under prev. policy details", "xpath", TXT_REFUSED_WITHDRAWN_PREV_POLICY_DETAILS);
	WebPageElements toggle_refused_withdrawn_prev_policy_details_n_option = new WebPageElements("Refused, Withdrawn, Declined.. Question toggle under prev. policy details", "xpath", TOGGLE_REFUSED_WITHDRAWN_PREV_POLICY_DETAILS_N_OPTION);
	WebPageElements input_payout_account_holders_name = new WebPageElements("Account holders name under payout details", "xpath", INPUT_PAYOUT_ACCOUNT_HOLDERS_NAME);
	WebPageElements input_payout_account_number = new WebPageElements("Account no under payout details", "xpath", INPUT_PAYOUT_ACCOUNT_NUMBER);
	WebPageElements rb_account_type_saving = new WebPageElements("Account Type Savings under payout details", "xpath", RB_ACCOUNT_TYPE_SAVING);
	WebPageElements txt_renewal_premium_payment_details = new WebPageElements("Renewal premium payment details section", "xpath", TXT_RENEWAL_PREMIUM_PAYMENT_DETAILS);
	WebPageElements rb_direct_bill_renewal_premium = new WebPageElements("Direct Bill payment method under payment details section", "xpath", RB_DIRECT_BILL_RENEWAL_PREMIUM);
	
	//Customer health Details
	WebPageElements input_height_health_details = new WebPageElements("Height Field under health details", "xpath", INPUT_HEIGHT_HEALTH_DETAILS);
	WebPageElements input_height_inch_health_details = new WebPageElements("Height inch Field under health details", "xpath", INPUT_HEIGHT_INCH_HEALTH_DETAILS);
	WebPageElements input_weight_health_details = new WebPageElements("Weight field under health details", "xpath", INPUT_WEIGHT_HEALTH_DETAILS);
	WebPageElements toggle_weight_change_question = new WebPageElements("Weight change question N option under health details", "xpath", TOGGLE_WEIGHT_CHANGE_QUESTION);
	WebPageElements txt_life_style_information = new WebPageElements("Life style information text", "xpath", TXT_LIFE_STYLE_INFORMATION);
	WebPageElements toggle_question_live_travel_outside_india_n_option = new WebPageElements("Travel outside india question N option", "xpath", TOGGLE_QUESTION_LIVE_TRAVEL_OUTSIDE_INDIA_N_OPTION);
	WebPageElements toggle_question_hazardous_occupation_n_option = new WebPageElements("Hazardous occupation question N option", "xpath", TOGGLE_QUESTION_HAZARDOUS_OCCUPATION_N_OPTION);
	WebPageElements toggle_question_narcotic_substance_n_option = new WebPageElements("Narcotics substance question N option", "xpath", TOGGLE_QUESTION_NARCOTIC_SUBSTANCE_N_OPTION);
	WebPageElements toggle_question_consume_alcohol_n_option = new WebPageElements("Consume Alcohol question N Option", "xpath", TOGGLE_QUESTION_CONSUME_ALCOHOL_N_OPTION);
	WebPageElements toggle_question_tobacco_nicotine_products_n_option = new WebPageElements("Tobacco Nicotin product question N Option", "xpath", TOGGLE_QUESTION_TOBACCO_NICOTINE_PRODUCTS_N_OPTION);
	WebPageElements txt_family_medical_history = new WebPageElements("Family medical History Section", "xpath", TXT_FAMILY_MEDICAL_HISTORY);
	WebPageElements chb_none_family_medical_history = new WebPageElements("None checkbox under family medical history", "xpath", CHB_NONE_FAMILY_MEDICAL_HISTORY);
	WebPageElements input_fatherage_family_medical_history = new WebPageElements("Father Age under family medical history", "xpath", INPUT_FATHERAGE_FAMILY_MEDICAL_HISTORY);
	WebPageElements input_motherage_family_medical_history = new WebPageElements("Mother Age under family medical history", "xpath", INPUT_MOTHERAGE_FAMILY_MEDICAL_HISTORY);
	WebPageElements ddl_father_state_of_health = new WebPageElements("DDL State of health for father", "xpath", DDL_FATHER_STATE_OF_HEALTH);
	WebPageElements ddl_father_state_of_health_option_ok_good = new WebPageElements("Option Ok/Good under DDL state of health for father", "xpath", DDL_FATHER_STATE_OF_HEALTH_OPTION_OK_GOOD);
	WebPageElements ddl_mother_state_of_health_option_ok_good = new WebPageElements("Option Ok/Good under DDL state of health for mother", "xpath", DDL_MOTHER_STATE_OF_HEALTH_OPTION_OK_GOOD);
	WebPageElements ddl_mother_state_of_health = new WebPageElements("DDL State of health for mother", "xpath", DDL_MOTHER_STATE_OF_HEALTH);
	WebPageElements toggle_no_of_brothers = new WebPageElements("No of brothers question N option", "xpath", TOGGLE_NO_OF_BROTHERS);
	WebPageElements toggle_no_of_sisters = new WebPageElements("No of sisters question N option", "xpath", TOGGLE_NO_OF_SISTERS);
	WebPageElements txt_medical_history = new WebPageElements("Medical history Section", "xpath", TXT_MEDICAL_HISTORY);
	WebPageElements toggle_remain_absent_medical_history_n_option = new WebPageElements("Remain Absent question N option", "xpath", TOGGLE_REMAIN_ABSENT_MEDICAL_HISTORY_N_OPTION);
	WebPageElements toggle_question_surgical_operation_n_option = new WebPageElements("surgical operation N option", "xpath", TOGGLE_QUESTION_SURGICAL_OPERATION_N_OPTION);
	WebPageElements toggle_question_diet_n_option = new WebPageElements("Diet question N option", "xpath", TOGGLE_QUESTION_DIET_N_OPTION);
	WebPageElements toggle_question_undergo_any_treatment_n_option = new WebPageElements("Under Go Any treatment question N Option", "xpath", TOGGLE_QUESTION_UNDERGO_ANY_TREATMENT_N_OPTION);
	WebPageElements toggle_question_surgical_operation_procedure_option_n = new WebPageElements("Surgical operation procedure question n option", "xpath", TOGGLE_QUESTION_SURGICAL_OPERATION_PROCEDURE_OPTION_N);
	WebPageElements chb_sought_advice_medical_history = new WebPageElements("Checkbox sought advice medical history", "xpath", CHB_SOUGHT_ADVICE_MEDICAL_HISTORY);
	WebPageElements toggle_question_physical_defects_option_n = new WebPageElements("Physical defects question option n", "xpath", TOGGLE_QUESTION_PHYSICAL_DEFECTS_OPTION_N);
	WebPageElements toggle_question_hiv_option_n = new WebPageElements("HIV question option N", "xpath", TOGGLE_QUESTION_HIV_OPTION_N);
	WebPageElements toggle_question_health_symptoms = new WebPageElements("Health Symptoms question N", "xpath", TOGGLE_QUESTION_HEALTH_SYMPTOMS);
	
	//REVIEW AND ACCEPTANCE
	WebPageElements txt_review_and_acceptance = new WebPageElements("Review and Acceptance text", "xpath", TXT_REVIEW_AND_ACCEPTANCE);
	WebPageElements txt_place_of_application = new WebPageElements("Place of Application", "xpath", TXT_PLACE_OF_APPLICATION);
	
	public String result, str;
	public boolean display, lnk_exit;
	public WebElement element;
	public String pageSource;


	public void insurerProposerSameFlow(WebDriver driver,String sumassured,String aadharnumber,String fatherSpouseName, String BirthState,String BirthCity,String pandetails,String address, String pin, String emailid, String city,String mobileno,
			String employername,String designation,String natureofduties,String expyears,String annualincome,
			String nomineefisrtname,String nomineelastname,String nomineedob,String nominationshare,String accountholdername,String accountnumber,String height,String heightinch, String weight, String fatherage, String motherage
			,String applicationplace) throws InterruptedException, AWTException {
	//	boolean alert_result = false;
		waitForElementPresent(driver, 120, txtbox_fisrtname_proposerdetails);
		sendKey_element(driver, txtbox_fisrtname_proposerdetails, "John");
		waitForElementPresent(driver, 60, txtbox_lastname_proposerdetails);
		sendKey_element(driver, txtbox_lastname_proposerdetails, "Robinson");
		waitForElementPresent(driver, 60, dob_proposerdetails);
		sendKey_element(driver, dob_proposerdetails, "10-12-1995");
		waitForElementPresent(driver, 60, image_malegender_proposerdetails);
		click(driver, image_malegender_proposerdetails);
		//waitForElementPresent(driver, 60, chb_life_to_be_insured_proposer);
		//click(driver, chb_life_to_be_insured_proposer);
		waitForElementPresent(driver, 60, btn_suggestplan);
		click(driver, btn_suggestplan);
		waitForElementPresent(driver, 60, ddl_select_menu_saving_with_protection_plan);
		click(driver, ddl_select_menu_saving_with_protection_plan);
		waitForElementPresent(driver, 60, ddl_value_bsli_vision_endowment_plus);
		click(driver, ddl_value_bsli_vision_endowment_plus);
		waitForElementPresent(driver, 60, btn_next_proposerdetails);
		click(driver, btn_next_proposerdetails);
		waitForElementPresent(driver, 60, txt_proposer_state);
		sendKey_element(driver, txt_proposer_state, "GUJARAT");
		waitForElementPresent(driver, 60, tab_riders);
		click(driver, tab_riders);
		waitForElementPresent(driver, 60, chb_selectall_riders_tab);
		click(driver, chb_selectall_riders_tab);
		waitForElementPresent(driver, 60, chb_accidental_death_and_disability_riders_tab);
		click(driver, chb_accidental_death_and_disability_riders_tab);
		Thread.sleep(1000);
		waitForElementPresent(driver, 60, input_sum_assured_accidental_death_and_disability);
		sendKey_element(driver, input_sum_assured_accidental_death_and_disability,sumassured);
		waitForElementPresent(driver, 60, btn_calculate_premium);
		click(driver, btn_calculate_premium);
		Thread.sleep(2000);
		waitForElementPresent(driver, 120, btn_generate_illustration);
		Thread.sleep(2000);
		click(driver, btn_generate_illustration);
		Thread.sleep(5000);
		Robot r = new Robot();
		r.keyPress(java.awt.event.KeyEvent.VK_ALT); 
		r.keyPress(java.awt.event.KeyEvent.VK_F4);  
		r.keyRelease(java.awt.event.KeyEvent.VK_ALT);
		r.keyRelease(java.awt.event.KeyEvent.VK_F4);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, btn_buy_now);
		click(driver, btn_buy_now);
		waitForElementPresent(driver, 60, btn_proceed);
		click(driver, btn_proceed);
		waitForElementPresent(driver, 60, input_basicdetails_aadharnumber);
		Thread.sleep(2000);
		sendKey_element(driver, input_basicdetails_aadharnumber, aadharnumber);
		Thread.sleep(3000);
		waitForElementPresent(driver, 60, txt_personal_details_basic_details);
		click(driver, txt_personal_details_basic_details);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, input_father_spouse_name_basic_details);
		sendKey_element(driver, input_father_spouse_name_basic_details, fatherSpouseName);
		Thread.sleep(1000);
		waitForElementPresent(driver, 60, input_birth_state_basic_details);
		sendKey_element(driver, input_birth_state_basic_details, BirthState);
		Thread.sleep(1000);
		waitForElementPresent(driver, 60, input_birth_city_basic_details);
		sendKey_element(driver, input_birth_city_basic_details, BirthCity);
		waitForElementPresent(driver, 60, ddl_marital_status_basic_details);
		click(driver, ddl_marital_status_basic_details);
		waitForElementPresent(driver, 60, ddl_value_marital_status_single_basic_details);
		click(driver, ddl_value_marital_status_single_basic_details);
		waitForElementPresent(driver, 60, toggle_btn_citizenship_basic_details);
		click(driver, toggle_btn_citizenship_basic_details);
		waitForElementPresent(driver, 60, toggle_btn_tax_resident_basic_details);
		click(driver, toggle_btn_tax_resident_basic_details);
		waitForElementPresent(driver, 60, txt_professional_details_basic_details);
		click(driver, txt_professional_details_basic_details);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, ddl_qualification_basic_details);
		click(driver, ddl_qualification_basic_details);
		waitForElementPresent(driver, 60, ddl_qualification_value_professional_basic_details);
		click(driver, ddl_qualification_value_professional_basic_details);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, ddl_occupation_basic_details);
		click(driver, ddl_occupation_basic_details);
		waitForElementPresent(driver, 60, ddl_occupation_value_service_basic_details);
		click(driver, ddl_occupation_value_service_basic_details);
		waitForElementPresent(driver, 60, input_pan_professional_details);
		sendKey_element(driver, input_pan_professional_details, pandetails);
		waitForElementPresent(driver, 60, btn_validate_for_pan);
		click(driver, btn_validate_for_pan);
		waitForElementPresent(driver, 60, txt_first_last_not_matching);
		click(driver, btn_close);
		waitForElementPresent(driver, 60, input_name_of_employer_professional_basic_details);
		sendKey_element(driver, input_name_of_employer_professional_basic_details, employername);
		waitForElementPresent(driver, 60, input_designation_professional_basic_details);
		sendKey_element(driver, input_designation_professional_basic_details, designation);
		waitForElementPresent(driver, 60, ddl_organization_type_professional_basic_details);
		click(driver, ddl_organization_type_professional_basic_details);
		waitForElementPresent(driver, 60, ddl_organization_value_private_professional_basic_details);
		click(driver, ddl_organization_value_private_professional_basic_details);
		waitForElementPresent(driver, 60, input_nature_of_duties_professional_details);
		sendKey_element(driver, input_nature_of_duties_professional_details, natureofduties);
		waitForElementPresent(driver, 60, input_years_with_experience_professional_details);
		sendKey_element(driver, input_years_with_experience_professional_details, expyears);
		waitForElementPresent(driver, 60, input_annual_income_professional_details);
		sendKey_element(driver, input_annual_income_professional_details, annualincome);
		
		waitForElementPresent(driver, 60, txt_communication_address_basic_details);
		click(driver, txt_communication_address_basic_details);
		Thread.sleep(3000);
		waitForElementPresent(driver, 60, address1_communication_address_basic_details);
		sendKey_element(driver, address1_communication_address_basic_details, address);
		waitForElementPresent(driver, 60, input_city_communication_address_basic_details);
		sendKey_element(driver, input_city_communication_address_basic_details, city);
		waitForElementPresent(driver, 60, input_pin_communication_address_basic_details);
		sendKey_element(driver, input_pin_communication_address_basic_details, pin);
		waitForElementPresent(driver, 60, input_mobile_communication_address_basic_details);
		sendKey_element(driver, input_mobile_communication_address_basic_details, mobileno);
		waitForElementPresent(driver, 60, input_email_communication_address_basic_details);
		sendKey_element(driver, input_email_communication_address_basic_details, emailid);
		
		try {
			driver.findElement(By.xpath(INPUT_EMAIL_COMMUNICATION_ADDRESS_BASIC_DETAILS)).sendKeys(Keys.TAB);
		}catch(Exception e) {
			Add_Log.info("Not able to find Email field in communication address section");
			seterror("Not able to find Email field in communication address section");
			//Reporter.log("Not able to find Email field in communication address section");
			TestResultStatus.Testfail = true;
			Assert.fail();
		}
		Thread.sleep(3000);
		//waitForElementPresent(driver, 60, toggle_policy_document_N_basic_details);
		//click(driver, toggle_policy_document_N_basic_details);
		waitForElementPresent(driver, 60, txt_eia_details_basic_details);
		click(driver, txt_eia_details_basic_details);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, rb_eia_details_no_value_basic_details);
		click(driver, rb_eia_details_no_value_basic_details);
		waitForElementPresent(driver, 60, txt_other_details_basic_details);
		click(driver, txt_other_details_basic_details);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, toggle_other_details_pep_n_value_basic_details);
		click(driver, toggle_other_details_pep_n_value_basic_details);
		waitForElementPresent(driver, 60, rb_other_details_savings_basic_details);
		click(driver, rb_other_details_savings_basic_details);
		waitForElementPresent(driver, 60, btn_confirm);
		click(driver, btn_confirm);
		waitForElementPresent(driver, 60, input_nominee_first_name_basic_details);
		sendKey_element(driver, input_nominee_first_name_basic_details, nomineefisrtname);
		waitForElementPresent(driver, 60, input_nominee_last_name_basic_details);
		sendKey_element(driver, input_nominee_last_name_basic_details, nomineelastname);
		waitForElementPresent(driver, 60, nominee_dob_basic_details);
		Thread.sleep(1000);
		sendKey_element(driver, nominee_dob_basic_details, nomineedob);
		waitForElementPresent(driver, 60, ddl_relationship_with_li_nominee_basic_details);
		click(driver, ddl_relationship_with_li_nominee_basic_details);
		Thread.sleep(1000);
		waitForElementPresent(driver, 60, ddl_relationship_with_li_value_parent_nominee_basic_details);
		click(driver, ddl_relationship_with_li_value_parent_nominee_basic_details);
		Thread.sleep(1000);
		waitForElementPresent(driver, 60, input_nomination_share_basic_details);
		sendKey_element(driver, input_nomination_share_basic_details, nominationshare);
		waitForElementPresent(driver, 60, btn_add_nominee_basic_details);
		click(driver, btn_add_nominee_basic_details);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, btn_confirm);
		click(driver, btn_confirm);
		Thread.sleep(5000);
		waitForElementPresent(driver, 60, btn_submit_payment);
		switchToTab(driver, btn_submit_payment);
		Thread.sleep(9000);	
		r.keyPress(java.awt.event.KeyEvent.VK_ESCAPE);  
		r.keyRelease(java.awt.event.KeyEvent.VK_ESCAPE);		
	//	System.out.println("the text is:"+s);
		Thread.sleep(2000);
		waitForElementPresent(driver, 200, txt_dummy_payment_option);
		click(driver, txt_dummy_payment_option);
		Thread.sleep(9000);
		r.keyPress(java.awt.event.KeyEvent.VK_ESCAPE);  
		r.keyRelease(java.awt.event.KeyEvent.VK_ESCAPE);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, chb_policy_agreement_checkbox);
		click(driver, chb_policy_agreement_checkbox);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, btn_submit_payment_gateway);
		//click(driver, btn_submit_payment_gateway);
		//driver.findElement(By.xpath(BTN_SUBMIT_PAYMENT_GATEWAY)).click();
		r.keyPress(java.awt.event.KeyEvent.VK_ENTER);
		r.keyRelease(java.awt.event.KeyEvent.VK_ENTER);
		//driver.findElement(By.xpath(BTN_SUBMIT_PAYMENT_GATEWAY)).click();
		/*driver.findElement(By.xpath(BTN_SUBMIT_PAYMENT_GATEWAY)).sendKeys(Keys.ENTER);
		driver.findElement(By.xpath(BTN_SUBMIT_PAYMENT_GATEWAY)).sendKeys(".");*/
		Thread.sleep(7000);
		r.keyPress(java.awt.event.KeyEvent.VK_ESCAPE);  
		r.keyRelease(java.awt.event.KeyEvent.VK_ESCAPE);
		//Thread.sleep(7000);
		/*r.keyPress(java.awt.event.KeyEvent.VK_ESCAPE);  
		r.keyRelease(java.awt.event.KeyEvent.VK_ESCAPE);*/
		waitForElementPresent(driver, 60, btn_paynow_payment_gateway);
		//click(driver, btn_paynow_payment_gateway);
		switchToTab(driver, btn_paynow_payment_gateway);
		waitForElementPresent(driver, 120, btn_continue_filling_customer_details_now);
		click(driver, btn_continue_filling_customer_details_now);
		waitForElementPresent(driver, 60, toggle_prev_policy_details_N_option);
		click(driver, toggle_prev_policy_details_N_option);
		waitForElementPresent(driver, 60, txt_refused_withdrawn_prev_policy_details);
		click(driver, txt_refused_withdrawn_prev_policy_details);
		waitForElementPresent(driver, 60, toggle_refused_withdrawn_prev_policy_details_n_option);
		click(driver, toggle_refused_withdrawn_prev_policy_details_n_option);
		waitForElementPresent(driver, 60, btn_confirm);
		click(driver, btn_confirm);
		waitForElementPresent(driver, 60, input_payout_account_holders_name);
		sendKey_element(driver, input_payout_account_holders_name, accountholdername);
		waitForElementPresent(driver, 60, input_payout_account_number);
		sendKey_element(driver, input_payout_account_number, accountnumber);
		waitForElementPresent(driver, 60, rb_account_type_saving);
		click(driver, rb_account_type_saving);
		waitForElementPresent(driver, 60, txt_renewal_premium_payment_details);
		click(driver, txt_renewal_premium_payment_details);
		waitForElementPresent(driver, 60, rb_direct_bill_renewal_premium);
		click(driver, rb_direct_bill_renewal_premium);
		waitForElementPresent(driver, 60, btn_confirm);
		click(driver, btn_confirm);
		waitForElementPresent(driver, 60, input_height_health_details);
		sendKey_element(driver, input_height_health_details, height);
		waitForElementPresent(driver, 60, input_height_inch_health_details);
		sendKey_element(driver, input_height_inch_health_details, heightinch);
		waitForElementPresent(driver, 60, input_weight_health_details);
		sendKey_element(driver, input_weight_health_details, weight);
		waitForElementPresent(driver, 60, toggle_weight_change_question);
		click(driver, toggle_weight_change_question);
		waitForElementPresent(driver, 60, txt_life_style_information);
		click(driver, txt_life_style_information);
		waitForElementPresent(driver, 60, toggle_question_live_travel_outside_india_n_option);
		click(driver, toggle_question_live_travel_outside_india_n_option);
		waitForElementPresent(driver, 60, toggle_question_hazardous_occupation_n_option);
		click(driver, toggle_question_hazardous_occupation_n_option);
		waitForElementPresent(driver, 60, toggle_question_narcotic_substance_n_option);
		click(driver, toggle_question_narcotic_substance_n_option);
		waitForElementPresent(driver, 60, toggle_question_consume_alcohol_n_option);
		click(driver, toggle_question_consume_alcohol_n_option);
		waitForElementPresent(driver, 60, toggle_question_tobacco_nicotine_products_n_option);
		click(driver, toggle_question_tobacco_nicotine_products_n_option);
		waitForElementPresent(driver, 60, txt_family_medical_history);
		click(driver, txt_family_medical_history);
		waitForElementPresent(driver, 60, chb_none_family_medical_history);
		click(driver, chb_none_family_medical_history);
		waitForElementPresent(driver, 60, input_fatherage_family_medical_history);
		sendKey_element(driver, input_fatherage_family_medical_history, fatherage);
		waitForElementPresent(driver, 60, ddl_father_state_of_health);
		click(driver, ddl_father_state_of_health);
		waitForElementPresent(driver, 60, ddl_father_state_of_health_option_ok_good);
		click(driver, ddl_father_state_of_health_option_ok_good);
		waitForElementPresent(driver, 60, input_motherage_family_medical_history);
		sendKey_element(driver, input_motherage_family_medical_history, motherage);
		waitForElementPresent(driver, 60, ddl_mother_state_of_health);
		click(driver, ddl_mother_state_of_health);
		waitForElementPresent(driver, 60, ddl_mother_state_of_health_option_ok_good);
		click(driver, ddl_mother_state_of_health_option_ok_good);
		waitForElementPresent(driver, 60, toggle_no_of_brothers);
		click(driver, toggle_no_of_brothers);
		waitForElementPresent(driver, 60, toggle_no_of_sisters);
		click(driver, toggle_no_of_sisters);
		waitForElementPresent(driver, 60, txt_medical_history);
		click(driver, txt_medical_history);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, toggle_remain_absent_medical_history_n_option);
		click(driver, toggle_remain_absent_medical_history_n_option);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, toggle_question_surgical_operation_n_option);
		click(driver, toggle_question_surgical_operation_n_option);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, toggle_question_diet_n_option);
		click(driver, toggle_question_diet_n_option);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, toggle_question_undergo_any_treatment_n_option);
		click(driver, toggle_question_undergo_any_treatment_n_option);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, toggle_question_surgical_operation_procedure_option_n);
		click(driver, toggle_question_surgical_operation_procedure_option_n);
		Thread.sleep(2000);
		waitForElementPresent(driver, 60, chb_sought_advice_medical_history);
		click(driver, chb_sought_advice_medical_history);
		waitForElementPresent(driver, 60, toggle_question_physical_defects_option_n);
		click(driver, toggle_question_physical_defects_option_n);
		waitForElementPresent(driver, 60, toggle_question_hiv_option_n);
		click(driver, toggle_question_hiv_option_n);
		waitForElementPresent(driver, 60, toggle_question_health_symptoms);
		click(driver, toggle_question_health_symptoms);
		waitForElementPresent(driver, 60, btn_confirm);
		click(driver, btn_confirm);
		Thread.sleep(5000);
		waitForElementPresent(driver, 60, txt_place_of_application);
		sendKey_element(driver, txt_place_of_application, applicationplace);
		waitForElementPresent(driver, 60, txt_review_and_acceptance);
		click(driver, txt_review_and_acceptance);
		System.out.println("Reached till OTP Enter phase on review and acceptance");
		
		Thread.sleep(2000);
		
	}
	public void gridTableUtiization(WebDriver driver) {

		try {
			waitForLoad(driver, 100);
			
			boolean b = driver.getPageSource().contains("$");
			System.out.println(b);
			//waitForElementPresent(driver, 60, tbl_grid_utilization);
		}

		catch (Exception e) {
			Add_Log.info("Not able to find tbl_grid_utilization");
			Reporter.log("Not able to find tbl_grid_utilization");
			TestResultStatus.Testfail = true;
			Assert.fail();

		}

	}



}

package utility;

import java.io.FileInputStream;
import java.util.Properties;

//import org.testng.annotations.Test;

public class CopyExcel extends SeleniumUtils {
	
	

    public void copyXlsFiles(){

            Properties Config = new Properties();

            FileInputStream fip;

            try {
                    fip = new FileInputStream(System.getProperty("user.dir")+"\\src/main/resources\\Config\\Config.properties");

                    Config.load(fip);

            } catch (Exception e) {

                    // TODO Auto-generated catch block

                    e.printStackTrace();

            }

            copyExcel(Config.getProperty("FileName"));

    }




}

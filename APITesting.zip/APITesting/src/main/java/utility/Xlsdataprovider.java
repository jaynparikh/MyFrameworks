package utility;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;



public class Xlsdataprovider {
	
	@DataProvider(name="Regression")
	public static Object[][] regressionData(Method m)
	{
		FetchExcelDataSet excelDatSet = new FetchExcelDataSet();
		Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\Dashboard_Tests.xls", "Regression_TC",m.getName());
		return dataset;
	}
	
	@DataProvider(name="Collateral")
	public static Object[][] collateralnData(Method m)
	{
		FetchExcelDataSet excelDatSet = new FetchExcelDataSet();
		Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\Dashboard_Tests.xls", "Collateral_TC",m.getName());
		return dataset;
	}
	
	@DataProvider(name="Default")
	public static Object[][] fetchdata(Method m)
	{
		FetchExcelDataSet excelDatSet = new FetchExcelDataSet();
		Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\Default.xls", "Default",m.getName());
		return dataset;
	}
	
	@DataProvider(name="DashboardTests")
	public static Object[][] Containssearchfetchdata(Method a)
	{
		FetchExcelDataSet excelDatSet = new FetchExcelDataSet();
		
		//Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src\\ExcelFiles\\ProductSearchContains.xls", "search",a.getName());
		Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\Dashboard_Tests.xls", "Smoke_Test",a.getName());
		return dataset;
	}
	
	
	@DataProvider(name="SanityTest")
	public static Object[][] Containssanityfetchdata(Method s)
	{
		FetchExcelDataSet excelDatSet = new FetchExcelDataSet();
		
		//Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src\\ExcelFiles\\ProductSearchContains.xls", "search",a.getName());
		Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\Dashboard_Tests.xls", "Time_Load",s.getName());
		return dataset;
	}
	
	@DataProvider(name="SanityTCTest")
	public static Object[][] Containssanitytcfetchdata(Method e)
	{
		FetchExcelDataSet excelDatSet = new FetchExcelDataSet();
		
		//Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src\\ExcelFiles\\ProductSearchContains.xls", "search",a.getName());
		Object[][] dataset = excelDatSet.getDataSetAsObjectArray(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\Dashboard_Tests.xls", "SanityTC",e.getName());
		return dataset;
	}
	
	

}

package property;

public interface INavigatorPage {
	
	String MSG_PLEASEWAIT = "//label[contains(@class,'x-component loadingText')]";
	String ICON_RIGHTSIDEMENU = "//a[contains(@class,'tab-menu-button')]";
	String MENU_TRADEVALIDATION = "(//span[text()='TradeValidation'])[2]";
	String ICON_DELETE = "(//span[@class='icon-delete'])[2]";
	String DDL_TRIGGERPICKER = "//div[@id='perspectiveComboBox-trigger-picker']";
	String LOADER7 = "(//div[@class='x-mask-msg-text'])[7]";
	String ICON_MORE_NAV = "(//span[contains(@class,'small icon-ellipse')])[2]";
}

package property;

public interface ICannedPage {

	
	String DDL_CANNED_CATEGORY = "//input[@name='category']";
	String LNK_CATEGORY_SFT_ACCOUNT = "//li[text()='SFT_ACCOUNT']";
	String LNK_REPORT_CATEGORY_FACILITY = "//li[text()='FACILITY']";
	String DDL_CANNED_REPORT_TYPE = "//input[@name='reportType']";
	String LNK_REPORT_TYPE_ACCOUNT_VIEW = "//li[text()='Account View']";
	String LNK_REPORT_TYPE_LIMIT_AVAILABILITY_REPORT = "//li[text()='Limit Availability Report']";
	String LNK_REPORT_TYPE_CPM_FACILITY_EXPOSURE = "//li[text()='Cpm Facility Exposure']";
	String BTN_CANNED_APPLY = "(//span[contains(text(),'Apply')])[2]";
	String TXT_CANNED_FIRST_RECORD ="(//table[1]/tbody/tr/td[1])[2]";
	String BTN_LINK = "//span[text()='Link']";
	String BTN_UNLINK = "//span[text()='Unlink']";
	String DDL_LINKTYPE = "//input[@name='linkType']";
	String TXT_CPGFCID = "//input[@name='cpGfcid']";
	String BTN_LINKTYPE_OK = "//span[text()='OK']";
	String ICON_CANNEDVIEWS = "(//span[contains(@class,'small REPORTS')])[1]";
	String ICON_CANNEDVIEWS2 = "(//span[contains(@class,'icon-reports')])[1]";
	String TAB_CITIRISKCREDIT = "(//span[text()='CitiRisk Credit'])[1]";
	String DDL_REPORTCATEGORY = "//input[@name='category']";
	String DDL_REPORTTYPE = "//input[@name='reportType']";
	String TRIGGER11 = "(//div[contains(@id,'trigger-picker')])[11]";
	String TRIGGER12 = "(//div[contains(@id,'trigger-picker')])[12]";
	String BTN_APPLY_CANNED = "(//span[text()='Apply'])[2]";
	
}

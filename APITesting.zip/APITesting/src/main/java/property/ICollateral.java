package property;

public interface ICollateral {

}

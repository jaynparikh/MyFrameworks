package property;

public interface ILoginPage 
{
	String TXT_USERNAME = "//*[@name='USER']";
	String TXT_PASSWORD = "//*[@name='PASSWORD']";
	String BTN_SIGNON = "//*[@value='Sign On']";
	
	String DDL_SOEID = "//*[@id='SM_USER']";
	String BTN_LOGIN = "//*[@value='login']";
	
	
	
}

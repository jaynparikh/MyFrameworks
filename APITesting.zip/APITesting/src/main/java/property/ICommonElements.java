package property;

public interface ICommonElements {
	String LNK_PRODUCT_RATING = "Product Rating";
	String LNK_HOME = "Home";
}

package property;

public interface ISanityPage {
	
	
		
		String LNK_CLONED = "//div[@id='displayContent']/div[2]/div/span[2]/a";
		String DDL_AVAILABLEUSERS = "SM_USER";
		String BTN_CLONEDAFTER = "//input[@value = 'Clone After']";
		
		String DDL_VIEW_NAME = "//input[@name='comboboxWithLevelType']";

	    String VIEW_NAME_OPTIONS = "//ul[starts-with(@id,'boundlist-')]/li";
	    String THIRD_PARTY_OPTIONS ="//ul[starts-with(@id,'boundlist-')]/li";
	    String COVERAGE_OPTIONS="//ul[starts-with(@id,'boundlist-')]/li";

	    String DDL_THIRD_PARTY = "//input[@name='comboboxWithDataType']";

	    String DDL_COVERAGE = "//input[@name='comboboxWithGroup']";

	    String DDL_CRITERIA = "//input[@name='criteria']";

	    String BTN_APPLY = "//span[contains(text(),'Apply')]";
	    String BTN_SAVE = "//span[contains(text(),'Save')]";
	    String BTN_MANAGE = "//span[contains(text(),'Manage')]";
	    
	    String TAB_UTILIZATION="//span[text()='Utilization']";
	    String TAB_TOP_10="//span[text()='Top 10']";
	    String TAB_OVERAGE="//span[text()='Top Overage']";
	    String TAB_EXCEPTIONS="//span[text()='Exceptions']";
	    String TAB_OBLIGOR_BY_BV = "//span[text()='Obligor By BV']";
	    String TAB_UNMATCHED_EXCEPTIONS = "//span[text()='Unmatched Exceptions']";
	    String TAB_EXPOSURE_SUMMARY = "//span[text()='Exposure Summary']";
	    String TAB_23_A_REPORT = "//span[text()='23A Report']";
	    String TAB_RELATIONSHIP ="//span[contains(@id,'tab') and text()='Relationship']";
	    String TAB_FACILITY ="//span[text()='Facility']";
	    String TAB_OBLIGOR ="//span[text()='Obligor']";
	    String TAB_UNMATCHED ="//span[text()='Unmatched']";
	    String TAB_NCS ="//span[text()='NCS']";
	    String TAB_SETTLEMENT_RISK ="//span[text()='Settlement Risk']";
	    String TAB_AGREEMENT ="//span[text()='Agreement']";
	    String TAB_SECURITY ="//span[text()='Security']";
	   
	    
	    
	    
	    
	    String LNK_VIEW_RELATIONSHIP="//li[text()='Relationship']";
	    String LNK_VIEW_OBLIGOR="//li[text()='Obligor']";
	    String LNK_VIEW_FACILITY="//li[text()='Facility']";
	    String LNK_VIEW_SALES_TRADING = "//li[text()='Sales and Trading']";
	    String LNK_VIEW_BENEFICIAL_OWNER="//li[text()='Beneficial Owner']";
	    String LNK_VIEW_LEGAL_VEHICLE="//li[text()='Legal Vehicle']";
	    String LNK_VIEW_EXCEPTIONS="//li[text()='Exceptions']";
	    String LNK_VIEW_BIS="//li[text()='BIS Top 50 Submission']";
	    
	    String LNK_THIRD_PARTY="//li[text()='Third Party Only']";
	    String LNK_THIRD_INTER="//li[text()='Inter Company Only']";
	    String LNK_THIRD_BOTH="//li[text()='Both']";
	    
	    String LNK_COVERAGE_ALL_CLIENTS = "//li[text()='All Clients']";
	    String LNK_COVERAGE_MY_CLIENTS = "//li[text()='My Clients']";
	    String LNK_COVERAGE_FAVORITES = "//li[text()='Favorites']";
	    
	    
	  String TBL_GRID_DATA = "//table/tbody/tr/td";
	    String LNK_FACILITY_ID_FIRST_RECORD = "//div[contains(@class,'x-grid-item-container')]/table[1]/tbody/tr/td[5]/div/a";
	    String TAB_CITIRISK_CREDIT = "//span[text()='CitiRisk Credit']";
	    String TBL_GRID_DATA_Top10 ="//*[@class='x-grid-cell-inner x-grid-cell-inner-row-numberer']";
	    String TXT_APPROVAL_CURRENCY = "//span[text()='Approval Currency']";
	    String LNK_DASHBOARD = "//span[text()='Dashboard']";
	 
	//    <div class="x-grid-cell-inner x-grid-cell-inner-row-numberer" style="text-align:right;">1</div>
	    //  String TBL_GRID_DATA_Top10 = "//table/tbody/tr";
	    //span[text()='Exceptions']

	    //String DP_COMMITTED_EXPIRY_DATE = "//div[contains(@id,'coredatefield')]/following-sibling::div[contains(@id,'coredatefield')]/div/div/div[contains(@class,'x-form-date-trigger')]")";

	    //String TOOL_NAVIGATOR = "//div[contains(@id,'coretoolbar')]/div/div/a[contains(@class,'navigation_navigator')]";

	    //String TXT_NAVIGATOR_SEARCHBOX = "//input[@placeholder='Enter Minimum 3 chars']";


	}



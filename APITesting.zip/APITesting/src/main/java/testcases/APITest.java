package testcases;

import org.testng.annotations.Test;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.LinkedHashMap;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.asserts.SoftAssert;

import testsuitebase.SuiteBase;
import testsuitebase.TestResultStatus;
import utility.Read_XLS;
import utility.SuiteUtility;

public class APITest extends SuiteBase {
	// private static final String WebDriver = null;

	Read_XLS FilePath = null;
	Read_XLS FilePath1 = null;
	String TestCaseName = null;
	String SheetName = "Time_Load";
	String ResultSheetName = "Result";
	public boolean TestCasePass = true;
	public int DataSet = -1;
	public DecimalFormat df = new DecimalFormat("#.##");

	public boolean Testskip = false;
	public boolean Testfail = false;
	SoftAssert s_assert = null;
	public double finish, start;
	public double end;
	public double totalTime;

	/*@BeforeTest()
	public void setUp() throws IOException {
		init();
		FilePath = TestCaseListExcelsearchContains;
		URLs = TestCaseListExcelsearchContains.getEnvUrl("Environment");
		System.out.println(URLs.size());
		loadWebBrowser();

	}*/

	/*-----Filter selection: Relationship, Both, All clients ; checking 4 tabs: Utilization, Top 10, Top Overage, Exceptions
						-----Also checking load time for utilization tab	*/
	@Test(priority = 1, dataProvider = "SanityTest", dataProviderClass = utility.Xlsdataprovider.class)
	public void TimeLoad_TC1(LinkedHashMap<String, String> data) throws InterruptedException, SQLException {
		
		DataSet++;
		TestCaseName = data.get("TestCaseName");
		CaseToRun = data.get("CaseToRun");
		String url = data.get("URL");
		String apiName = data.get("ApiName");
		String inputParameter = data.get("InputParameter");
		String body = getData(data, "Body");
		String Role = getData(data,"Role");
		//String exp_option = getData(data, "ExpectedOptions");

		if (CaseToRun.equalsIgnoreCase("N")) {
			System.out.println(TestCaseName + " : CaseToRun = N for So Skipping Execution.");
			Testskip = true;
			throw new SkipException(
					TestCaseName + "'s CaseToRun Flag Is 'N' Or Blank. So Skipping Execution Of " + TestCaseName);
		} else {

			/*for (String Key : URLs.keySet()) {
				System.out.println(URLs.get(Key));
				credentials = TestCaseListExcelsearchContains.getLoginCredentials("Users", Role);
				for (int j = 0; j < credentials.size(); j++) {
					users = credentials.get(j);
					System.out.println(users.get("username"));
					System.out.println(users.get("password"));
					username = users.get("username");
					password = users.get("password");
				}*/
				//driver.get(URLs.get(Key));
				totalTime= objLoginPage.apiTest1(url,apiName,inputParameter,body);
				
				//totalTime = (end - start) / 1000;
				String totaltime = df.format(totalTime);
				SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad", DataSet + 1, totaltime);
				/*if (Key.equalsIgnoreCase("UAT")) {
					SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_UAT", DataSet + 1, totaltime);
				} else if (Key.equalsIgnoreCase("PROD")) {
					SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_PROD", DataSet + 1, totaltime);
				} else if (Key.equalsIgnoreCase("SIT")) {
						SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_SIT", DataSet + 1, totaltime);
				}*/
				//driver.manage().deleteAllCookies();

			}

		}

	
	
	@AfterMethod
	public void reporterDataResults(ITestResult Result) {
		Testfail = TestResultStatus.Testfail;
		System.out.println("test fail flag in AfterMethod: " + Testfail);
		if (Testskip) {

			String str = "0";
			totalTime = 0;
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_UAT", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_PROD", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_SIT", DataSet + 1, str);

			Add_Log.info(TestCaseName + " : Reporting test data set line " + (DataSet + 1) + " as SKIP In excel.");
			// If found Testskip = true, Result will be reported as SKIP against
			// data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", DataSet + 1, "SKIP");

		} else if (Testfail) {
			Add_Log.info(TestCaseName + " : Reporting test data set line " + (DataSet + 1) + " as FAIL In excel.");
			// To make object reference null after reporting In report.
			if (!(driver == null)) {
				// closeWebBrowser();
			}

			String str = "0";
			totalTime = 0;
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_UAT", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_PROD", DataSet + 1, str);
			SuiteUtility.WriteResultUtility1(FilePath, SheetName, "TimeLoad_SIT", DataSet + 1, str);

			TestCasePass = false;
			// If found Testfail = true, Result will be reported as FAIL against
			// data set line In excel sheet.

			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", DataSet + 1, "FAIL");

			driver.manage().deleteAllCookies();
			// driver.close();
			// Reporter.log(Result.getMethod().getMethodName()+" failed.");

		} else {
			if (!(driver == null)) {
				// closeWebBrowser();
			}

			System.out.println(df.format(totalTime));
			System.out.println("Total Time for page load - " + totalTime);

			Add_Log.info(TestCaseName + " : Reporting test data set line " + (DataSet + 1) + " as PASS In excel.");
			// If found Testskip = false and Testfail = false, Result will be
			// reported as PASS against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", DataSet + 1, "PASS");
			driver.manage().deleteAllCookies();
			// driver.close();

		}
		// At last make both flags as false for next data set.

		Testskip = false;
		TestResultStatus.Testfail = false;
		// driver.close();

	}

	/*@AfterTest
	public void testUp() {
		driver.close();
		driver.quit();
	}*/

	@AfterSuite
	public void aftersuite() {
		cpyExcel.copyXlsFiles();
	}
}

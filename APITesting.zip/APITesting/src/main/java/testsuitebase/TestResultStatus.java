package testsuitebase;

public class TestResultStatus {
	public static boolean Testfail=false;
}

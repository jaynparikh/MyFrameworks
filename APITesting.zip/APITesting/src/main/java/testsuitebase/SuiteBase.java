//Find More Tutorials On WebDriver at -> http://software-testing-tutorials-automation.blogspot.com
package testsuitebase;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;


import pageobjects.APIFunctions;

import utility.CopyExcel;
import utility.FetchExcelDataSet;
import utility.Read_XLS;
import utility.ScreenshotUtility;
import utility.SeleniumUtils;

public class SuiteBase {	

	public Read_XLS TestCaseListExcelOne=null;
	public Read_XLS TestCaseListExcelsearch=null;
	public Read_XLS TestCaseListExcelsearchContains=null;
	public Read_XLS TestCaseListExceResultContains=null;
	public Logger Add_Log = null;
	public Properties Config = null;
	public static WebDriver driver = null;
	public String CaseToRun = null;
	public APIFunctions objLoginPage = new APIFunctions();
	public SeleniumUtils utils = new SeleniumUtils();
	public ScreenshotUtility screenutility =new ScreenshotUtility();
	
	public CopyExcel cpyExcel = new CopyExcel();
	
	protected FetchExcelDataSet objFD = new FetchExcelDataSet();
	
	public String sysRating = null;
	public String IPRID = null;
	public WebDriver ExistingchromeBrowser;
	public WebDriver ExistingmozillaBrowser;
	public WebDriver ExistingIEBrowser;	
	
	public HashMap<String, String> URLs = null;

    public ArrayList<HashMap<String, String>> credentials = null;

    public HashMap<String, String> users = null;

    public String username = null;
    public String password = null;
	/*public static int DataSet=-1;	
	public static boolean Testskip=false;
	public static boolean Testfail=false;
	public static boolean TestCasePass=true;*/
	
	public void init() throws IOException{
		//To Initialize logger service.
		Add_Log = Logger.getLogger("rootLogger");				
		

		TestCaseListExcelsearchContains = new Read_XLS(System.getProperty("user.dir")+"\\src/main/resources\\ExcelFiles\\Dashboard_Tests.xls");
	
		//Bellow given syntax will Insert log In applog.log file.
		Add_Log.info("All Excel Files Initialised successfully.");
		
		//Create object of Java Properties class
		Config = new Properties();
		FileInputStream fip = new FileInputStream(System.getProperty("user.dir")+"\\src/main/resources\\Config\\Config.properties");
		Config.load(fip);
		Add_Log.info("Config.properties file loaded successfully.");
		

	}
	
	public void loadWebBrowser(){
		if(Config.getProperty("testBrowser").equalsIgnoreCase("Mozilla") && ExistingmozillaBrowser!=null){
			driver = ExistingmozillaBrowser;
			return;
		}else if(Config.getProperty("testBrowser").equalsIgnoreCase("chrome") && ExistingchromeBrowser!=null){
			driver = ExistingchromeBrowser;
			return;
		}else if(Config.getProperty("testBrowser").equalsIgnoreCase("IE") && ExistingIEBrowser!=null){
			driver = ExistingIEBrowser;
			return;
		}	
		
		if(Config.getProperty("testBrowser").equalsIgnoreCase("Mozilla")){
			//To Load Firefox driver Instance. 
			driver = new FirefoxDriver();			
			Add_Log.info("Firefox Driver Instance loaded successfully.");
			
		}else if(Config.getProperty("testBrowser").equalsIgnoreCase("Chrome")){
			//To Load Chrome driver Instance.
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src/main/resources\\BrowserDrivers\\chromedriver.exe");
			/*driver = new ChromeDriver();*/
			String downloadFilepath = System.getProperty("user.dir")+"\\src\\ExcelFiles\\";
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", downloadFilepath);
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", chromePrefs);
			DesiredCapabilities cap = DesiredCapabilities.chrome();
			cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			cap.setCapability(ChromeOptions.CAPABILITY, options);
			driver = new ChromeDriver(cap);
			Add_Log.info("Chrome Driver Instance loaded successfully.");
			
		}else if(Config.getProperty("testBrowser").equalsIgnoreCase("IE")){
			//To Load IE driver Instance.
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\src/main/resources\\BrowserDrivers\\IEDriverServer.exe");	
			driver = new InternetExplorerDriver();
			Add_Log.info("IE Driver Instance loaded successfully.");			
		}		
		
		
		
		driver.manage().window().maximize();
		//driver.get(Config.getProperty("url"));
		/*driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);*/
	}
	
	public void closeWebBrowser(){
		driver.close();
		driver.quit();
		//null browser Instance when close.

	}
	
	public String getData(LinkedHashMap<String, String> data,String key){
		if(data.get(key)!=null && data.get(key).length()>0){
			return data.get(key);
		}else{
			return "";
		}
		
	}
}

package pageobjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.config.SSLConfig;



import static com.jayway.restassured.RestAssured.given;
import static org.testng.Assert.fail;

import property.ICommonElements;
import property.ILoginPage;
import testsuitebase.TestResultStatus;
import utility.SeleniumUtils;


public class APIFunctions extends SeleniumUtils implements ILoginPage,ICommonElements
{
	

	public long apiTest1(String url ,String apiName, String inputParameter,String body){
			int statusCode = apiResponseCode(url, apiName, inputParameter, body);
			long time = apiTime(url, apiName, inputParameter, body);
			
			if(statusCode!=200) {
				TestResultStatus.Testfail = true;
				Assert.fail();
			}
			
			return time;
			
			
	}
	
	public long apiTime(String url ,String apiName, String inputParameter,String body){
		long time = given().config(RestAssured.config().sslConfig(new SSLConfig().
				relaxedHTTPSValidation())).contentType("application/json").body(body).
			when().get(url+apiName+inputParameter).then().extract().
			response().getTimeIn(TimeUnit.MILLISECONDS);
		return time;
		
	}
	
	public int apiResponseCode(String url ,String apiName, String inputParameter,String body) {
		int statusCode = given().config(RestAssured.config().sslConfig(new SSLConfig().
				relaxedHTTPSValidation())).contentType("application/json").body(body).
			when().get(url+apiName+inputParameter).then().extract().
			response().getStatusCode();
		
		return statusCode;
	}
	
	

	
}

package models;

public class Validations {
	String required = "";
	String validregex = "";
	String invalidregex = "";
	
	public String getRequired() {
		return required;
	}
	public void setRequired(String required) {
		this.required = required;
	}
	public String getValidregex() {
		return validregex;
	}
	public void setValidregex(String validregex) {
		this.validregex = validregex;
	}
	public String getInvalidregex() {
		return invalidregex;
	}
	public void setInvalidregex(String invalidregex) {
		this.invalidregex = invalidregex;
	}
	
	
}

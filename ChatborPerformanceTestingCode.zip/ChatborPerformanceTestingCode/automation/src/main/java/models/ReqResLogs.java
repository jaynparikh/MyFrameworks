	package models;
	import java.io.Serializable;

import configurations.StaticConfiguration;
	import models.Attributes;
	import models.States;
	import models.Validations;

	public class ReqResLogs implements Serializable{
		
		String reqStartTime = "";
	    String reqEndTime = "";    
	    String reqTotalTime = "";
	    public String getReqStartTime() {
			return reqStartTime;
		}
		public void setReqStartTime(String reqStartTime) {
			this.reqStartTime = reqStartTime;
		}
		public String getReqEndTime() {
			return reqEndTime;
		}
		public void setReqEndTime(String reqEndTime) {
			this.reqEndTime = reqEndTime;
		}
		public String getReqTotalTime() {
			return reqTotalTime;
		}
		public void setReqTotalTime(String reqTotalTime) {
			this.reqTotalTime = reqTotalTime;
		}
		public String getValueEntered() {
			return valueEntered;
		}
		public void setValueEntered(String valueEntered) {
			this.valueEntered = valueEntered;
		}
		String valueEntered = "";
	    
	}

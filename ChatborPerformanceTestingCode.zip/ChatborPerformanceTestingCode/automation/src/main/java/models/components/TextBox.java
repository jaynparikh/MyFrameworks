package models.components;

import models.ComponentResponseBean;

public class TextBox extends ComponentResponseBean{
	
}

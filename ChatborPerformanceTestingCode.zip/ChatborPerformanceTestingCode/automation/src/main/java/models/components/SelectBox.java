package models.components;
import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;
import java.util.List;

import configurations.StaticConfiguration;
import models.ComponentResponseBean;
import models.Values;

public class SelectBox extends ComponentResponseBean{
	List<Values> data;

	public List<Values> getData() {
		return data;
	}

	public void setData(String data) {
		Type listType = new TypeToken<List<Values>>() {}.getType();
		this.data = StaticConfiguration.gson.fromJson(data, listType);
	}
	
}

package models;

import java.io.Serializable;
import java.util.ArrayList;

import configurations.StaticConfiguration;

public class LogFileDetails implements Serializable {
	// default serialVersion id
	private static final long serialVersionUID = 1L;

	String sessionID = "";

	String exeStartTime = "";
	String exeEndTime = "";
	String exeTotalTime = "";

	String connectionStartTime = "";
	String connectionEndTime = "";
	String connectionTotalTime = "";

	String formFillUpStartTime = "";
	String formFillUpEndTime = "";
	String formTotalTime = "";

	String compAvgTime = "";
	String reqAvgTime = "";

	public ArrayList<ComponentLogs> clArrayList = new ArrayList<ComponentLogs>();
	public ArrayList<ReqResLogs> rrlArrayList = new ArrayList<ReqResLogs>();

	public String getReqAvgTime() {
		return reqAvgTime;
	}

	public void setReqAvgTime(String reqAvgTime) {
		this.reqAvgTime = reqAvgTime;
	}

	public ArrayList<ReqResLogs> getRrlArrayList() {
		return rrlArrayList;
	}

	public void setRrlArrayList(ArrayList<ReqResLogs> rrlArrayList) {
		this.rrlArrayList = rrlArrayList;
	}

	public void addComponentLogs(ComponentLogs cl) {
		cl.compTotalTime = StaticConfiguration.timeDifference(cl.compStartTime, cl.compEndTime);

		System.out.println("Component started filling on 	\t" + cl.compStartTime);
		System.out.println("Component ended filling on 		" + cl.compEndTime);
		System.out.println("Component fill up time  		" + cl.compTotalTime);

		this.clArrayList.add(cl);
	}

	public void addReqResLogs(ReqResLogs rrl) {
		rrl.reqTotalTime = StaticConfiguration.timeDifference(rrl.reqStartTime, rrl.reqEndTime);

		System.out.println("Req Value	" + rrl.valueEntered);
		System.out.println("Req Start	" + rrl.reqStartTime);
		System.out.println("Req End		" + rrl.reqEndTime);
		System.out.println("Req Total	" + rrl.reqTotalTime);

		this.rrlArrayList.add(rrl);
	}

	public ArrayList<ComponentLogs> getClArrayList() {
		return clArrayList;
	}

	public void setClArrayList(ArrayList<ComponentLogs> clArrayList) {
		this.clArrayList = clArrayList;
	}

	public void calculateTotalTime() {
		exeTotalTime = StaticConfiguration.timeDifference(exeStartTime, exeEndTime);
		connectionTotalTime = StaticConfiguration.timeDifference(connectionStartTime, connectionEndTime);
		formTotalTime = StaticConfiguration.timeDifference(formFillUpStartTime, formFillUpEndTime);

		long totalCompTime = 0;
		for (int counter = 0; counter < getClArrayList().size(); counter++) {
			ComponentLogs cl = getClArrayList().get(counter);
			totalCompTime += StaticConfiguration.convertMill(cl.getCompTotalTime());
		}

		compAvgTime = StaticConfiguration.getAverageTime(totalCompTime, getClArrayList().size());

		long totalReqTime = 0;
		for (int counter = 0; counter < getRrlArrayList().size(); counter++) {
			ReqResLogs cl = getRrlArrayList().get(counter);
			totalReqTime += StaticConfiguration.convertMill(cl.getReqTotalTime());
		}

		reqAvgTime = StaticConfiguration.getAverageTime(totalReqTime, getRrlArrayList().size());
	}

	public String getCompAvgTime() {
		return compAvgTime;
	}

	public void setCompAvgTime(String compAvgTime) {
		this.compAvgTime = compAvgTime;
	}

	@Override
	public String toString() {
		return new StringBuffer("Execution Start Time: ").append(this.exeStartTime).append(" \nExecution End Time: ")
				.append(this.exeEndTime).append(" \nForm Fillup Start Time: ").append(this.formFillUpStartTime)
				.append(" \nForm Fillup Start Time: ").append(this.formFillUpEndTime)
				.append(" \nConnection Start Time: ").append(this.exeStartTime).append(" \nConnection End Time: ")
				.append(this.exeStartTime).append(" \nSession ID: ").append(this.sessionID).toString();
	}

	public String getExeTotalTime() {
		return exeTotalTime;
	}

	public void setExeTotalTime(String exeTotalTime) {
		this.exeTotalTime = exeTotalTime;
	}

	public String getConnectionTotalTime() {
		return connectionTotalTime;
	}

	public void setConnectionTotalTime(String connectionTotalTime) {
		this.connectionTotalTime = connectionTotalTime;
	}

	public String getFormTotalTime() {
		return formTotalTime;
	}

	public void setFormTotalTime(String formTotalTime) {
		this.formTotalTime = formTotalTime;
	}

	public String getSessionID() {
		return sessionID;
	}

	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}

	public String getExeStartTime() {
		return exeStartTime;
	}

	public void setExeStartTime(String exeStartTime) {
		this.exeStartTime = exeStartTime;
	}

	public String getExeEndTime() {
		return exeEndTime;
	}

	public void setExeEndTime(String exeEndTime) {
		this.exeEndTime = exeEndTime;
	}

	public String getConnectionStartTime() {
		return connectionStartTime;
	}

	public void setConnectionStartTime(String connectionStartTime) {
		this.connectionStartTime = connectionStartTime;
	}

	public String getConnectionEndTime() {
		return connectionEndTime;
	}

	public void setConnectionEndTime(String connectionEndTime) {
		this.connectionEndTime = connectionEndTime;
	}

	public String getFormFillUpStartTime() {
		return formFillUpStartTime;
	}

	public void setFormFillUpStartTime(String formFillUpStartTime) {
		this.formFillUpStartTime = formFillUpStartTime;
	}

	public String getFormFillUpEndTime() {
		return formFillUpEndTime;
	}

	public void setFormFillUpEndTime(String formFillUpEndTime) {
		this.formFillUpEndTime = formFillUpEndTime;
	}
}

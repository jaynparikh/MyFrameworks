package models;

public class Attributes {
	String formatRegEx = "";
	String isUppercase = "";
	String width = "";
	String medium = "";
	String rows = "";
	String maxLength = "";
	String hint = "";
	
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getMedium() {
		return medium;
	}
	public void setMedium(String medium) {
		this.medium = medium;
	}
	public String getRows() {
		return rows;
	}
	public void setRows(String rows) {
		this.rows = rows;
	}
	public String getFormatRegEx() {
		return formatRegEx;
	}
	public void setFormatRegEx(String formatRegEx) {
		this.formatRegEx = formatRegEx;
	}
	public String getIsUppercase() {
		return isUppercase;
	}
	public void setIsUppercase(String isUppercase) {
		this.isUppercase = isUppercase;
	}
	public String getMaxLength() {
		return maxLength;
	}
	public void setMaxLength(String maxLength) {
		this.maxLength = maxLength;
	}
}

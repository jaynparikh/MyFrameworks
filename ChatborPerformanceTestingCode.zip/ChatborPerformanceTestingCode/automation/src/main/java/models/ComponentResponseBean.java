	package models;
	import configurations.StaticConfiguration;
	import models.Attributes;
	import models.States;
	import models.Validations;

	public class ComponentResponseBean {
		String componentType = "";
		String id = "";
		String key = "";
		String label = "";
		String value = "";
		String token = "";
		String formName = "";
		String parentnode = "";
		String hasFAQ = "";
		String topic = "";
		String message = "";
		int status = 0;
		Validations validation = new Validations();
		Attributes attributes = new Attributes();
		States states = new States();
		boolean hidden = false;
		boolean validValue = false;
		boolean disabled = false;
		boolean currentQuestion = false;
		boolean required = true;
		int maxLength = 100;
		int minLength = 0;
		String validRegx = "";
		String inValidRegx = "";
		String timestamp = "";
		
		
		public boolean isRequired() {
			return required;
		}
		public void setRequired(boolean required) {
			this.required = required;
		}
		public int getMaxLength() {
			return maxLength;
		}
		public void setMaxLength(int maxLength) {
			this.maxLength = maxLength;
		}
		public int getMinLength() {
			return minLength;
		}
		public void setMinLength(int minLength) {
			this.minLength = minLength;
		}
		public String getInValidRegx() {
			return inValidRegx;
		}
		public void setInValidRegx(String inValidRegx) {
			this.inValidRegx = inValidRegx;
		}
		public String getTimestamp() {
			return timestamp;
		}
		public void setTimestamp(String timestamp) {
			this.timestamp = timestamp;
		}
		public void setAttributes(Attributes attributes) {
			this.attributes = attributes;
		}
		public void setStates(States states) {
			this.states = states;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public int getStatus() {
			return status;
		}
		public void setStatus(int status) {
			this.status = status;
		}
		public String getValidRegx() {
			return validRegx;
		}
		public void setValidRegx(String validRegx) {
			this.validRegx = validRegx;
		}
		public void setValidation(Validations validation) {
			this.validation = validation;
		}
		public String getComponentType() {
			return componentType;
		}
		public void setComponentType(String componentType) {
			this.componentType = componentType;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getKey() {
			return key;
		}
		public void setKey(String key) {
			this.key = key;
		}
		public String getLabel() {
			return label;
		}
		public void setLabel(String label) {
			this.label = label;
		}
		public String getValue() {
			return value;
		}
		public void setValue(String value) {
			this.value = value;
		}
		public String getToken() {
			return token;
		}
		public void setToken(String token) {
			this.token = token;
		}
		public String getFormName() {
			return formName;
		}
		public void setFormName(String formName) {
			this.formName = formName;
		}
		public String getParentnode() {
			return parentnode;
		}
		public void setParentnode(String parentnode) {
			this.parentnode = parentnode;
		}
		public String getHasFAQ() {
			return hasFAQ;
		}
		public void setHasFAQ(String hasFAQ) {
			this.hasFAQ = hasFAQ;
		}
		public String getTopic() {
			return topic;
		}
		public void setTopic(String topic) {
			this.topic = topic;
		}
		public Validations getValidation() {
			return this.validation;
		}
		public void setValidation(String validation) {
			this.validation = StaticConfiguration.gson.fromJson(validation, Validations.class);
		}
		public Attributes getAttributes() {
			return attributes;
		}
		public void setAttributes(String attributes) {
			this.attributes = StaticConfiguration.gson.fromJson(attributes, Attributes.class);
		}
		public States getStates() {
			return states;
		}
		public void setStates(String states) {
			this.states = StaticConfiguration.gson.fromJson(states, States.class);
		}
		public boolean isHidden() {
			return hidden;
		}
		public void setHidden(boolean hidden) {
			this.hidden = hidden;
		}
		public boolean isValidValue() {
			return validValue;
		}
		public void setValidValue(boolean validValue) {
			this.validValue = validValue;
		}
		public boolean isDisabled() {
			return disabled;
		}
		public void setDisabled(boolean disabled) {
			this.disabled = disabled;
		}
		public boolean isCurrentQuestion() {
			return currentQuestion;
		}
		public void setCurrentQuestion(boolean currentQuestion) {
			this.currentQuestion = currentQuestion;
		}	

	}

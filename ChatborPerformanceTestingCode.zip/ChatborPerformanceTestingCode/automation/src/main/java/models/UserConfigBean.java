package models;

import org.json.JSONException;
import org.json.JSONObject;

public class UserConfigBean {

	String userId;
	String password;
	String botlibre;
	String wsAppId;
	String wsPassword;
	String wsVersion;
	String wsId;
	
	public UserConfigBean(String userId, String password, String botlibre, String wsAppId, String wsPassword,
			String wsVersion, String wsId) {
		super();
		this.userId = userId;
		this.password = password;
		this.botlibre = botlibre;
		this.wsAppId = wsAppId;
		this.wsPassword = wsPassword;
		this.wsVersion = wsVersion;
		this.wsId = wsId;
	}

	public JSONObject toJSON() {
		JSONObject userConfig = new JSONObject();
		try {
			userConfig.put("userId", this.userId);
			userConfig.put("password", this.password);
			userConfig.put("botlibre", this.botlibre);
			userConfig.put("wsAppId", this.wsAppId);
			userConfig.put("wsPassword", this.wsPassword);
			userConfig.put("wsVersion", this.wsVersion);
			userConfig.put("wsId", this.wsId);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userConfig;
	}
	
	public String toSting() {
		
		System.out.println("To String Called");
		return toJSON().toString();
	}
	
	public UserConfigBean() {
		super();
	}


	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBotlibre() {
		return botlibre;
	}
	public void setBotlibre(String botlibre) {
		this.botlibre = botlibre;
	}
	public String getWsAppId() {
		return wsAppId;
	}
	public void setWsAppId(String wsAppId) {
		this.wsAppId = wsAppId;
	}
	public String getWsPassword() {
		return wsPassword;
	}
	public void setWsPassword(String wsPassword) {
		this.wsPassword = wsPassword;
	}
	public String getWsVersion() {
		return wsVersion;
	}
	public void setWsVersion(String wsVersion) {
		this.wsVersion = wsVersion;
	}
	public String getWsId() {
		return wsId;
	}
	public void setWsId(String wsId) {
		this.wsId = wsId;
	}
	
}

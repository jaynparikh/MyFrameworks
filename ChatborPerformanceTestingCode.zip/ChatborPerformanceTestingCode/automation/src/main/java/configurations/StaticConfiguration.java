package configurations;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.text.ParseException;
import com.google.gson.Gson;
import com.google.gson.JsonParser;

import models.ComponentLogs;
import models.LogFileDetails;
import models.ReqResLogs;
import models.UserConfigBean;

public class StaticConfiguration {
	// Device Details
	//public static String SERVER_URL = "http://74.122.121.204:3000"; // Will be used to control server URL
	
	public static String SERVER_URL = "https://chatbot.streebo.com:3000"; // Will be used to control server URL
	
	public static String W_USER_NAME = "6f14e8d2-d6c5-4b4f-a06e-d00543a84ac8";
	public static String W_PASSWORD = "tGtZeVJ3Zmar";
	public static String W_ID = "5c93535b-9f6b-4b34-93f6-de2301da1c5a";
	public static String W_MESSAGE = "Enter Employee Detail";
	public static String W_VERSION = "2017-05-26";
	
	public static String FEB_USER_NAME = "radha.basida@streebo.com";
	public static String FEB_PASS = "radha123";
	
	public static String BOT_LIBRE = "false";
		
	public static String FEB_URL = "http://198.176.30.251:10039"; // Will be used to control FEB URL
	public static String INTENT_SERVICE_URL = "https://dxauat.streebo.com:3000"; // Will be used to control FEB URL
	
	public static String APP_ID = "f1e25be8-92f9-4024-8746-b60152a67f85"; // Will be used to control App ID
	public static String FORM_ID = "F_employeeForm"; // Will be used to control Form ID
	public static String INTENT = ""; // Will be used to control Form ID
	
	public static UserConfigBean USER_CONFIG = new UserConfigBean();
	public static String DATAPROVIDER_SHEET = "Dataprovider.xls"; // Change as per your data provider name
	public static Gson gson = new Gson(); // Library Used For Parsing JSON Objects and Arrays
	
	public static JsonParser jsonParser = new JsonParser();
	
	public static boolean formSubmitted = false;
	
	public static String ConnectionID = "";
	public static ArrayList<LogFileDetails> logsArray;
	
	public static int connector = 10;
	
	public static ComponentLogs componentLogs = null;
	public static ReqResLogs reqResLogs = null;
	
	//public static ArrayList<ComponentBean> = new Arr; 
	public static String time() {
		return new SimpleDateFormat("HH:mm:ss:SSS").format(new Date());
	}
	
	public static String addtime(long addTime) {
		return new SimpleDateFormat("HH:mm:ss:SSS").format(new Date(new Date().getTime() + addTime));
	}
	
	public static String timestamp() {
		return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());
	}
	
	
	public static String timeDifference(String start,String end) {
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss:SSS", Locale.ENGLISH); 
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		
		try {
			Date startTime = format.parse(start);
			Date endTime = format.parse(end);
			Date difference = new Date((endTime.getTime() - startTime.getTime()));
			return format.format(difference);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return "";
	}
	
	public static String maxTime(String first,String second) {
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss:SSS", Locale.ENGLISH); 
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		try {
			Date firstTime = format.parse(first);
			Date secondTime = format.parse(second);
			Date difference = new Date((firstTime.getTime() - secondTime.getTime()));
			
			if(difference.getTime() > 0) {
				return first;
			}
			else
			{
				return second;
			}
		
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return "";
	}
	
	public static String minTime(String first,String second) {
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss:SSS", Locale.ENGLISH); 
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		try {
			Date firstTime = format.parse(first);
			Date secondTime = format.parse(second);
			Date difference = new Date((firstTime.getTime() - secondTime.getTime()));
			
			if(difference.getTime() > 0) {
				return second;
			}
			else
			{
				return first;
			}
		
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return "";
	}

	public static long convertMill(String time) {	
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss:SSS", Locale.ENGLISH);
		
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date date = null;
		try {
			date = format.parse(time);
			
			return date.getTime();
		} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		return 0;
	}
	
	public static String getAverageTime(long milliseconds,int total) {
		long avg = 0;
		try {
			 avg = milliseconds / total;	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss:SSS", Locale.ENGLISH); 
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		Date first = new Date();
		Date second = new Date(first.getTime() + avg);
		return format.format(new Date((second.getTime() - first.getTime()))); 
	}


	public static String date() {
		return new SimpleDateFormat("dd-MM-yyyy").format(new Date());
	}

}

package configurations;


public class ConfigurationVariables {				
	public io.socket.client.Socket socket;
}


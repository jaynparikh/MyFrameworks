package connector;

import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import configurations.StaticConfiguration;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import models.ComponentLogs;
import models.ComponentResponseBean;
import models.LogFileDetails;
import models.ReqResLogs;
import models.UserConfigBean;
import models.components.SelectBox;
import models.components.TextArea;
import models.components.TextBox;
import utility.FileUtility;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;

import java.util.Base64;
import java.util.Date;

public class Connector {
	// public class Connector implements JavaSamplerClient{

	// JSONParser parser = new JSONParser(); JSONObject json = (JSONObject)
	// parser.parse(stringToParse);

	static Gson gson = new Gson(); // Library Used For Parsing JSON Objects and Arrays
	static io.socket.client.Socket socket;
	static UserConfigBean userConfigBean = new UserConfigBean();

	public static void main(String[] args) {

		// Connector.getIntentInfo(StaticConfiguration.W_MESSAGE);
		Connection(); // Session Connector
		
		//FileUtility.createTestSupportFiles();
	 //FileUtility.readSummary(); // Read Summary
		// FileUtility.createSummary();
	}

	public static void connectToServer(String url) {
		try {
			IO.Options opts = new IO.Options();
			// opts.forceNew = true;
			opts.reconnection = false;
			opts.timeout = 1000000;
			opts.secure = true;

			Connector.socket = IO.socket(url, opts);
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	public static void waitForDuration(long milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Exeception In Thread");
			e.printStackTrace();
		}
	}

	public static void getIntentInfo(String keyword) {
		try {
			URL url = new URL(StaticConfiguration.INTENT_SERVICE_URL + "/feb/wintentdetails");
			URLConnection con = url.openConnection();
			HttpURLConnection http = (HttpURLConnection) con;
			http.setRequestMethod("POST"); // PUT is another valid option
			http.setRequestProperty("Accept", "application/json");
			http.setRequestProperty("Content-Type", "application/json");
			http.setDoOutput(true);

			JSONObject userConfig = new JSONObject();
			try {
				userConfig.put("username", StaticConfiguration.W_USER_NAME);
				userConfig.put("password", StaticConfiguration.W_PASSWORD);
				userConfig.put("wsid", StaticConfiguration.W_ID);
				userConfig.put("message", keyword);

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			byte[] out = userConfig.toString().getBytes(StandardCharsets.UTF_8);

			int length = out.length;

			http.setFixedLengthStreamingMode(length);
			http.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
			http.connect();

			try (OutputStream os = http.getOutputStream()) {
				os.write(out);
			}

			String result = "";
			InputStream content = (InputStream) http.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(content));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
			System.out.println(result);

			JsonObject jo = StaticConfiguration.jsonParser.parse(result).getAsJsonObject();

			System.out.println();
			System.out.println("***************** DATA Fetched For Intent Service ******************");
			System.out.println("intent				" + jo.get("intent").getAsString());
			System.out.println("appid				" + jo.get("appid").getAsString());
			System.out.println("formid				" + jo.get("formid").getAsString());
			System.out.println("isInApp				" + jo.get("isInApp").getAsString());
			System.out.println("*******************************************************************");

			StaticConfiguration.INTENT = jo.get("intent").getAsString();
			StaticConfiguration.APP_ID = jo.get("appid").getAsString();
			StaticConfiguration.FORM_ID = jo.get("formid").getAsString();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void setUserConfig() {
		Connector.userConfigBean.setUserId(StaticConfiguration.FEB_USER_NAME);
		Connector.userConfigBean.setPassword(StaticConfiguration.FEB_PASS);
		Connector.userConfigBean.setBotlibre(StaticConfiguration.BOT_LIBRE);
		Connector.userConfigBean.setWsAppId(StaticConfiguration.W_USER_NAME);
		Connector.userConfigBean.setWsPassword(StaticConfiguration.W_PASSWORD);
		Connector.userConfigBean.setWsVersion(StaticConfiguration.W_VERSION);
		Connector.userConfigBean.setWsId(StaticConfiguration.W_ID);
		// System.out.println("User Config" +
		// Connector.userConfigBean.toJSON().toString());
		Connector.sendMessageToServer(Connector.userConfigBean.toJSON().toString());
	}

	public static void sendMessageToServer(String value) {
		System.out.println("Request Start Time Captured");
		System.out.println("Client is sending \" " + value + " \" to server");
		StaticConfiguration.reqResLogs = new ReqResLogs();
		StaticConfiguration.reqResLogs.setValueEntered(value);
		StaticConfiguration.reqResLogs.setReqStartTime(StaticConfiguration.time());
		Connector.socket.emit("message from client", value);
	}

	public static void disconnect() {
		if (Connector.socket.connected()) {
			Connector.socket.disconnect();
		}
	}

	public static void resetChat() {
		if (Connector.socket.connected()) {
			Connector.socket.disconnect();
		}
		Connector.connectToServer(StaticConfiguration.SERVER_URL);
	}

	public static void Connection() {
		final LogFileDetails lfd = new LogFileDetails();

		lfd.setExeStartTime(StaticConfiguration.time());
		connectToServer(StaticConfiguration.SERVER_URL); // Connect to server first

		// FileUtility.readSummary();

		// Bind Events Listener With Connector

		Connector.socket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {

			public void call(Object... args) {
				lfd.setConnectionStartTime(StaticConfiguration.time());
				System.out.println("Connected");

				Connector.sendMessageToServer("connected"); // Ack server that client is connected with server
				Connector.setUserConfig(); // Set user configuration to server

				if (Connector.socket.connected()) {
					Connector.sendMessageToServer(StaticConfiguration.W_MESSAGE);
				}


			}

		}).on("message from server", new Emitter.Listener() {

			public void call(Object... args) {

				if (StaticConfiguration.reqResLogs != null) {
					System.out.println("Request End Time Captured");
					StaticConfiguration.reqResLogs.setReqEndTime(StaticConfiguration.time());
					lfd.addReqResLogs(StaticConfiguration.reqResLogs);
					StaticConfiguration.reqResLogs = null;
				}

				try {

					JSONObject jo = (JSONObject) args[0];
					System.out.println("Message From Server Received");
					System.out.println(jo);
					// System.out.println(jo.get("data"));

					JSONObject message = new JSONObject(jo.get("data").toString());

					if (message.has("isIntentRequest")) {
						System.out.println("Intent Called	" + message.getString("intentValue"));
						lfd.setFormFillUpStartTime(StaticConfiguration.time());
					}
					else if (message.has("message")) {
						System.out.println("Message");

						String messageData = message.getString("message");
						
						if (messageData.equalsIgnoreCase("Your data has been successfully submitted.")) {
							System.out.println("Data Is Submiteed Succesfully");
							StaticConfiguration.formSubmitted = true;
							StaticConfiguration.componentLogs.setCompEndTime(StaticConfiguration.time());
							lfd.addComponentLogs(StaticConfiguration.componentLogs);
							StaticConfiguration.componentLogs = null;
						} else if (messageData
								.equalsIgnoreCase("There is some trouble in understanding you.")) {
							System.out.println("There is some trouble in understanding you.");
							lfd.setConnectionEndTime(StaticConfiguration.time());
							lfd.setSessionID("Fail_"+Connector.socket.id());
							lfd.setExeEndTime(StaticConfiguration.time());
							lfd.calculateTotalTime();
							FileUtility.writeLogs("Fail_" + Connector.socket.id(), lfd);
						} else if (messageData
								.equalsIgnoreCase("I didn't understand. You can try rephrasing.")) {
							System.out.println("I didn't understand. You can try rephrasing.");
							lfd.setConnectionEndTime(StaticConfiguration.time());
							lfd.setSessionID("Fail_"+Connector.socket.id());
							lfd.setExeEndTime(StaticConfiguration.time());
							lfd.calculateTotalTime();
							FileUtility.writeLogs("Fail_" + Connector.socket.id()+ "_time_" + new Date().getTime(), lfd);
						} else if (messageData.equalsIgnoreCase("What else can I help you with?")) {
							System.out.println("Execution Is Over");
							lfd.setFormFillUpEndTime(StaticConfiguration.time());

							// Connector.disconnect();
							if (StaticConfiguration.formSubmitted) {
								lfd.setConnectionEndTime(StaticConfiguration.time());
								lfd.setSessionID(Connector.socket.id());
								lfd.setExeEndTime(StaticConfiguration.time());

								lfd.calculateTotalTime();
								FileUtility.writeLogs(Connector.socket.id() + "_time_" + new Date().getTime(), lfd);
								// System.exit(0);
								// FileUtility.readSummary();
							} else {
								lfd.setConnectionEndTime(StaticConfiguration.time());
								lfd.setSessionID("Fail_"+Connector.socket.id());
								lfd.setExeEndTime(StaticConfiguration.time());
								lfd.calculateTotalTime();
								FileUtility.writeLogs("Fail_" + Connector.socket.id()+ "_time_" + new Date().getTime(), lfd);
							}

							// Connector.validateEntry();
							// System.exit(0);

						}
						else {
						
						ComponentResponseBean cb = StaticConfiguration.gson.fromJson(message.get("message").toString(),
								ComponentResponseBean.class);
						if (StaticConfiguration.componentLogs == null) {
							StaticConfiguration.componentLogs = new ComponentLogs(cb);
							StaticConfiguration.componentLogs.setCompStartTime(StaticConfiguration.time());
						} else {
							StaticConfiguration.componentLogs.setCompEndTime(StaticConfiguration.time());
							lfd.addComponentLogs(StaticConfiguration.componentLogs);
							StaticConfiguration.componentLogs = new ComponentLogs(cb);
							StaticConfiguration.componentLogs.setCompStartTime(StaticConfiguration.time());
						}
						
						System.out.println("Component Type " + cb.getComponentType());
						System.out.println("Component Label " + cb.getLabel());
						System.out.println("Validations " + cb.getValidation().getRequired());
						System.out.println("Invaid Regx " + cb.getValidation().getInvalidregex());
						System.out.println("Valid Regx " + cb.getValidation().getValidregex());
						System.out.println("Max Length " + cb.getAttributes().getMaxLength());
						
						cb.setTimestamp(message.getString("timestamp"));
						
						System.out.println("Time Stamp " + cb.getTimestamp());
							
							if (cb.getComponentType().equalsIgnoreCase("textbox")) {
								TextBox tb = StaticConfiguration.gson.fromJson(message.get("message").toString(),
										TextBox.class);
								Connector.sendMessageToServer("txt Data");
							} else if (cb.getComponentType().equalsIgnoreCase("textarea")) {
								TextArea ta = StaticConfiguration.gson.fromJson(message.get("message").toString(),
										TextArea.class);
								Connector.sendMessageToServer(Connector.socket.id());
							} else if (cb.getComponentType().equalsIgnoreCase("select")) {
								SelectBox sb = StaticConfiguration.gson.fromJson(message.get("message").toString(),
										SelectBox.class);
								// Print All Values
								for (int counter = 0; counter < sb.getData().size(); counter++) {
									System.out.println(sb.getData().get(counter).getValue());
								}

								if (sb.getData().size() > 0)
									Connector.sendMessageToServer(
											sb.getData().get((sb.getData().size() - 1)).getValue());
							}
						}

					} 

				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
				}
			}

		}).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {
			public void call(Object... args) {
				System.out.println("Disconnected " + StaticConfiguration.ConnectionID);

			}
		});

		Connector.socket.connect();

	}

	public static void validateEntry() {
		try {
			URL url = new URL(StaticConfiguration.FEB_URL + "/forms-basic/secure/org/data/" + StaticConfiguration.APP_ID
					+ "/" + StaticConfiguration.FORM_ID + "?sortBy=lastModified&order=DESC&limit=1");

			String encoding = Base64.getEncoder().encodeToString(
					(Connector.userConfigBean.getUserId() + ":" + Connector.userConfigBean.getPassword())
							.getBytes("UTF-8"));

			System.out.println("Encoded Values");
			System.out.println(encoding);

			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			// connection.setDoOutput(true);
			connection.setRequestProperty("Authorization", "Basic " + encoding);
			connection.setRequestProperty("Accept", "application/json");
			connection.setRequestProperty("Content-Type", "application/json");

			String result = "";
			InputStream content = (InputStream) connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(content));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
			// System.out.println(result);

			JsonObject jo = StaticConfiguration.jsonParser.parse(result).getAsJsonObject();
			JsonArray jArray = jo.getAsJsonArray("items");

			System.out.println("Size :	" + jArray.size());
			System.out.println(jArray.get(0));

			JsonObject jo1 = (JsonObject) jArray.get(0).getAsJsonObject();

			System.out.println();
			System.out.println("***************** DATA Fetched From FEB Server ********************");
			System.out.println("Created			\t" + jo1.get("created").getAsString());
			System.out.println("Last Modified	\t\t" + jo1.get("lastModified").getAsString());
			System.out.println("UID				" + jo1.get("uid").getAsString());
			System.out.println("Name			\t" + jo1.get("F_txt_Name").getAsString());
			System.out.println("Address			\t" + jo1.get("F_txtArea_Address").getAsString());
			System.out.println("Designation		\t" + jo1.get("F_drop_Designation").getAsString());
			System.out.println("*******************************************************************");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

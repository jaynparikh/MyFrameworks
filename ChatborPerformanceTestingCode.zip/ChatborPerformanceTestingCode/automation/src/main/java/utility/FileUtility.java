package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import configurations.StaticConfiguration;
import models.ComponentLogs;
import models.LogFileDetails;

public class FileUtility {

	public static void readSummary() {
		String filepath = "dataLogs";

		final File folder = new File(filepath);
		StaticConfiguration.logsArray = new ArrayList<LogFileDetails>();
		listFilesForFolder(folder);

	}

	public static void listFilesForFolder(final File folder) {
		int i = 0;
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				System.out.println(fileEntry.getName());
				readLogs(fileEntry);
			}

			if (i++ == folder.listFiles().length - 1) {
				System.out.println("Last File");
				createSummary();
			}
		}
	}
	
	
		
	@SuppressWarnings({ "resource", "deprecation" })
	public static void createSummary() {
		
		System.out.println("Creating TestCase");

		try {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Summary");
		
		System.out.println("Size " + StaticConfiguration.logsArray.size());

		// Create Lable Row
		XSSFRow row = sheet.createRow(0);
		CellStyle style = workbook.createCellStyle();
		
		XSSFFont font = workbook.createFont();
	    font.setFontHeightInPoints((short) 10);
	    font.setFontName("Calibri");
	    font.setItalic(true);
	    font.setBold(true);
	    font.setColor(HSSFColor.BROWN.index);
		
		long avgFormFillUp = 0;
		long avgConnection = 0;
		long avgExe = 0;
		long avgComponent = 0;
		long avgReq = 0;
		 
		style = workbook.createCellStyle();
		style.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
		style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		style.setFont(font);
		style.setBorderBottom(BorderStyle.DOTTED);
		
		 XSSFCell cell = row.createCell(0);
		 cell.setCellValue("SESSION_ID");
         cell.setCellStyle(style);
         
        
         cell = row.createCell(1);    
         cell.setCellStyle(style);
         cell.setCellValue("EXE_START");
         
         cell = row.createCell(2);    
         cell.setCellStyle(style);
         cell.setCellValue("EXE_END");
         
         cell = row.createCell(3);    
         cell.setCellStyle(style);
         cell.setCellValue("EXE_TOTAL");
         
         cell = row.createCell(4);    
         cell.setCellStyle(style);
         cell.setCellValue("CON_START");
         
         cell = row.createCell(5);    
         cell.setCellStyle(style);
         cell.setCellValue("CON_END");
         
         cell = row.createCell(6);    
         cell.setCellStyle(style);
         cell.setCellValue("CON_TOTAL");
         
         cell = row.createCell(7);    
         cell.setCellStyle(style);
         cell.setCellValue("FORM_START");
         
         cell = row.createCell(8);    
         cell.setCellStyle(style);
         cell.setCellValue("FORM_END");
         
         cell = row.createCell(9);    
         cell.setCellStyle(style);
         cell.setCellValue("FORM_TOTAL");
         
         cell = row.createCell(10);    
         cell.setCellStyle(style);
         cell.setCellValue("NAME_COMP");
         
         cell = row.createCell(11);    
         cell.setCellStyle(style);
         cell.setCellValue("ADD_COMP");
         
         cell = row.createCell(12);    
         cell.setCellStyle(style);
         cell.setCellValue("DES_COMP");
         
         cell = row.createCell(13);    
         cell.setCellStyle(style);
         cell.setCellValue("COMP_AVG");
         
         cell = row.createCell(14);    
         cell.setCellStyle(style);
         cell.setCellValue("INTENT_REQ");
         
         cell = row.createCell(15);    
         cell.setCellStyle(style);
         cell.setCellValue("NAME_REQ");
         
         cell = row.createCell(16);    
         cell.setCellStyle(style);
         cell.setCellValue("ADD_REQ");
         
         cell = row.createCell(17);    
         cell.setCellStyle(style);
         cell.setCellValue("DES_REQ");
         
         cell = row.createCell(18);    
         cell.setCellStyle(style);
         cell.setCellValue("REQ_AVG");
	 
		int rowCounter = 0;
		try {

			for (; rowCounter < StaticConfiguration.logsArray.size(); rowCounter++) {

				row = sheet.createRow(rowCounter + 1);
				int column = 0;
				
				LogFileDetails lfs = StaticConfiguration.logsArray.get(rowCounter);

				row.createCell(column++).setCellValue(lfs.getSessionID());
				row.createCell(column++).setCellValue(lfs.getExeStartTime());
				row.createCell(column++).setCellValue(lfs.getExeEndTime());
				row.createCell(column++).setCellValue(lfs.getExeTotalTime());
				avgExe += StaticConfiguration.convertMill(lfs.getExeTotalTime());
				row.createCell(column++).setCellValue(lfs.getConnectionStartTime());
				row.createCell(column++).setCellValue(lfs.getConnectionEndTime());
				row.createCell(column++).setCellValue(lfs.getConnectionTotalTime());
				avgConnection += StaticConfiguration.convertMill(lfs.getConnectionTotalTime());
				row.createCell(column++).setCellValue(lfs.getFormFillUpStartTime());
				row.createCell(column++).setCellValue(lfs.getFormFillUpEndTime());
				row.createCell(column++).setCellValue(lfs.getFormTotalTime());
				avgFormFillUp += StaticConfiguration.convertMill(lfs.getFormTotalTime());
				
				for(int counter=0;counter < lfs.getClArrayList().size();counter++)
				{
					row.createCell(column++).setCellValue(lfs.getClArrayList().get(counter).getCompTotalTime());
				}
				
				row.createCell(column++).setCellValue(lfs.getCompAvgTime());
				
				for(int counter=0;counter < lfs.getRrlArrayList().size();counter++)
				{
					row.createCell(column++).setCellValue(lfs.getRrlArrayList().get(counter).getReqTotalTime());
				}
				row.createCell(column++).setCellValue(lfs.getReqAvgTime());
				
				avgComponent += StaticConfiguration.convertMill(lfs.getCompAvgTime());
				avgReq += StaticConfiguration.convertMill(lfs.getReqAvgTime());
			}
			
			
			row = sheet.createRow(rowCounter + 1);
			
			cell = row.createCell(0);    
	        cell.setCellStyle(style);
	        cell.setCellValue("Avg");
	        
	        cell = row.createCell(1);    
	        cell.setCellStyle(style);
	        cell.setCellValue("Execution");
	        
	        cell = row.createCell(2);    
	        cell.setCellStyle(style);
	        cell.setCellValue("Average");
	        
	        cell = row.createCell(3);    
	        cell.setCellStyle(style);
	        cell.setCellValue(StaticConfiguration.getAverageTime(avgExe,StaticConfiguration.logsArray.size()));
	        
	        cell = row.createCell(4);    
	        cell.setCellStyle(style);
	        cell.setCellValue("Connnection");
	        
	        cell = row.createCell(5);    
	        cell.setCellStyle(style);
	        cell.setCellValue("Average");
	        
	        
	        cell = row.createCell(6);    
	        cell.setCellStyle(style);
	        cell.setCellValue(StaticConfiguration.getAverageTime(avgConnection,StaticConfiguration.logsArray.size()));
	        
	        cell = row.createCell(7);    
	        cell.setCellStyle(style);
	        cell.setCellValue("Form");
	        
	        cell = row.createCell(8);    
	        cell.setCellStyle(style);
	        cell.setCellValue("Average");
	        
	        cell = row.createCell(9);    
	        cell.setCellStyle(style);
	        cell.setCellValue(StaticConfiguration.getAverageTime(avgFormFillUp,StaticConfiguration.logsArray.size()));
	        
	        cell = row.createCell(10);    
	        cell.setCellStyle(style);
	        
	        cell = row.createCell(11);    
	        cell.setCellStyle(style);
	        
	        cell = row.createCell(12);    
	        cell.setCellStyle(style);
	        
	        cell = row.createCell(13);    
	        cell.setCellStyle(style);
	        cell.setCellValue(StaticConfiguration.getAverageTime(avgComponent,StaticConfiguration.logsArray.size()));
	        
	        cell = row.createCell(14);    
	        cell.setCellStyle(style);
	        
	        cell = row.createCell(15);    
	        cell.setCellStyle(style);
	        
	        cell = row.createCell(16);    
	        cell.setCellStyle(style);
	        
	        cell = row.createCell(17);    
	        cell.setCellStyle(style);
	        
	        cell = row.createCell(18);    
	        cell.setCellStyle(style);
	        cell.setCellValue(StaticConfiguration.getAverageTime(avgReq,StaticConfiguration.logsArray.size()));
	        
			

			FileOutputStream out = new FileOutputStream("SummarySheet.xls", false);

			workbook.write(out);
			out.flush();
			out.close();

			
			System.out.println("File Written Successfully");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}


	public static void readLogs(final File file) {
		FileInputStream fi;
		try {
			fi = new FileInputStream(file);
			ObjectInputStream oi = new ObjectInputStream(fi);
			LogFileDetails lfd = (LogFileDetails) oi.readObject();
			//System.out.println(lfd.toString());
			StaticConfiguration.logsArray.add(lfd);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void writeLogs(String fileName, LogFileDetails lfd) {
		String filepath = "dataLogs";
		try {
			File directory = new File(filepath);
			if (!directory.exists()) {
				directory.mkdir();
				// If you require it to make the entire directory path including parents,
				// use directory.mkdirs(); here instead.
			}

			File file = new File(filepath + "//" + fileName + ".txt");
			FileOutputStream fileOut = new FileOutputStream(file, true);
			ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
			objectOut.writeObject(lfd);
			objectOut.close();
			System.out.println("The Object  was succesfully written to a file");
		} catch (Exception ex) {
			ex.printStackTrace();

		}
	}

	@SuppressWarnings({ "resource", "deprecation" })
	public static void createTestSupportFiles() {
		
		System.out.println("Creating TestCase");
		
		//String filepath = "AppSuppportData";
		
		String filepath = "TestSupport\\"+StaticConfiguration.APP_ID+"\\"+StaticConfiguration.FORM_ID+"\\";
		Path path = Paths.get(filepath);
		try {
				File directory = new File(filepath);
				if (!directory.exists()) {
				
				Files.createDirectories(path);
				
				System.out.println("Created New File Directory");
				System.out.println(filepath);
				// If you require it to make the entire directory path including parents,
				// use directory.mkdirs(); here instead.
			}

			File file = new File(filepath +"//"+ StaticConfiguration.FORM_ID + ".xlsx");
			System.out.println(file.exists());
			FileOutputStream fileOut = new FileOutputStream(file, true);
			ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
			objectOut.writeObject(new LogFileDetails());
			objectOut.close();
			System.out.println("Testcase was succesfully written to a file");

		}catch(Exception e) {
			e.printStackTrace();
		}

		
		}

}

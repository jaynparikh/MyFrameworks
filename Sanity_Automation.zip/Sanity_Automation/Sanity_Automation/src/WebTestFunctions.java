import static org.testng.Assert.fail;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import utility_web.Screenshot;
import utility_web.UIWebElementsWeb;
import utility_web.SeleniumUtility;
import utility_web.WebPageString;


public class WebTestFunctions extends SeleniumUtility implements WebPageString {
	UIWebElementsWeb ob = new UIWebElementsWeb();
	Screenshot screenshots = new Screenshot();
	
	public WebDriver launchBrowser(WebDriver driver) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Jay Parikh\\Downloads\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap.setCapability(ChromeOptions.CAPABILITY, options);
		driver = new ChromeDriver(cap);
		return driver;
	}
	
	public WebDriver intranet_launchBrowser(WebDriver driver) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Jay Parikh\\Downloads\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--incognito");
		options.addArguments("disable-infobars");
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap.setCapability(ChromeOptions.CAPABILITY, options);
		driver = new ChromeDriver(cap);
		return driver;
	}

	
	public  void login(WebDriver driver)
			throws IOException, InterruptedException, AWTException {
		
		
		driver.navigate().to(url);
		driver.manage().window().maximize();
		//test.log(LogStatus.PASS, "url opened");
		//screenshots.getscreenshot(driver);
		
		
		waitForElementPresent(driver, 60, ob.LOGIN_BTN);
		click(driver,ob.LOGIN_BTN);
		//Thread.sleep(2000);
		//test.log(LogStatus.PASS, "btn clicked");
		//screenshots.getscreenshot(driver);
		
		
		waitForElementtobeclickable(driver, 60, ob.USERNAME);
		Thread.sleep(1000);
		//driver.findElement(By.xpath("//input[@id='userID']")).sendKeys("qa.dxa@streebo.com");
		sendKey_element(driver, ob.USERNAME, "qa.dxa@streebo.com");
		//test.log(LogStatus.PASS, "username entered");
		//screenshots.getscreenshot(driver);
		
		waitForElementtobeclickable(driver, 60, ob.PASSWORD);
		sendKey_element(driver, ob.PASSWORD, "qa123");
	//	test.log(LogStatus.PASS, "password entered");
		//screenshots.getscreenshot(driver);
		
		
		waitForElementPresent(driver, 60, ob.TO_LOGIN);
		click(driver,ob.TO_LOGIN);
		//test.log(LogStatus.PASS, "succesful login");
		//screenshots.getscreenshot(driver);
		//Thread.sleep(4000);
		
		
		waitForElementtobeclickable(driver, 60, ob.GLOBAL_HEADER);
	//	waitForElementPresent(driver, 60, ob.GLOBAL_HEADER);
		click(driver,ob.GLOBAL_HEADER);
		//test.log(LogStatus.PASS, "Open site menu clicked");
		//screenshots.getscreenshot(driver);
		
		waitForElementtobeclickable(driver, 60, ob.DXA_SOLUTIONS);
		//waitForElementPresent(driver, 60, ob.DXA_SOLUTIONS);
		click(driver,ob.DXA_SOLUTIONS);
		//test.log(LogStatus.PASS, "Dxa solutions clicked");
		//screenshots.getscreenshot(driver);
		//Thread.sleep(4000);
		
	}






public  void pscu_chatbot(WebDriver driver)
		throws IOException, InterruptedException, AWTException {
	
	
	/**************performs login********************/
	login( driver);
	
	/**********chatbot tile clicked******************/
	
	waitForElementtobeclickable(driver, 60, ob.MY_APP_AMERICAS);
	click(driver,ob.MY_APP_AMERICAS);
//	test.log(LogStatus.PASS, "my app americas tile clicked");
//	screenshots.getscreenshot(driver);
	
	waitForElementtobeclickable(driver, 60, ob.PSCU_MOBILE_APP);
	click(driver,ob.PSCU_MOBILE_APP);
	//test.log(LogStatus.PASS, "chatbot form opened");
	//screenshots.getscreenshot(driver);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_HEADER);
	click(driver,ob.CHATBOT_HEADER);
//	test.log(LogStatus.PASS, "chatbot header tab clicked");
	//screenshots.getscreenshot(driver);
	
	
	/********* start chat bot****************/
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	Thread.sleep(1000);
	sendKey_element( driver,ob.CHATBOT_ENTER, "lost card");
	Thread.sleep(2000);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_SEND);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "keyword entered succesfully....");
	//screenshots.getscreenshot(driver);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	waitForElementPresent(driver, 60, ob.RESP_DATEPICKER);
	click(driver, ob.RESP_DATEPICKER);
	waitForElementPresent(driver, 60, ob.RESP_DATEPICKER_SELECTDATE_3);
	click(driver, ob.RESP_DATEPICKER_SELECTDATE_3);
//	test.log(LogStatus.PASS, "date entered");
//	screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_DO_ANY_OF_THESE_TRANSACTIONS_LOOK_SUSPICIOUS);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "Aeroflot Airlines - $2,133.00");
	//Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "checkbox ticked of aeroflow airlines");
	//screenshots.getscreenshot(driver);

	waitForElementPresent(driver, 60, ob.RESP_TXT_WHY_ARE_YOU_REPORTING_CARD_LOST_OR_STOLEN);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "I lost my card");
	//Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "radio selected: i lost my card");
	//screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_WHERE_DID_YOU_LOSE_YOUR_CARD);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "Home");
	//Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "radio selected: home");
//	screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_IN_WHICH_STATE_YOU_LOSE_YOUR_CARD);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	//waitForElementPresent(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "Arizona");
	//Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "state entered");
	//screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_DID_YOU_LOSE_PIN_OF_THIS_CARD);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "No");
//	Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "radio selected: no");
	//screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_IS_THE_CARD_IN_YOUR_POSSESSION);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	//waitForElementPresent(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "No");
	//Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "radio selected: no");
	//screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_IS_ADDRESS_CORRECT);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "Yes");
	//Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "radio selected: Yes");
	//screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_DO_YOU_WANT_REPLACEMENT_CARD_SHIPPED);
	waitForElementtobeclickable(driver, 60, ob.CHATBOT_ENTER);
	sendKey_element( driver,ob.CHATBOT_ENTER, "Yes");
//	Thread.sleep(2000);
	click(driver,ob.CHATBOT_SEND);
	//test.log(LogStatus.PASS, "radio selected: Yes");
	//screenshots.getscreenshot(driver);
	waitForElementPresent(driver, 60, ob.RESP_TXT_REQUEST_HAS_BEEN_SUBMITTED);	
	Assert.assertTrue(verifyElementPresent(driver, ob.VERIFY_MSG), "success");
	
	
	
}

public void intranet(WebDriver driver) throws AWTException, InterruptedException {
	driver.navigate().to(url);
	driver.manage().window().maximize();
	//WebDriverWait wait = new WebDriverWait(driver, 60);
	//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[text()='Login']")));
	driver.findElement(By.xpath("//div[@class='loginWhtBgPd']/div/div[2]/input")).sendKeys("kkk");
	/*driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
	Robot r = new Robot();
	r.keyPress(KeyEvent.VK_TAB);
	r.keyPress(KeyEvent.VK_TAB);
	// r.keyRelease(KeyEvent.VK_TAB);
	 String text = "Hello World";
		StringSelection stringSelection = new StringSelection(text);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, stringSelection);
	 r.keyPress(KeyEvent.VK_CONTROL);
	 r.keyPress(KeyEvent.VK_V);
	 r.keyRelease(KeyEvent.VK_V);
	 r.keyRelease(KeyEvent.VK_CONTROL);
	 Thread.sleep(5000);*/
	// driver.switchTo().frame(1);
	// driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("jay.parikh@streebo.com");
	 /*Robot r = new Robot(); 
	 int k=0;
	 while(k==0) {
		 try {
			
		 driver.findElement(By.xpath("//input[@placeholder='Enter username']")).sendKeys("jay.parikh@streebo.com");
		 break;
		 }catch (Exception e) {
			// TODO: handle exception
			 r.keyPress(KeyEvent.VK_TAB);
			 r.keyRelease(KeyEvent.VK_TAB);
			k=0; 
		}
	 }*/
	// r.keyPress(KeyEvent.VK_TAB);
	// r.keyPress(KeyEvent.VK_TAB);
	
	
	//driver.findElement(By.xpath("//input[@placeholder='Enter password']")).sendKeys("jay123");
}












}


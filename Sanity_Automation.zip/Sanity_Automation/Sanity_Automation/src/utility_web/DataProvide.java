package utility_web;

import java.io.File;
import java.lang.reflect.Method;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.testng.annotations.DataProvider;

public class DataProvide {

	@DataProvider(name="Login")
	public static Object [][] Login() throws Exception
	{
		File filepath = new File("C:\\Users\\Jay Parikh\\eclipse-workspace\\Sanity_Automation\\Sanity_Automation\\src\\excel\\Dataprovider.xls");
		Workbook wb= Workbook.getWorkbook(filepath);
		Sheet sheet = wb.getSheet("data");

		int row= sheet.getRows();
		int column = sheet.getColumns();
		String Inputdata[][] = new String[row-1][column];
		int count =0;
		for(int i=1;i<row;i++)
		{
			for (int j=0;j<column;j++)
			{			Cell cell = sheet.getCell(j,i);
			Inputdata[count][j]=cell.getContents();
			}
			count++;
		}
		return Inputdata;
	}

	@DataProvider(name="TC")
	public static Object [][] TestCase(Method m) throws Exception
	{
		File filepath = new File("C:\\Users\\Jay Parikh\\eclipse-workspace\\Sanity_Automation\\Sanity_Automation\\src\\excel\\Dataprovider.xls");
		Workbook wb= Workbook.getWorkbook(filepath);
		Sheet sheet = wb.getSheet("TestCase");     
		int row= sheet.getRows();
		int column = sheet.getColumns();
		String Inputdata[][] = null;
		int count=0;
		Cell cell;
		for (int i=1;i<row;i++)
		{
			String cell_tcnumber = sheet.getCell(0,i).getContents();       
			//For Verifying Method Name, which method has to execute
			if(cell_tcnumber.equalsIgnoreCase(m.getName())) {

				for(int j=0;j<column;j++) {
					cell = sheet.getCell(j,i);
					if(!cell.getContents().isEmpty()) 
					{
						count++;       
					}
				}
				//For multi-column functionality
				Inputdata= new String[1][count];
				int k =0;
				for (int j=0;j<column;j++)
				{
					cell = sheet.getCell(j,i);
					if(!cell.getContents().isEmpty()) 
					{
						Inputdata[0][k]=cell.getContents();
						
						k++;
					}
				}
			} 
		}
		return Inputdata;
	}
}

package utility_web;



public class UIWebElementsWeb {
	
	WebPageString q = new WebPageString() {
	};
	//elements on login page
	public utility_web.WebPageElements URL = new utility_web.WebPageElements("url", "xpath", q.url);
	public utility_web.WebPageElements LOGIN_BTN = new utility_web.WebPageElements("btn", "xpath", q.login_btn);
	public utility_web.WebPageElements USERNAME = new utility_web.WebPageElements("txtbox", "xpath", q.username);
	public utility_web.WebPageElements PASSWORD = new utility_web.WebPageElements("txtbox", "xpath", q.password);
	public utility_web.WebPageElements TO_LOGIN = new utility_web.WebPageElements("BTN", "xpath", q.tologin);
	public utility_web.WebPageElements GLOBAL_HEADER = new utility_web.WebPageElements("header btn", "xpath", q.globe_header);
	public utility_web.WebPageElements DXA_SOLUTIONS = new utility_web.WebPageElements("nested link", "xpath", q.dxa_solutions);
	public utility_web.WebPageElements MY_APP_AMERICAS = new utility_web.WebPageElements("tile", "xpath", q.MyApps_Americas);
	public utility_web.WebPageElements PSCU_MOBILE_APP = new utility_web.WebPageElements("tile", "xpath", q.pscu_mobile_app);
	public utility_web.WebPageElements CHATBOT_HEADER = new utility_web.WebPageElements("header", "xpath", q.chatbot_header);
	public utility_web.WebPageElements CHATBOT_ENTER = new utility_web.WebPageElements("enter text field", "xpath", q.chat_enter);
	public utility_web.WebPageElements CHATBOT_SEND = new utility_web.WebPageElements("send button", "xpath", q.send);
	public utility_web.WebPageElements VERIFY_MSG = new utility_web.WebPageElements("txt msg field", "xpath", q.verify_msg);
	public utility_web.WebPageElements RESP_TXT_WHEN_DID_CARD_GO_MISSING = new utility_web.WebPageElements("chatbot response-When did card go missing", "xpath", q.resp_txt_when_did_card_go_missing);
	public utility_web.WebPageElements RESP_DATEPICKER = new utility_web.WebPageElements("chatbot response-datepicker", "xpath", q.resp_txt_datepicker);
	public utility_web.WebPageElements RESP_DATEPICKER_SELECTDATE_3 = new utility_web.WebPageElements("chatbot response-datepicker-DATE3", "xpath", q.resp_datepicker_selectdate_3);
	public utility_web.WebPageElements RESP_TXT_DO_ANY_OF_THESE_TRANSACTIONS_LOOK_SUSPICIOUS = new utility_web.WebPageElements("chatbot response-do_any_of_these_transaction_look_suspicious", "xpath", q.resp_txt_do_any_of_these_transaction_look_suspicious);
	public utility_web.WebPageElements RESP_TXT_WHY_ARE_YOU_REPORTING_CARD_LOST_OR_STOLEN = new utility_web.WebPageElements("chatbot response-why_are_you_reporting_card_lost_or_stolen", "xpath", q.resp_txt_why_are_you_reporting_card_lost_or_stolen);
	public utility_web.WebPageElements RESP_TXT_WHERE_DID_YOU_LOSE_YOUR_CARD = new utility_web.WebPageElements("chatbot response-where_did_you_lose_your_card", "xpath", q.resp_txt_where_did_you_lose_your_card);
	public utility_web.WebPageElements RESP_TXT_IN_WHICH_STATE_YOU_LOSE_YOUR_CARD = new utility_web.WebPageElements("chatbot response-in_which_state_you_lose_your_card", "xpath", q.resp_txt_in_which_state_you_lose_your_card);
	public utility_web.WebPageElements RESP_TXT_DID_YOU_LOSE_PIN_OF_THIS_CARD = new utility_web.WebPageElements("chatbot response-did_you_lose_pin_of_this_card", "xpath", q.resp_txt_did_you_lose_pin_of_this_card);
	public utility_web.WebPageElements RESP_TXT_IS_THE_CARD_IN_YOUR_POSSESSION = new utility_web.WebPageElements("chatbot response-is_the_card_in_your_possession", "xpath", q.resp_txt_is_the_card_in_your_possession);
	public utility_web.WebPageElements RESP_TXT_IS_ADDRESS_CORRECT = new utility_web.WebPageElements("chatbot response-is_address_correct", "xpath", q.resp_txt_is_address_correct);
	public utility_web.WebPageElements RESP_TXT_DO_YOU_WANT_REPLACEMENT_CARD_SHIPPED = new utility_web.WebPageElements("chatbot response-do_u_want_replacement_card_shipped", "xpath", q.resp_txt_do_u_want_replacement_card_shipped);
	public utility_web.WebPageElements RESP_TXT_REQUEST_HAS_BEEN_SUBMITTED = new utility_web.WebPageElements("chatbot response-request_has_been_submitted", "xpath", q.resp_txt_request_has_been_submitted);
	
}

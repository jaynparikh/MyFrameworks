package utility_web;



public interface WebPageString {
	//login
	//String url =  "http://www.demodxa.streebo.com";
	String url =  "http://intranet.streebo.com";
	String login_btn = "//*[@id=\"layoutContainers\"]/div/div[1]/div[2]/div/div[2]/section/div[2]/app-root/app-landing/div/div/table/td/div/a[1]";
	String username = "//*[@id='userID']";
	String password = "//*[@id=\"password\"]";
	String tologin = "//*[@class='btn btn-dark w-100']";
	String globe_header = "//*[@id=\"wpToolbarSitesNavMenu\"]/img[1]";
	String dxa_solutions = "//*[@id=\"_dxa.solutions\"]/span";
	
	
	//start chatbot
	
	String MyApps_Americas = "//div[contains(text(),'My Apps - Americas')]";
	String pscu_mobile_app = "//div[contains(text(),'PSCU Mobile App')]";
	String chatbot_header = "//*[@id=\"topLevelNavigation\"]/li[4]/a";
	String chat_enter = "//*[@id=\"9579819a-5d93-4fd9-8c34-05d240bc6806\"]";
	String send = "//*[@id=\"998fca11-d1f3-4550-8e20-562ec03c9792\"]/img";
	String aeroflot_airlines = "//*[@id=\"label51d5f225-df6f-49d4-b394-c9c57b3c122395bdd6c7-2ffb-4bcd-824e-825346b32b36_0\"]";
	String i_lost_my_card = "//*[@id=\"label66f4319c-2e83-4f53-8503-be5fe9c31754_0\"]";
	String home = "//*[@id=\"label66f4319c-2e83-4f53-8503-be5fe9c31754_0\"]";
	String no = "//*[@id=\"label66f4319c-2e83-4f53-8503-be5fe9c31754_1\"]";
	String verify_msg = "//*[@id=\"fd368c05-209f-4bcd-89f2-bb3c4c66adde\"]/div[33]/div[2]/div[2]/div";
	String resp_txt_when_did_card_go_missing = "//div[contains(text(),'go missing?')]";
	String resp_txt_datepicker = "(//input[@data-role='date'])[1]";
	String resp_datepicker_selectdate_3 = "//td/a[text()='3']";
	String resp_txt_do_any_of_these_transaction_look_suspicious = "//div[text()='Do any of these transactions look suspicious?']";
	String resp_txt_why_are_you_reporting_card_lost_or_stolen = "//div[text()='1. Why are you reporting the card lost or stolen??']";
	String resp_txt_where_did_you_lose_your_card = "//div[text()='2. Where did you lose your card?']";
	String resp_txt_in_which_state_you_lose_your_card = "//div[text()='3. In which state did you lose your card?']";
	String resp_txt_did_you_lose_pin_of_this_card = "//div[text()='4. Did you lose the pin for this card?']";
	String resp_txt_is_the_card_in_your_possession = "//div[text()='5. Is the card in your possession?']";
	String resp_txt_is_address_correct = "//div[text()='6. Is the address correct? 5678 Central Ave. St. Peterburg FL 33701']";
	String resp_txt_do_u_want_replacement_card_shipped = "//div[text()='7. Do you want the replacement card shipped overnight? ($25 charge)']";
	String resp_txt_request_has_been_submitted = "//div[contains(text(),'Thank you. Your request has been submitted.')]";
	
}	

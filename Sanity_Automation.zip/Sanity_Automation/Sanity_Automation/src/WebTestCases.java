
import java.awt.AWTException;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.ScreenCapture;


import utility_web.Screenshot;



public class WebTestCases {
	ExtentTest test;
	ExtentReports extent;
	public  WebDriver driver;
	//public WebDriver driver1;
	String driverPath = "C:\\Users\\Jay Parikh\\Downloads\\chromedriver.exe";
	Screenshot screenshots = new Screenshot();
	WebTestFunctions wtf = new WebTestFunctions();

	@BeforeMethod
	public void setup() {
		System.out.println("Before method executed");
		
		

	}

	/*@BeforeSuite
	public void extent_reports() {
		extent = new ExtentReports("E:\\web_automation\\web_report" + screenshots.timestamp() + ".html", true);

	}*/

	// ----------------------------------------------------------------------------------------------

	@Test(priority = 0, enabled = true, dataProviderClass = utility_web.DataProvide.class, dataProvider = "TC")
	public void TC1(String TCID, String TCDESC, String RUNMODE) throws IOException, InterruptedException, AWTException {
		if (RUNMODE.equalsIgnoreCase("y") && TCID.equalsIgnoreCase("TC1")) {
			System.out.println("Runmode value for " + TCID + " is: " + RUNMODE + " ");
		//	driver = wtf.launchBrowser(driver);
		//	driver
			driver.navigate().to("intranet.streebo.com");
			/*test = extent.startTest(TCID + " " + TCDESC, TCDESC);
			wtf.login(driver, test, extent);*/
		}

		else if (RUNMODE.equalsIgnoreCase("n")) {
		/*	test = extent.startTest(TCID + " " + TCDESC, TCDESC);*/
			throw new SkipException("Skipped");
		}
	}

	@Test(priority = 1, enabled = true, dataProviderClass = utility_web.DataProvide.class, dataProvider = "TC")
	public void TC2(String TCID, String TCDESC, String RUNMODE) throws IOException, InterruptedException, AWTException {
		if (RUNMODE.equalsIgnoreCase("y") && TCID.equalsIgnoreCase("TC2")) {
			System.out.println("Runmode value for " + TCID + " is: " + RUNMODE + " ");
			driver = wtf.intranet_launchBrowser(driver);
			//test = extent.startTest(TCID + " " + TCDESC, TCDESC);
			//wtf.pscu_chatbot(driver);
			wtf.intranet(driver);																																																																																																																												
		}

		else if (RUNMODE.equalsIgnoreCase("n")) {
		/*	test = extent.startTest(TCID + " " + TCDESC, TCDESC);*/
			throw new SkipException("Skipped");
		}

	}

	// ------------------------------------------------------------------------------------------
	@AfterMethod
	public void getResult(ITestResult result) throws IOException, InterruptedException {
		if (result.getStatus() == ITestResult.FAILURE) {
			screenshots.getscreenshot(driver);
			driver.quit();
			//test.log(LogStatus.FAIL, result.getName() + " is Failed : " + result.getThrowable());

		} else if (result.getStatus() == ITestResult.SKIP) {
			System.out.println(result.getStatus());
			//test.log(LogStatus.SKIP, result.getName() + " is Skipped  ");
		} else {
			driver.quit();
		}

		

	}

	@AfterSuite
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
		extent.flush();
		// service.stop();
		System.out.println("Cases Executed");
	}

}

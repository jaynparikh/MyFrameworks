package utility;


import xpath.ui;


public class UIWebElementsAndroid {
	

	QRGeneration q = new QRGeneration() {
	};
	//elements on login page
	public utility.WebPageElements ALLOW = new utility.WebPageElements("Allow button on permission prompt", "xpath", LoginInterface.allow);
   	public utility.WebPageElements USERNAME = new utility.WebPageElements("Username textbox", "xpath", LoginInterface.username);
   	public utility.WebPageElements PASSWORD = new utility.WebPageElements("Password textbox", "xpath", LoginInterface.password);
   	public utility.WebPageElements LOGINCLICK = new utility.WebPageElements("Login button", "xpath", LoginInterface.loginclick);
   	public utility.WebPageElements LOGIN_ALERT = new utility.WebPageElements("Login alert", "xpath", LoginInterface.login_alert);
   	public utility.WebPageElements LOGIN_OK = new utility.WebPageElements("Login alert ok", "xpath", LoginInterface.login_ok);
   	public utility.WebPageElements FORMS = new utility.WebPageElements("Forms headeron dashboard page", "xpath", LoginInterface.forms);
   	public WebPageElements CATEGORY_ELETRICIAN = new utility.WebPageElements("Construction Category", "xpath", LoginInterface.category_electrician);
   	public WebPageElements CANCEL = new utility.WebPageElements("QR generation icon", "xpath", LoginInterface.cancel);
   	
   	
	public WebPageElements MULTIPLE_PDF = new WebPageElements("multiple pdf", "xpath", q.multiple_pdf);
	public WebPageElements URDU_NAME = new WebPageElements("urdu name", "xpath", q.urdu_name);
	public WebPageElements MARKS = new WebPageElements("marks", "xpath", q.marks);
	public WebPageElements ADDRESS = new WebPageElements("address", "xpath", q.address);
	public WebPageElements TIME_DD = new WebPageElements("time_dd", "xpath", q.time_dd);
	public WebPageElements TIME_SELECT = new WebPageElements("time_select", "xpath", q.time_select);
	public WebPageElements DATE_BOX = new WebPageElements("datebox", "xpath", q.date_box);
	//public WebPageElements DATE_SELECT = new WebPageElements("load form", "xpath", q.date_select);
	public WebPageElements DATE_SET = new WebPageElements("date_set", "xpath", q.date_set);
	//public WebPageElements CURRENCY = new WebPageElements("currency", "xpath", q.currency);
	public WebPageElements SELECTONE = new WebPageElements("selectone", "xpath", q.selectone);
	public WebPageElements GETPDF_TEXT = new WebPageElements("getpdf_text", "xpath", q.getPDF_Text);
	public WebPageElements GETPDF_SELECT = new WebPageElements("getpdf_select", "xpath", q.getPdf_Select);
	public WebPageElements GETPDF_MULTILINE = new WebPageElements("getpdf_multiline", "xpath", q.getPDF_Multiline);
	public WebPageElements VERIFYPDF = new WebPageElements("verifypdf", "xpath", q.verify_pdf);
	public WebPageElements GETPDF_ALL = new WebPageElements("getpdf_all", "xpath", q.getpdf_All);
	//public WebPageElements SUBMIT = new WebPageElements("submit", "xpath", q.submit);
	//public WebPageElements PDF_BACK = new WebPageElements("load form", "xpath", q.pdf_back);
	public utility.WebPageElements F_qr_scan = new utility.WebPageElements("QR scanner form", "xpath", q.qrscan_form);
	public utility.WebPageElements F_qr_code_scan = new utility.WebPageElements("QR scanner form", "xpath", q.qrcodescan);
	public utility.WebPageElements F_qr_code_verify= new utility.WebPageElements("QR scanner form", "xpath", q.qrscan_verify);
	public utility.WebPageElements FORMLIST= new utility.WebPageElements("List of forms", "xpath", LoginInterface.formList);
	public WebPageElements AUTHOR = new utility.WebPageElements("Author list to find QR Generation form", "xpath", LoginInterface.author );
   	
	//elements for QR generation form
	//public WebPageElements AUTHOR = new utility.WebPageElements("Author list to find QR Generation form", "xpath", q.author );
   	public WebPageElements QRGENERATION_FORM = new utility.WebPageElements("QR Generation form", "xpath", q.qrgeneration_form);
   	public WebPageElements BTN_SUBMIT = new utility.WebPageElements("From submit button", "xpath", q.btn_submit);
   	
   	public WebPageElements QRGENERATIONICON = new utility.WebPageElements("QR generation icon", "xpath", q.qrgenerateicon);
   	
   	public WebPageElements TXT_SINGLELINE = new utility.WebPageElements("Single line entty textbox", "xpath", q.txt_singleline);
   	public WebPageElements TXT_MULTILINE = new utility.WebPageElements("Multi line entty textbox", "xpath", q.txt_multiline);
   	public WebPageElements TXT_NUMBER = new utility.WebPageElements("Number textbox", "xpath", q.txt_number);
   	public WebPageElements CURRENCY = new utility.WebPageElements("Currency textbox", "xpath", q.txt_currency);
   	public WebPageElements DATEPICKER = new utility.WebPageElements("Date Picker", "xpath", q.datepicker);
   	public WebPageElements SELECTDATE = new utility.WebPageElements("date selection", "xpath", q.selectdate);
   	public WebPageElements BTN_DATESET = new utility.WebPageElements("button set on datepickrer", "xpath", q.btn_dateset);
   	
   	public WebPageElements TXT_EMAIL = new utility.WebPageElements("Email textbox", "xpath", q.txt_email);
   	public WebPageElements DROPDOWN = new utility.WebPageElements("Dropdown", "xpath", q.dropdown);
   	public WebPageElements DROPDOWN_OPTION = new utility.WebPageElements("Dropdown Option", "xpath", q.dropdown_option);
   	public WebPageElements RADIO_MALE = new utility.WebPageElements("radio button male", "xpath", q.radio_male);
   	public WebPageElements MULTISELECT_BLUE= new utility.WebPageElements("Multi select blue", "xpath", q.multiselect_blue);
   	public WebPageElements MULTISELECT_GREEN = new WebPageElements("Multi select Green", "xpath", q.multiselect_green);
   	public WebPageElements CHECKBOX = new WebPageElements("checkbox", "xpath", q.checkbox);
   	public WebPageElements TXT_TIME = new utility.WebPageElements("Time textbox", "xpath", q.txt_time);
   	public WebPageElements TXT_TIME_OPTIONS= new utility.WebPageElements("Time field options", "xpath", q.txt_time_options);
   	public WebPageElements PANEL_QRSHARE = new WebPageElements("Options to share downloaded qr code", "xpath", q.panel_qrshare);
   	
   	
   	
   	//Qr scanner
   	
    public WebPageElements QR_SCANNER_ELEMENT = new WebPageElements("stop rec", "xpath", q.qrscanner);
    public WebPageElements QR_SCANNER_PAGE = new WebPageElements("stop rec", "xpath", q.qrscanner_form);
    public WebPageElements SINGLE_LINE_ENTRY = new WebPageElements("stop rec", "xpath", q.single_line_entry);

   	
 // out of box feature testing....
	
   	
 	public WebPageElements OUTOFBOX = new WebPageElements("esignature", "xpath", q.outofboxfeatureform);
 	public WebPageElements ESIGNATURE = new WebPageElements("esignature", "xpath", q.e_signature);
 	public WebPageElements CAMERA = new WebPageElements("camera", "xpath", q.camera);
 	public WebPageElements EDITABLE_CAMERA = new WebPageElements("editable camera", "xpath", q.editable_camera);
 	public WebPageElements AUDIO_1 = new WebPageElements("audio", "xpath", q.audio);
 	public WebPageElements AUDIO_PLAY = new WebPageElements("audio", "xpath", q.audio_play);
 	public WebPageElements AUDIO_STOP = new WebPageElements("audio stop", "xpath", q.audio_stop);
 	//public WebPageElements AUDIO_PLAY = = new WebPageElements("play", "xpath", q.);
 	public WebPageElements VIDEO_1 = new WebPageElements("video", "xpath", q.video);
 	public WebPageElements VIDEO_REC = new WebPageElements("video rec", "xpath", q.video_rec);
 	public WebPageElements BARCODE = new WebPageElements("barcode", "xpath", q.barcode);
 	public WebPageElements QRCODE = new WebPageElements("qrcode", "xpath", q.qrcode);
 	public WebPageElements CAMERA_CAPTURE_BOX = new WebPageElements("qcamera capture box", "xpath", q.camera_capture_box);
 	public WebPageElements OK = new WebPageElements("ok", "xpath", q.ok);
 	public WebPageElements EDITABLE_CAMERA_ACCEPT = new WebPageElements("editable camera accept", "xpath", q.editable_camera_accept);
 	public WebPageElements STOP_REC = new WebPageElements("stop rec", "xpath", q.stop_rec);
   	
 	
 	
   	public WebPageElements CAMERAFORM = new WebPageElements("Sagar Testing Form", "xpath", q.cameraform);
   	//public WebPageElements CAMERA= new WebPageElements("Camera Option", "xpath", q.camera);
   	public WebPageElements CAMERAOPTION = new WebPageElements("Camera Pop up", "id", q.cameraoption);
   	public WebPageElements CAMERA_OK_SAMSUNG = new WebPageElements("Ok button after clicking picture", "xpath", q.cameraOkSamsung);
   	public WebPageElements CAMERA_OK_NEXUS = new WebPageElements("Ok button after clicking picture", "xpath", q.cameraOkNexus);
   	public WebPageElements ALBUM = new WebPageElements(" Second Camera Icon", "xpath", q.album);
   	public WebPageElements GALLERY = new WebPageElements("Gallery Icon", "id", q.gallery);
   	public WebPageElements GALLERYUPLOAD = new WebPageElements("Gallery Upload", "xpath", q.galleryupload);
   	public WebPageElements album = new WebPageElements("Gallery Album", "xpath", q.album);
   	public WebPageElements ALBUMPHOTO = new WebPageElements("Gallery Album Photo", "xpath", q.albumphoto);
   	public WebPageElements AUDIOSTART= new WebPageElements("Audio Start", "xpath", q.audiostart);
   	public WebPageElements AUDIOSTOP = new WebPageElements("Audio Stop", "xpath", q.audiostop);
   	public WebPageElements PLAYBUTTON= new WebPageElements("Play Button", "xpath", q.playbutton);
   	public WebPageElements ESIGN = new WebPageElements("E Signature", "xpath", q.esign);
   	public WebPageElements DATA = new WebPageElements("Data Text Box", "xpath", q.data);
   	public WebPageElements GPS = new WebPageElements("GPS", "xpath", q.gps);
   	//public WebPageElements BARCODE = new WebPageElements("Barcode", "xpath", q.barcode);
   	//public WebPageElements QRCODE = new WebPageElements("Qr code", "xpath", q.qrcode);
   	public WebPageElements SUBMIT = new WebPageElements("Submit Button", "xpath", q.submit);
   	public WebPageElements VIEWRES = new WebPageElements("View Response", "xpath", q.viewres);
   	public WebPageElements SEARCHTAG = new WebPageElements("Search Tag", "xpath", q.searchtag);
   	public WebPageElements SEARCHBOX = new WebPageElements("Search Box", "xpath", q.searchbox);
   	public WebPageElements VIEWRESFORM = new WebPageElements("View Response Form", "xpath", q.viewresform);
   	public WebPageElements OFFLINERECORD = new WebPageElements("Offline record inserted pop", "xpath", q.offlinerecord);
   	public WebPageElements RECORDOK = new WebPageElements("ok button of pop up", "xpath", q.recordok);
   	
  //offline pdf
  	public WebPageElements OFFLINEFORM = new WebPageElements("Offlinepdf form", "xpath", q.offlineform);
     	public WebPageElements GETPDF = new WebPageElements("Get PDF Button", "xpath", q.getpdf);
     	
     	//offline create service call
    public WebPageElements CREATEFORM = new WebPageElements("Create service form", "xpath", q.createform);
  	public WebPageElements NAME = new WebPageElements("Name Textbox", "xpath", q.name);
  	public WebPageElements MARK = new WebPageElements("Mark Textbox", "xpath", q.mark);
  	public WebPageElements RECORD = new WebPageElements("Record Textbox", "xpath", q.record);
  	public WebPageElements BINDBUTTON = new WebPageElements("Binding button", "xpath", q.bindbutton);
    public WebPageElements SUBMITBUTTON = new WebPageElements("Submit button of offline form", "xpath", q.submitbutton);
    	
    	//offline search service
  	public WebPageElements SEARCHFORM = new WebPageElements("Offline Search service form", "xpath", q.searchform);
  	public WebPageElements TEXTBOX = new WebPageElements("Search service form textbox", "xpath", q.textbox);
  	public WebPageElements SEARCHSUBMIT = new WebPageElements("Search service form submit button", "xpath", q.searchsubmit);
  	public WebPageElements OFFLINEFORMSEARCH = new WebPageElements("Offline MobileForms Form", "xpath", q.offlineformsearch);
  	public WebPageElements SEARCHSERVICERES = new WebPageElements("Search form view response", "xpath", q.searchserviceres);
  	public WebPageElements DROPDOWNCOLUMNS = new WebPageElements("Search service form's drop down menu", "xpath", q.dropdowncolumns);
  	public WebPageElements search_author = new WebPageElements("Search service form' author", "xpath", q.authorres);
  	public WebPageElements search_stage = new WebPageElements("Search service form' stage", "xpath", q.stage);
  	public WebPageElements search_status = new WebPageElements("Search service form' status", "xpath", q.status);
  	public WebPageElements search_delete = new WebPageElements("Search service form' delete", "xpath", q.deletecolumn);
  	
  	//offline retrieve service
  	public WebPageElements retriev_delete = new WebPageElements("Retrieve service form' delete", "xpath", q.delete);
   	
  	
  	// online service call check(PRANAV)
  	
  	public WebPageElements CREATE_BUTTON = new WebPageElements("CREATE ONLINE' create", "xpath", q.create_button);
  	public WebPageElements START_XPATH = new WebPageElements("start xpath' create", "xpath", q.start_xpath);
  	public WebPageElements END_XPATH = new WebPageElements("end xpath' create", "xpath", q.end_xpath);
  	public WebPageElements MARKS_IN_CREATE = new WebPageElements("marks' create", "xpath", q.marks_in_create);
  	public WebPageElements VIEW_MODE = new WebPageElements("view mode' view", "xpath", q.view_mode);
  	public WebPageElements SEARCH_BOX_RESULT = new WebPageElements("view mode' view", "xpath", q.searchbox);
  	
  	public WebPageElements SHOW_HIDE_COL = new WebPageElements("show hide col. menu", "xpath", q.show_hide_col);
  	public WebPageElements SHOW_HIDE_COL_AUTHOR = new WebPageElements("colauthor", "xpath", q.show_hide_col_author);
  	public WebPageElements SHOW_HIDE_COL_STAGE = new WebPageElements("col stage", "xpath", q.show_hide_col_stage);
  	public WebPageElements  SHOW_HIDE_COL_STATUS  = new WebPageElements("col status", "xpath", q.show_hide_col_status);
  	public WebPageElements  SHOW_HIDE_COL_SINGLE_LINE_ENTRY = new WebPageElements("col single_line entry", "xpath", q.show_hide_col_single_line_entry);
  	public WebPageElements  SHOW_HIDE_COL_NUMBER  = new WebPageElements("col numberr", "xpath", q.show_hide_col_number);
  	public WebPageElements  FIRST_RESPONSE  = new WebPageElements("col numberr", "xpath", q.first_response);
  	
  	//online delete service call check(PRANAV)
  	
  	
  	public WebPageElements  VIEW_RES_FIRST_ELE  = new WebPageElements("first coln", "xpath", q.view_res_first_ele);
  	public WebPageElements  VIEW_RES_SECOND_ELE  = new WebPageElements("second coln", "xpath", q.view_res_second_ele);
  	public WebPageElements  NO_OF_REC  = new WebPageElements("first coln", "xpath", q.no_of_rec);
  	public WebPageElements DEL_SERVICE  = new WebPageElements("first coln", "xpath", q.delete_service);
  	
  //online retrieve service call check(PRANAV)
  	
  	public WebPageElements  RETRIEVE_MARK  = new WebPageElements("first coln", "xpath", q.retrieve_mark);
  	public WebPageElements RETRIEVE_IP = new WebPageElements("first coln", "xpath", q.retrieve_ip);
  	public WebPageElements COUNTER = new WebPageElements("counter", "xpath", q.counter);
  	public WebPageElements DROP_DOWN_COUNTER = new WebPageElements("drop down counter", "xpath", q.dropdown_counter);
  	public WebPageElements DROP_DOWN_SEARCH = new WebPageElements("drop down counter", "xpath", q.drop_down_search);
  	
  	//online js services
  	
  	
  	public WebPageElements VIEW_MODE_JS = new WebPageElements("view mode' view", "xpath", q.view_mode_js);
  	
}

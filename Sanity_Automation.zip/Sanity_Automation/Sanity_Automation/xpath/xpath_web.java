



public interface QRGenerationq {
	
	
	
	String author = "//*[@text='Author']";
	
	
	String qrgeneration_form = "//*[@text='MF-8.5.10 Release Te... QR Generation']";
	//android.view.View[@text='MF-8.5.10 Release Te... Multiple PDF']
	//android.view.View[@text='MF-8.5.10 Release Te... QR Generation']
	String btn_submit = "//*[@text='Submit']";
	String qrgenerateicon = "//*[@text='Section']/following-sibling::android.widget.Button";
	//android.widget.Button[contains(@id,'QRCode')]
	
	String txt_singleline = "//*[@text='Single Line Entry']/following-sibling::android.widget.EditText";
	String txt_multiline = "//*[@text='Multi-Line Entry']/following-sibling::android.widget.EditText";
	String txt_number = "//*[@text='Number']/following-sibling::android.widget.EditText";
	String txt_currency = "//*[@text='Currency']/following-sibling::android.widget.EditText";
	String datepicker = "//*[@text='Date']/following-sibling::android.widget.Spinner";
	//String selectdate = "//android.view.View[@id='month_view'][2]/child::android.view.View[10]";
	String selectdate = "//android.view.View[@text='7']";
	//android.widget.DatePicker/descendant::android.view.View[@id='month_view'][2]/child::*[@text='9']
	String btn_dateset = "//*[@text='SET']";
	String txt_email = "//*[@text='Email']/following-sibling::android.widget.EditText";
	String dropdown = "//*[@text='Drop Down']/following-sibling::android.view.View[not(contains(@id,'hint'))]";
	String dropdown_option = "//android.widget.CheckedTextView[@text='one']";
	String radio_male = "//*[@text='male']";
	String multiselect_blue = "//*[@text='blue']";
	String multiselect_green = "//*[@text='green']";
	String checkbox = "//*[@text='Check Box']";
	String txt_time = "//*[@text='Time']/following-sibling::android.widget.EditText";
	String txt_time_options = "//*[@text='Streebo Mobile Forms']/child::android.view.View[@id='blockingDiv']/following-sibling::android.view.View";
	//String panel_qrshare = "//*[@text='Share via']";
	String panel_qrshare = "//*[@text='Link Sharing']";
	
	//multi pdf
	String multiple_pdf = "//android.view.View[@text='MF-8.5.10 Release Te... Multiple PDF']";
	String urdu_name ="//android.view.View[@text='نام کا نام']/following-sibling::android.widget.EditText";
	String marks = "//android.view.View[@text='Marks']/following-sibling::android.widget.EditText";
	String address = "//android.view.View[@text='address']/following-sibling::android.widget.EditText";
	String time_dd = "//android.view.View[@text='Time']/following-sibling::android.widget.EditText";
	String time_select = "//*[@text='12:00 AM 12:15 AM 12:30 AM 12:45 AM 1:00 AM 1:15 AM 1:30 AM 1:45 AM 2:00 AM 2:15 AM 2:30 AM 2:45 AM 3:00 AM 3:15 AM 3:30 AM 3:45 AM 4:00 AM 4:15 AM 4:30 AM 4:45 AM 5:00 AM 5:15 AM 5:30 AM 5:45 AM 6:00 AM 6:15 AM 6:30 AM 6:45 AM 7:00 AM 7:15 AM 7:30 AM 7:45 AM 8:00 AM 8:15 AM 8:30 AM 8:45 AM 9:00 AM 9:15 AM 9:30 AM 9:45 AM 10:00 AM 10:15 AM 10:30 AM 10:45 AM 11:00 AM 11:15 AM 11:30 AM 11:45 AM 12:00 PM 12:15 PM 12:30 PM 12:45 PM 1:00 PM 1:15 PM 1:30 PM 1:45 PM 2:00 PM 2:15 PM 2:30 PM 2:45 PM 3:00 PM 3:15 PM 3:30 PM 3:45 PM 4:00 PM 4:15 PM 4:30 PM 4:45 PM 5:00 PM 5:15 PM 5:30 PM 5:45 PM 6:00 PM 6:15 PM 6:30 PM 6:45 PM 7:00 PM 7:15 PM 7:30 PM 7:45 PM 8:00 PM 8:15 PM 8:30 PM 8:45 PM 9:00 PM 9:15 PM 9:30 PM 9:45 PM 10:00 PM 10:15 PM 10:30 PM 10:45 PM 11:00 PM 11:15 PM 11:30 PM 11:45 PM']";
	String date_box =  "//*[@text='Date']/following-sibling::android.widget.Spinner";
	String date_select = "//*[@contentDescription='15 June 2018']";
	String date_set= "//*[@text='SET']";
	String currency = "//android.view.View[@text='Currency']/following-sibling::android.widget.EditText";
//	String multiselect_blue = "//*[@text='blue']";
//	String multiselect_green = "//*[@text='green']";
//  String radio_male = "//*[@text='male']";	
	
	String selectone = "//*[@text='one']";
	
	String getPDF_Text = "//*[@resource-id='230e67e3-4147-43fa-8e16-fceb53d8bc30']";
	String getPdf_Select = "//*[@resource-id='9ba20395-acf4-4f8c-885d-26082ff61970']";
	String getPDF_Multiline = "//*[@resource-id='2b113e85-d06b-4888-8268-a7ad0bdf8678']";
	String getpdf_All= "//*[@resource-id='e4a9e40f-9809-4822-8157-581b341207e9']";
	String verify_pdf = "//*[@resource-id='com.google.android.apps.docs:id/action_add_to_drive']";
	/*String submit = "//*[@text='Submit']";*/
	
	
	String qrscan_form="//android.view.View[@text='MF-8.5.10 Release Te... QR Scanner']";
	String qrcodescan="//android.view.View[@text='Scan QR Code']";
	String qrscan_verify="//android.widget.EditText[@resource-id='d5a4e66d-c568-43c7-8692-b57bbbd62f2e']";
	
	// out of box feature testing....
	
		String outofboxfeatureform = "//*[@text='MobileFormsTesting New features']";
		String e_signature  =  "//*[@resource-id='signaturePad80b34503-c726-47a3-86c5-251f2b190728'] ";
		String camera = "//*[@text='Camera']/following-sibling::*[contains(@resource-id,'MYFILE')]"; 
		String camera_capture_box = "//*[@text='CAMERA']";
		String editable_camera = "//*[@resource-id='MYFILE_f6704526-a5f5-4f76-8025-597e902f386f']"; 
		String audio = "//*[@resource-id='start7f4b4068-d24c-4b32-88b2-f8ed1cc1539e']";
		String audio_stop = "//*[@resource-id='stop7f4b4068-d24c-4b32-88b2-f8ed1cc1539e']";
		String audio_play = "//*[@text='play']";
		String video_play = "//*[@text='Record']";
		String video = "//*[@resource-id='MYFILE_a0a8b0e4-222a-43db-8844-c2c91339ebc1']";
		String video_rec = "//*[@text='Record']";
		String barcode = "//*[@resource-id='btn_2393ca59-01c3-45f6-8ffd-8589f0aee5b7']"; 
		String qrcode = "//*[@resource-id='btn_f8f2e3bc-a560-42a4-80e6-6d19a8acdbb2']";
		String ok = "//*[@resource-id='com.sec.android.app.camera:id/okay']";
		String editable_camera_accept = "//*[@text='Save Image']";
		String stop_rec ="//*[@text='Stop']";
	
	//Qr Scanner
	       String qrscanner_form = "//*[@text='MF-8.5.10 Release Te... QR Generation']";
	       String qrscanner = "//*[@resource-id='btnqrcode']";
	       String single_line_entry = "//*[@text='Single Line Entry']/following-sibling::android.widget.EditText";

	
	//outofbox features
		String cameraform="//android.view.View[@text='MobileFormsTesting New features']";
		//sString camera="//*[@text='Camera']/following-sibling::*[contains(@resource-id,'MYFILE')]";
		String cameraoption="android:id/button2";//id
		String cameraOkSamsung="//android.widget.TextView[@resource-id='com.sec.android.app.camera:id/okay']";
		String cameraOkNexus = "//*[@resource-id='org.codeaurora.snapcam:id/done_button']";
		String gallery="android:id/button3";
		String galleryupload="//android.widget.ImageView[@resource-id='com.android.documentsui:id/icon_thumb']";
		String album="//android.view.View[@resource-id='MYFILE_14c13705-5404-47b4-8d2e-8d37b6c82299']";
		String albumphoto="//*[@index='1' and @package='com.sec.android.gallery3d']";
		String audiostart="//android.widget.Button[@text='Start']";
		String audiostop="//android.widget.Button[@text='Stop']";
		String playbutton="//android.widget.Button[@text='play']";
		String esign="//android.widget.Image[@resource-id='signaturePad32d21a6c-ec9a-4536-8ea5-876826f9b70b']";
		String data="//android.widget.EditText[@resource-id='a778915b-54e9-4d6e-8ab3-877073935ebe']";
		String gps="//android.view.View[@text='Show location in map']";
		//String barcode="//android.view.View[@resource-id='btn_b9d25147-9456-4561-8e6f-bb35f8916b0f']";
		//String qrcode="//android.view.View[@resource-id='btn_0f4d2b41-fc53-47bb-8e1f-50261c66282b']";
		String submit="//android.view.View[@text='Submit']";
		String viewres="//*[@text='View' and ./parent::*[./parent::*[@text='sagar testing Form 1 View Launch Date & Time 23/05/2018 15:07 Author admin Type FEB App ']]]";
		String searchtag="//*[@class='android.widget.EditText']";
		String searchbox="//*[@class='android.widget.EditText']";
		String viewresform="//android.view.View[@text='admin']";
		String offlinerecord = "//android.view.View[@text='Offline record inserted !']";
		String recordok = "//android.widget.Button[@text='Ok']";
		
		//offline pdf
		String offlineform="//android.view.View[@text='MobileFormsAutomatio... Offline Form']";
		String getpdf="//android.view.View[@resource-id= '2b113e85-d06b-4888-8268-a7ad0bdf8678']";
		
		//offline create service call
		String createform = "//*[@text='MobileFormsTesting Offline service chec...']";
		String name="//*[@text='Name']/following-sibling::android.widget.EditText";
		String mark = "//*[@text='marks']/following-sibling::android.widget.EditText";
		String bindbutton="//android.view.View[@resource-id='21d710bf-ef0f-4f95-8ebb-1c07e81c81f3']";
		String record = "//*[@text='no of records']/following-sibling::android.widget.EditText";
		String submitbutton="//*[@text='Submit']";
		
		//offlinesearchservice
		String searchform="//android.view.View[@text='MobileFormsAutomatio... Delete/Search Form']";
		String textbox="//android.widget.EditText[@resource-id='07a080dc-7bd3-4e6d-8b47-57f4324a7717']";
		String searchsubmit="//android.view.View[@text='Submit']";
		String offlineformsearch="//android.view.View[@text='MobileFormsAutomatio... Offline Form']";
		String searchserviceres="//android.view.View[@text='MobileFormsAutomatio... Delete/Search Form View Launch Date & Time 27/02/2018 12:26 Author admin Type FEB App ']//android.view.View[@text='View']";
		String dropdowncolumns="//android.widget.Button[@text='Show / hide columns']";
		String authorres="//android.widget.CheckBox[@text='Author']";
		String stage="//android.widget.CheckBox[@text='Stage']";
		String status="//android.widget.CheckBox[@text='Status']";
		String deletecolumn="//android.widget.CheckBox[@text='Deleted Data']";
		
		//offlineretrieveservice
		String delete= "//android.view.View[@text='Click to delete']";
		
		
		//online create service
		
	//String createform = "//*[@text='MobileFormsTesting Offline service chec...']";	
	//	String name="//*[@text='Name']/following-sibling::android.widget.EditText";
	  
		String start_xpath = "//*[@text='Testing App Form 1']";
		String end_xpath  = "//*[@text='MobileFormsTesting Offline service chec...']";
		String create_button = "//*[@resource-id='21d710bf-ef0f-4f95-8ebb-1c07e81c81f3']";	
		String marks_in_create = "//*[@resource-id='3acfbf46-31e8-4aa5-87f9-bb1fb34ea74a']";
		String view_mode = "//*[@text='View' and ./parent::*[./parent::*[@text='MobileFormsTesting service data form View Launch Date & Time 18/06/2018 12:58 Author pranav.madhani@streebo.com Type FEB App ']]]";
		String view_mode_js = "//*[@text='View' and ./parent::*[./parent::*[@text='Service test JS service data form re... View Launch Date & Time 10/07/2018 15:03 Author pranav.madhani@streebo.com Type FEB App ']]]";
		String searchboxresult = "//*[@class='android.widget.EditText']";
		
		String show_hide_col = "//*[@text='Show / hide columns']";
		String show_hide_col_author = "//*[@text='Author']";
		String show_hide_col_stage = "//*[@text='Stage']";
		String show_hide_col_status = "//*[@text='Status']";
		String show_hide_col_single_line_entry =  "//*[@text='Single Line Entry']";
		String show_hide_col_number =  "//*[@text='Number']";
		String first_response = "//*[@text='67']";
		
		
		
		//online delete service {pranav}
		
		String view_res_first_ele = "//*[@resource-id='dataTablecontentformRecord']/android.view.View[1]/android.view.View[1]";
		String view_res_second_ele = "//*[@resource-id='dataTablecontentformRecord']/android.view.View[2]/android.view.View[2]";
		String no_of_rec = "//*[@resource-id='7c805275-8938-46be-88bf-29120b9cdff0']";
		String delete_service = "//*[@resource-id='17d2a218-f2b1-4986-8bfd-ada3ab24324e']";
		
		//online retrieve service {pranav}
		
		String retrieve_mark = "//*[@resource-id='85a4a481-e41d-42ef-8d9c-39847ccd5781']";
		String retrieve_ip = "//*[@resource-id='1d97796e-4116-4a3d-823f-fbe6d26a1d42']";
		String counter = "//*[@resource-id='dataTablecontentformRecord']/android.view.View";
		String drop_down_search = "//*[@resource-id='select_2b871785-fb22-4c72-81f0-81c1818e2f24']";
		String dropdown_counter = "//*[@class='android.widget.ListView']/android.widget.CheckedTextView";
}	//*[@resource-id='dataTablecontentformRecord']/android.view.View
